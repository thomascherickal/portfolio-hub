---
type: prompt-set
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [prompt-set, area/01-curation-prompts]
updated: 2026-11-15
---

# Prompts That Curate the Best Prompt Frameworks

Run these in order. Use a model with web search on for CURATE-01 so the longlist reflects current practice, and verify every source it cites.

## CURATE-01 - Build the Longlist

```
Role: You are a prompt-engineering researcher.
Task: Build a longlist of named prompt frameworks and prompting techniques
used by Gen AI practitioners today.
For each, give: name, expansion of the acronym if any, origin (paper,
vendor docs, competition or community), year, the problem it solves,
and a source link.
Include both structural templates (e.g. CO-STAR, RISEN, RTF) and
reasoning techniques (e.g. Chain-of-Thought, ReAct).
Exclude anything you cannot source. Mark community frameworks with no
formal origin as "community".
Output a Markdown table, then a list of sources.
```

## CURATE-02 - Score Against a Rubric

```
<longlist>{{CURATE-01 output}}</longlist>

Score each framework 1 to 5 on:
1. Clarity - can a new user apply it in under 5 minutes?
2. Coverage - does it force the inputs that most prompts forget
   (context, audience, format, constraints)?
3. Testability - does it produce outputs you can assert against?
4. Evidence - is there published or vendor evidence it improves results?
5. Fit for Gen AI engineering work - code, evals, RAG, agents, consulting.
6. Overlap - penalise frameworks that are near-duplicates of a stronger one.
Return a ranked table with totals and a one-line justification each.
Recommend a shortlist of 6 to 10 that together cover structure,
reasoning, examples and tool use with minimal overlap.
```

## CURATE-03 - Head-to-Head Bake-Off

```
<shortlist>{{CURATE-02 shortlist}}</shortlist>
<tasks>
1. Write an eval plan for a customer-support chatbot.
2. Debug a RAG pipeline with low recall.
3. Draft a client proposal for an AI pilot.
</tasks>

For each task, write one prompt per shortlisted framework. Keep the
underlying facts identical so only the structure differs.
Then output a test plan: which outputs to compare, the judge rubric,
and how many runs per prompt to average out variance.
```

## CURATE-04 - Write the Canonical Template

```
<framework>{{name}}</framework>
<evidence>{{bake-off results}}</evidence>

Write the registry file for this framework:
- What it is (2 sentences) and its source
- When to use it and when not to
- The blank template with {{placeholders}}
- A filled example for a Gen AI engineering task
- Common mistakes (3 bullets)
- 5 sample prompts for Gen AI professionals, each with an id,
  target role and use case
Use the entry schema for each sample prompt.
```

## CURATE-05 - Quarterly Re-Review

```
<registry_frameworks>{{current framework files}}</registry_frameworks>
<usage_data>{{usage and test pass rates per framework}}</usage_data>

Which frameworks should be kept, merged or deprecated? Has any new
technique emerged since {{last review date}} that deserves a bake-off?
Propose changes as a changelog with version bumps.
```

## Links

- Up: [[README|Registry home]]
