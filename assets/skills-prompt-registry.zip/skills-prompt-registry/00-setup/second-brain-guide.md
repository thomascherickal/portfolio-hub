---
type: guide
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [guide, area/00-setup]
updated: 2026-11-15
---

# Second Brain Guide

The registry opens as an Obsidian vault (or any wikilink-aware Markdown tool such as Logseq or Foam). Every file carries front matter and a Links section, so the graph view shows how roles, skills, frameworks and tests connect.

## Metadata Conventions

| Field | Where | Purpose |
|---|---|---|
| `type` | every file | moc, category-index, role-index, skill, framework, guide, prompt-set |
| `owner` | every file | accountable person (Thomas Cherickal) |
| `tags` | every file | nested tags: `role/...`, `category/...`, `framework/...`, `status/...` |
| `aliases` | skills, roles, frameworks | alternative names for search and link matching |
| `parent` | category indexes | the folder one level up |
| `metadata.id` | skills | stable registry id |
| `metadata.status` | skills | seed, draft, tested, approved, deprecated |
| `updated` | every file | last edit date |

## Linking Rules

- Every note links **up** to its folder's index note (`_index.md` or `README.md`).
- Skills link **sideways** to sibling skills and **across** to the frameworks that suit them.
- Wikilinks use full paths (`[[03-skills/quantum/engineering/_index|engineering]]`) because many files share the name `SKILL.md`.

## Useful Queries (Dataview plugin)

```dataview
TABLE metadata.role AS role, metadata.status AS status
FROM #skill AND #status/seed
SORT metadata.category
```

```dataview
LIST FROM #moc
```

## Daily Use

- Open the vault at the registry root.
- Start from `README.md` or `03-skills/README.md` and follow the links down.
- When you promote an entry, update `status` in both the front matter and the tag.

## Links

- Up: [[README|Registry home]]
