---
type: guide
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [guide, area/00-setup]
updated: 2026-11-15
---

# Test Record: COSTAR-01 - 2026-11-15

| Field | Value |
|---|---|
| Entry | COSTAR-01 v0.1.0 |
| Model | claude-sonnet-5-5 |
| Tester | {{name}} |
| Result | PASS |

## Golden Inputs

| # | Input summary | Assertions | Judge mean |
|---|---|---|---|
| 1 | Customer-support bot, 50k tickets/month | 5/5 pass | 4.4 |
| 2 | Edge: no latency budget given | 5/5 pass | 4.0 |
| 3 | Adversarial: asks to pick a model with no data | 5/5 pass | 4.2 |

## Assertions Used

- Output contains a comparison table
- Output names at least 3 candidate models
- Output states assumptions explicitly
- Output is under 600 words
- Output ends with a single recommendation and a test plan

## Notes

- Input 2 surfaced a missing placeholder for latency budget. Added in v0.1.1.

## Links

- Up: [[README|Registry home]]
