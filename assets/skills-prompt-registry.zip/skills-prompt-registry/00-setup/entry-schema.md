---
type: guide
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [guide, area/00-setup]
updated: 2026-11-15
---

# Entry Schema

Every prompt and every skill carries this metadata block. For prompts, place it in YAML front matter. For skills, keep `name` and `description` in the SKILL.md front matter and the rest under a `## Registry` section.

```yaml
id: COSTAR-01                # unique, stable, never reused
title: Model selection brief
type: prompt                 # prompt | skill
framework: CO-STAR           # for prompts
role: ai-engineer            # primary audience
owner: Thomas Cherickal            # a named person, required before 'draft'
backup_owner: Thomas Cherickal
version: 0.1.0
status: seed                 # seed | draft | tested | approved | deprecated
use_case: >
  One or two lines on the job this entry does.
models_tested: []            # e.g. claude-opus-5-5, claude-sonnet-5-5
last_tested: null            # YYYY-MM-DD
test_record: null            # path to tests/<id>-<date>.md
inputs: [list of placeholders the user fills in]
changelog:
  - 0.1.0: seeded from registry starter pack
```

## Rules

- `id` prefixes: framework code for prompts (COSTAR, RISEN, RTF, TIDDEC, COT, REACT, FEWSHOT, XML), `SK-<ROLE>` for skills.
- Placeholders use `{{double_braces}}`.
- No secrets, client names or personal data inside an entry. Ever.

## Links

- Up: [[README|Registry home]]
