---
type: guide
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [guide, area/00-setup]
updated: 2026-11-15
---

# Cold-Start Guide: Building the Registry With No Existing Data

You do not need a backlog of prompts to start. You need a schema, a seed set, a harvest loop and a test gate. This pack is the seed set.

## Phase 0 - Decide the Rules (Day 1)

- Adopt `entry-schema.md` as the contract. An entry without an owner is not an entry.
- Pick the repo home: one Git repo, Markdown only, folders as shown in `README.md`.
- Add a `CODEOWNERS` file so every folder routes reviews to a named owner.
- Use semantic versioning per entry: MAJOR for changed behaviour, MINOR for new capability, PATCH for wording fixes.

## Phase 1 - Seed From Public Knowledge (Week 1)

- Run the prompts in `01-curation-prompts/curate-frameworks.md` to build the framework shortlist.
- Commit the 8 framework files in `02-frameworks/` with status `seed`.
- Commit the role skills in `03-skills/` with status `seed` and owner `Thomas Cherickal`.
- Seed count after Phase 1: 8 frameworks, 40 sample prompts, 42 skills.

## Phase 2 - Harvest From People (Weeks 2 to 4)

- Ask each team to export 3 to 5 chats where Claude did excellent work.
- Run the prompts in `harvest-prompts.md` to extract, anonymise and template the reusable prompt inside each chat.
- Each harvested prompt becomes a `draft` entry with the contributor as owner.
- Run a 30-minute "prompt clinic" per department: people bring one task, leave with one registered entry.

## Phase 3 - Test Gate (Ongoing)

- Follow `testing-guide.md`. Every entry gets at least 3 golden inputs and pass/fail assertions.
- An entry moves to `tested` only with a dated test record in its `tests/` folder.
- Re-run tests on every model upgrade. A model change is a regression risk, not a free upgrade.

## Phase 4 - Govern (Monthly)

- Owners review their entries monthly. Stale for 90 days with no owner action means `deprecated`.
- Track adoption: which entries are used, by whom, and whether output was accepted unedited.
- When a person leaves, CODEOWNERS reassignment is part of offboarding. This is the whole point: knowledge stays when people go.

## Phase 5 - Publish the Free Demo

- Build a static site from the Markdown (MkDocs, Astro Starlight or Eleventy all work).
- Deploy a public sample subset to Cloudflare Pages or GitHub Pages on the free tier.
- Keep internal entries in a private repo. Publish only `seed` and generic entries.
- Add a search box and filters for role, framework, status and owner.

## Minimum Viable Registry Checklist

- [ ] Schema adopted
- [ ] CODEOWNERS file in place
- [ ] Seed pack committed
- [ ] One harvest round completed
- [ ] 10 entries at `tested`
- [ ] Public sample live on Pages

## Links

- Up: [[README|Registry home]]
