---
type: prompt-set
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [prompt-set, area/00-setup]
updated: 2026-11-15
---

# Harvest Prompts

Use these to turn individual chat histories into registry entries.

## HARVEST-01 - Extract the Reusable Prompt

```
<chat_export>{{paste the full chat}}</chat_export>

Find the prompt or prompt sequence in this chat that produced the best result.
1. Quote the original prompt(s).
2. Rewrite it as a reusable template with {{placeholders}} for every
   task-specific detail.
3. Remove all names, client details, credentials and personal data.
4. Name the framework it most resembles (CO-STAR, RISEN, RTF, TIDD-EC,
   Chain-of-Thought, ReAct, Few-Shot, XML-Structured) and restructure it
   to fit that framework cleanly.
5. Fill in the entry schema below. Leave owner as the contributor.
<schema>{{paste entry-schema.md YAML}}</schema>
```

## HARVEST-02 - Is This a Prompt or a Skill?

```
<candidate>{{template from HARVEST-01}}</candidate>

Decide whether this belongs in the registry as a prompt or as a skill.
It is a skill if it: is reused across many tasks, needs multi-step
procedure, references files or scripts, or should trigger automatically.
It is a prompt if it is a single, self-contained request.
Explain in three sentences, then output the entry in the right format.
For a skill, output a SKILL.md with name, description (when to trigger),
steps, checks and a Registry section.
```

## HARVEST-03 - Write the Golden Tests

```
<entry>{{entry}}</entry>

Write 3 golden inputs for this entry: one typical, one edge case, one
adversarial. For each, list 3 to 5 deterministic assertions and a
5-line judge rubric. Output in the format of example-test.md.
```

## HARVEST-04 - Deduplicate Against the Registry

```
<new_entry>{{entry}}</new_entry>
<registry_index>{{list of id, title, use_case for all entries}}</registry_index>

Is the new entry a duplicate, a variant, or new? If duplicate, name the
existing id. If variant, propose merging as a MINOR version bump of the
existing entry and show the diff. If new, confirm the id.
```

## Links

- Up: [[README|Registry home]]
