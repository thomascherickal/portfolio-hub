---
type: moc
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, area/README.md]
updated: 2026-11-15
---

# Skills and Prompt Registry

A versioned garden of Claude skills and prompts. Each entry has an owner, a use case, a version and test results. Prompts and skills are treated as engineering assets, not chat history.

## Folder Map

```
skills-prompt-registry/
├── README.md                      <- you are here
├── 00-setup/
│   ├── cold-start-guide.md        <- how to stand this up with zero existing data
│   ├── entry-schema.md            <- required metadata for every prompt and skill
│   ├── testing-guide.md           <- how entries earn "tested" status
│   ├── example-test.md            <- a filled-in test record
│   ├── harvest-prompts.md         <- prompts that pull good prompts out of people's chats
│   └── second-brain-guide.md      <- metadata, tags and linking for Obsidian
├── 01-curation-prompts/
│   └── curate-frameworks.md       <- prompts that find, score and canonicalise frameworks
├── 02-frameworks/                 <- one file per framework, 5 Gen AI sample prompts each
│   ├── co-star.md
│   ├── risen.md
│   ├── rtf.md
│   ├── tidd-ec.md
│   ├── chain-of-thought.md
│   ├── react.md
│   ├── few-shot.md
│   └── xml-structured.md
├── 03-skills/                     <- hierarchical: category / subcategory / role / skill / SKILL.md
    ├── software-engineering/  general, languages (Python, Go, Rust), application (back-end, front-end, full-stack, PWA)
    ├── ai-ml/                 applied-ai (AI, Gen AI), llm-systems (LLM, RAG, Local AI)
    ├── quantum/               engineering (quantum computing, quantum ML/AI), research (quantum computing researcher)
    ├── web3/                  blockchain, DeFi and Web3 engineer
    ├── design-and-content/    web designer, technical writer
    ├── research/              research scientist, industry researcher
│   └── consulting/            Gen AI consultant
└── 04-public-skills-directory/    <- public skills by other authors: owner = author, curator = Thomas Cherickal
    ├── roles/                 same category hierarchy, one ranked page per role
    ├── skills/<owner>/        one linked note per public skill
    ├── sources/               one note per source repo, ranked by stars
    └── all-skills.md          every listed skill, ranked by stars
```

## Status Lifecycle

`seed` -> `draft` -> `tested` -> `approved` -> `deprecated`

Everything in this pack starts as `seed`. Nothing reaches `approved` without an owner and a passing test record.

## Start Here

Read `00-setup/cold-start-guide.md`. It takes you from an empty repo to a public sample registry in five phases.

## Owner

Thomas Cherickal owns and curates the seed entries in `00` to `03`. Public skills in `04` keep their original authors as owners, with Thomas Cherickal as curator.

## Second Brain

Open this folder as an Obsidian vault. See [[00-setup/second-brain-guide|second brain guide]]. Entry points: [[03-skills/README|Skills index]], [[02-frameworks/_index|Frameworks]].
- Public directory: [[04-public-skills-directory/README|Public skills directory]]

## Publish

See [[DEPLOY-CLOUDFLARE-PAGES|Deploy to Cloudflare Pages]] to host the free public registry at skillregistry.thedigitalfuturist.com.
