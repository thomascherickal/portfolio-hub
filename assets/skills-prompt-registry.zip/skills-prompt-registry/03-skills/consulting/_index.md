---
type: category-index
category: consulting
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, category/consulting]
parent: 03-skills
updated: 2026-11-15
---

# consulting

Gen AI consulting and advisory.

- Up: [[03-skills/README|Skills index]]

## Roles

- [[03-skills/consulting/genai-consultant/README|Gen AI Consultant]]
