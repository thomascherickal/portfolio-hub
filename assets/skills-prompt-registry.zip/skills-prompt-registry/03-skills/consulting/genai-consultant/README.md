---
type: role-index
role: genai-consultant
category: consulting
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/genai-consultant, category/consulting]
aliases: [Gen AI Consultant]
updated: 2026-11-15
---

# Gen AI Consultant Skills

| Skill | Use it when | id |
|---|---|---|
| [use-case-discovery](./use-case-discovery/SKILL.md) | at the start of an engagement | SK-GENAI-CONSULTANT-use-case-discovery |
| [roi-business-case](./roi-business-case/SKILL.md) | when a client needs budget approval | SK-GENAI-CONSULTANT-roi-business-case |
| [ai-readiness-assessment](./ai-readiness-assessment/SKILL.md) | before proposing a roadmap | SK-GENAI-CONSULTANT-ai-readiness-assessment |

## Links

- Up: [[03-skills/consulting/_index|consulting]]
