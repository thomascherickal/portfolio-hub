---
name: roi-business-case
description: Build an ROI case for a Gen AI initiative. Use when a client needs budget approval.
metadata:
  id: SK-GENAI-CONSULTANT-roi-business-case
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: genai-consultant
  category: consulting
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/genai-consultant, category/consulting, status/seed]
aliases: [roi business case]
---

# roi-business-case

## Steps

1. Baseline current time and cost per task.
2. Estimate realistic time saved from a pilot, not vendor claims.
3. Include build, run, change-management and risk costs.
4. Show payback period under conservative and expected cases.

## Done When

- [ ] Every assumption is listed and sourced

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-GENAI-CONSULTANT-roi-business-case | genai-consultant | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/consulting/genai-consultant/README|Gen AI Consultant skills]]
- Siblings: [[03-skills/consulting/genai-consultant/ai-readiness-assessment/SKILL|ai-readiness-assessment]], [[03-skills/consulting/genai-consultant/use-case-discovery/SKILL|use-case-discovery]]
- Frameworks: [[02-frameworks/co-star|co-star]], [[02-frameworks/rtf|rtf]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
