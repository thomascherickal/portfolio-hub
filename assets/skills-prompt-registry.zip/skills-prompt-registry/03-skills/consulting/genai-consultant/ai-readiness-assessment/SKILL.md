---
name: ai-readiness-assessment
description: Assess an organisation's readiness for Gen AI. Use before proposing a roadmap.
metadata:
  id: SK-GENAI-CONSULTANT-ai-readiness-assessment
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: genai-consultant
  category: consulting
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/genai-consultant, category/consulting, status/seed]
aliases: [ai readiness assessment]
---

# ai-readiness-assessment

## Steps

1. Score data, skills, governance, infrastructure and culture 1 to 5.
2. Identify the blocking gaps.
3. Recommend a 90-day plan to close the top 3 gaps.
4. Define how to measure progress.

## Done When

- [ ] Scores backed by interview or document evidence

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-GENAI-CONSULTANT-ai-readiness-assessment | genai-consultant | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/consulting/genai-consultant/README|Gen AI Consultant skills]]
- Siblings: [[03-skills/consulting/genai-consultant/roi-business-case/SKILL|roi-business-case]], [[03-skills/consulting/genai-consultant/use-case-discovery/SKILL|use-case-discovery]]
- Frameworks: [[02-frameworks/co-star|co-star]], [[02-frameworks/rtf|rtf]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
