---
name: use-case-discovery
description: Run Gen AI use-case discovery with a client. Use at the start of an engagement.
metadata:
  id: SK-GENAI-CONSULTANT-use-case-discovery
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: genai-consultant
  category: consulting
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/genai-consultant, category/consulting, status/seed]
aliases: [use case discovery]
---

# use-case-discovery

## Steps

1. Interview stakeholders on tasks that are repetitive, text-heavy or judgement-light.
2. List candidate use cases with owner and current cost.
3. Score on value, feasibility, data readiness and risk.
4. Pick 1 to 3 for a pilot.

## Done When

- [ ] Every use case has a named business owner

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-GENAI-CONSULTANT-use-case-discovery | genai-consultant | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/consulting/genai-consultant/README|Gen AI Consultant skills]]
- Siblings: [[03-skills/consulting/genai-consultant/ai-readiness-assessment/SKILL|ai-readiness-assessment]], [[03-skills/consulting/genai-consultant/roi-business-case/SKILL|roi-business-case]]
- Frameworks: [[02-frameworks/co-star|co-star]], [[02-frameworks/rtf|rtf]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
