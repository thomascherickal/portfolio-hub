---
type: role-index
role: industry-researcher
category: research
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/industry-researcher, category/research]
aliases: [Industry Researcher]
updated: 2026-11-15
---

# Industry Researcher Skills

| Skill | Use it when | id |
|---|---|---|
| [market-landscape-scan](./market-landscape-scan/SKILL.md) | when asked who the players are in a space | SK-INDUSTRY-RESEARCHER-market-landscape-scan |
| [source-verification](./source-verification/SKILL.md) | on any research piece with numbers | SK-INDUSTRY-RESEARCHER-source-verification |
| [research-brief](./research-brief/SKILL.md) | when turning research into a deliverable | SK-INDUSTRY-RESEARCHER-research-brief |

## Links

- Up: [[03-skills/research/_index|research]]
