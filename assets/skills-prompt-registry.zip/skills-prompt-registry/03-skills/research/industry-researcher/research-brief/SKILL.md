---
name: research-brief
description: Write an industry research brief. Use when turning research into a deliverable.
metadata:
  id: SK-INDUSTRY-RESEARCHER-research-brief
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: industry-researcher
  category: research
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/industry-researcher, category/research, status/seed]
aliases: [research brief]
---

# research-brief

## Steps

1. Lead with the answer.
2. Support with 3 to 5 findings and evidence.
3. Add implications for the reader.
4. List sources.

## Done When

- [ ] Under 2 pages

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-INDUSTRY-RESEARCHER-research-brief | industry-researcher | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/research/industry-researcher/README|Industry Researcher skills]]
- Siblings: [[03-skills/research/industry-researcher/market-landscape-scan/SKILL|market-landscape-scan]], [[03-skills/research/industry-researcher/source-verification/SKILL|source-verification]]
- Frameworks: [[02-frameworks/co-star|co-star]], [[02-frameworks/react|react]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
