---
name: market-landscape-scan
description: Map a market or technology landscape. Use when asked who the players are in a space.
metadata:
  id: SK-INDUSTRY-RESEARCHER-market-landscape-scan
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: industry-researcher
  category: research
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/industry-researcher, category/research, status/seed]
aliases: [market landscape scan]
---

# market-landscape-scan

## Steps

1. Define the market boundaries.
2. List companies, products and funding from primary sources.
3. Group into segments.
4. Note trends and gaps.

## Done When

- [ ] Every company row has a source and date

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-INDUSTRY-RESEARCHER-market-landscape-scan | industry-researcher | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/research/industry-researcher/README|Industry Researcher skills]]
- Siblings: [[03-skills/research/industry-researcher/research-brief/SKILL|research-brief]], [[03-skills/research/industry-researcher/source-verification/SKILL|source-verification]]
- Frameworks: [[02-frameworks/co-star|co-star]], [[02-frameworks/react|react]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
