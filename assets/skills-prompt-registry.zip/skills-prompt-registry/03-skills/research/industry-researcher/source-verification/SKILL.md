---
name: source-verification
description: Verify claims and figures before publishing. Use on any research piece with numbers.
metadata:
  id: SK-INDUSTRY-RESEARCHER-source-verification
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: industry-researcher
  category: research
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/industry-researcher, category/research, status/seed]
aliases: [source verification]
---

# source-verification

## Steps

1. Trace each figure to its primary source.
2. Check the date and definition used.
3. Cross-check with a second source.
4. Flag anything unverifiable.

## Done When

- [ ] No unsourced figures

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-INDUSTRY-RESEARCHER-source-verification | industry-researcher | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/research/industry-researcher/README|Industry Researcher skills]]
- Siblings: [[03-skills/research/industry-researcher/market-landscape-scan/SKILL|market-landscape-scan]], [[03-skills/research/industry-researcher/research-brief/SKILL|research-brief]]
- Frameworks: [[02-frameworks/co-star|co-star]], [[02-frameworks/react|react]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
