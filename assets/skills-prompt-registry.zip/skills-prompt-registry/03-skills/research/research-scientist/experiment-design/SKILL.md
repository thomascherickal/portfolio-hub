---
name: experiment-design
description: Design a rigorous experiment. Use before running any study or ablation.
metadata:
  id: SK-RESEARCH-SCIENTIST-experiment-design
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: research-scientist
  category: research
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/research-scientist, category/research, status/seed]
aliases: [experiment design]
---

# experiment-design

## Steps

1. State hypothesis and null hypothesis.
2. Define variables, controls and metrics.
3. Estimate sample size or seeds needed.
4. Pre-register the analysis plan.

## Done When

- [ ] Analysis plan written before results

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-RESEARCH-SCIENTIST-experiment-design | research-scientist | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/research/research-scientist/README|Research Scientist skills]]
- Siblings: [[03-skills/research/research-scientist/literature-review/SKILL|literature-review]], [[03-skills/research/research-scientist/reproducible-paper/SKILL|reproducible-paper]]
- Frameworks: [[02-frameworks/co-star|co-star]], [[02-frameworks/react|react]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
