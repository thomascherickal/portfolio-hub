---
type: role-index
role: research-scientist
category: research
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/research-scientist, category/research]
aliases: [Research Scientist]
updated: 2026-11-15
---

# Research Scientist Skills

| Skill | Use it when | id |
|---|---|---|
| [literature-review](./literature-review/SKILL.md) | when starting a research question | SK-RESEARCH-SCIENTIST-literature-review |
| [experiment-design](./experiment-design/SKILL.md) | before running any study or ablation | SK-RESEARCH-SCIENTIST-experiment-design |
| [reproducible-paper](./reproducible-paper/SKILL.md) | when preparing a paper or preprint | SK-RESEARCH-SCIENTIST-reproducible-paper |

## Links

- Up: [[03-skills/research/_index|research]]
