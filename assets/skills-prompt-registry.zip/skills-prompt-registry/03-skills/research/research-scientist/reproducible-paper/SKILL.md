---
name: reproducible-paper
description: Write a reproducible research paper. Use when preparing a paper or preprint.
metadata:
  id: SK-RESEARCH-SCIENTIST-reproducible-paper
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: research-scientist
  category: research
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/research-scientist, category/research, status/seed]
aliases: [reproducible paper]
---

# reproducible-paper

## Steps

1. Release code, data and configs with versions.
2. Report seeds, hardware and run time.
3. Include ablations and error bars.
4. Write limitations honestly.

## Done When

- [ ] Results reproduce from the repo

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-RESEARCH-SCIENTIST-reproducible-paper | research-scientist | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/research/research-scientist/README|Research Scientist skills]]
- Siblings: [[03-skills/research/research-scientist/experiment-design/SKILL|experiment-design]], [[03-skills/research/research-scientist/literature-review/SKILL|literature-review]]
- Frameworks: [[02-frameworks/co-star|co-star]], [[02-frameworks/react|react]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
