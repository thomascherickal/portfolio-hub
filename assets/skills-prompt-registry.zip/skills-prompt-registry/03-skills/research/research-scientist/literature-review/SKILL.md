---
name: literature-review
description: Run a structured literature review. Use when starting a research question.
metadata:
  id: SK-RESEARCH-SCIENTIST-literature-review
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: research-scientist
  category: research
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/research-scientist, category/research, status/seed]
aliases: [literature review]
---

# literature-review

## Steps

1. Define the question and inclusion criteria.
2. Search arXiv, Semantic Scholar and Google Scholar.
3. Extract claims, methods and results into a table.
4. Identify gaps and contradictions.

## Done When

- [ ] Every claim linked to a paper

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-RESEARCH-SCIENTIST-literature-review | research-scientist | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/research/research-scientist/README|Research Scientist skills]]
- Siblings: [[03-skills/research/research-scientist/experiment-design/SKILL|experiment-design]], [[03-skills/research/research-scientist/reproducible-paper/SKILL|reproducible-paper]]
- Frameworks: [[02-frameworks/co-star|co-star]], [[02-frameworks/react|react]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
