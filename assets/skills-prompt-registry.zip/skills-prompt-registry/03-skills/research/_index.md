---
type: category-index
category: research
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, category/research]
parent: 03-skills
updated: 2026-11-15
---

# research

Scientific and industry research.

- Up: [[03-skills/README|Skills index]]

## Roles

- [[03-skills/research/research-scientist/README|Research Scientist]]
- [[03-skills/research/industry-researcher/README|Industry Researcher]]
