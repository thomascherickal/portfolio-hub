---
name: model-selection-eval
description: Compare candidate LLMs for a task on quality, latency and cost. Use when choosing or switching models, or when a model upgrade is announced.
metadata:
  id: SK-AI-ENGINEER-model-selection-eval
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: ai-engineer
  category: ai-ml/applied-ai
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/ai-engineer, category/ai-ml/applied-ai, status/seed]
aliases: [model selection eval]
---

# model-selection-eval

## Steps

1. Collect the task definition, volume, latency budget and cost ceiling.
2. Build or reuse a golden set of at least 30 real inputs.
3. Run every candidate on the same set with the same prompt.
4. Score with deterministic checks plus a versioned judge rubric.
5. Report a table: quality, p95 latency, cost per 1k requests.

## Done When

- [ ] Same prompt and temperature across models
- [ ] Results include variance across at least 3 runs

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-AI-ENGINEER-model-selection-eval | ai-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/applied-ai/ai-engineer/README|AI Engineer skills]]
- Siblings: [[03-skills/ai-ml/applied-ai/ai-engineer/llm-eval-harness/SKILL|llm-eval-harness]], [[03-skills/ai-ml/applied-ai/ai-engineer/prompt-regression-tests/SKILL|prompt-regression-tests]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
