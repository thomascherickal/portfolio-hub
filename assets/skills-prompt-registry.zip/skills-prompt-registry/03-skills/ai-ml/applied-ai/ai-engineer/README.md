---
type: role-index
role: ai-engineer
category: ai-ml/applied-ai
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/ai-engineer, category/ai-ml/applied-ai]
aliases: [AI Engineer]
updated: 2026-11-15
---

# AI Engineer Skills

| Skill | Use it when | id |
|---|---|---|
| [model-selection-eval](./model-selection-eval/SKILL.md) | when choosing or switching models, or when a model upgrade is announced | SK-AI-ENGINEER-model-selection-eval |
| [llm-eval-harness](./llm-eval-harness/SKILL.md) | when a feature has no tests, or before any prompt or model change ships | SK-AI-ENGINEER-llm-eval-harness |
| [prompt-regression-tests](./prompt-regression-tests/SKILL.md) | when a prompt is edited or the underlying model changes | SK-AI-ENGINEER-prompt-regression-tests |

## Links

- Up: [[03-skills/ai-ml/applied-ai/_index|ai-ml/applied-ai]]
