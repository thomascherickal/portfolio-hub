---
name: llm-eval-harness
description: Scaffold an evaluation harness for an LLM feature. Use when a feature has no tests, or before any prompt or model change ships.
metadata:
  id: SK-AI-ENGINEER-llm-eval-harness
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: ai-engineer
  category: ai-ml/applied-ai
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/ai-engineer, category/ai-ml/applied-ai, status/seed]
aliases: [llm eval harness]
---

# llm-eval-harness

## Steps

1. Define the feature's job in one sentence.
2. Write golden inputs: typical, edge, adversarial.
3. Write assertions as code (schema, length, banned phrases).
4. Add an LLM-judge step with a rubric file.
5. Wire it into CI to run on every PR touching prompts.

## Done When

- [ ] Harness runs locally with one command
- [ ] Failing assertions block merge

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-AI-ENGINEER-llm-eval-harness | ai-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/applied-ai/ai-engineer/README|AI Engineer skills]]
- Siblings: [[03-skills/ai-ml/applied-ai/ai-engineer/model-selection-eval/SKILL|model-selection-eval]], [[03-skills/ai-ml/applied-ai/ai-engineer/prompt-regression-tests/SKILL|prompt-regression-tests]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
