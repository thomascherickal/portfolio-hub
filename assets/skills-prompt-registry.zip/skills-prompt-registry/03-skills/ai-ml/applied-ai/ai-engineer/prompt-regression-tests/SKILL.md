---
name: prompt-regression-tests
description: Write regression tests for an existing prompt. Use when a prompt is edited or the underlying model changes.
metadata:
  id: SK-AI-ENGINEER-prompt-regression-tests
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: ai-engineer
  category: ai-ml/applied-ai
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/ai-engineer, category/ai-ml/applied-ai, status/seed]
aliases: [prompt regression tests]
---

# prompt-regression-tests

## Steps

1. Snapshot current outputs on the golden set.
2. Diff new outputs against snapshots on structure, not wording.
3. Flag semantic drift with a judge comparing old vs new.
4. Record results in the registry test format.

## Done When

- [ ] Test record is dated and linked from the entry

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-AI-ENGINEER-prompt-regression-tests | ai-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/applied-ai/ai-engineer/README|AI Engineer skills]]
- Siblings: [[03-skills/ai-ml/applied-ai/ai-engineer/llm-eval-harness/SKILL|llm-eval-harness]], [[03-skills/ai-ml/applied-ai/ai-engineer/model-selection-eval/SKILL|model-selection-eval]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
