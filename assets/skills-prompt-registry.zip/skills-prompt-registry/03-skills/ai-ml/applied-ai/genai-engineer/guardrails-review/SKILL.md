---
name: guardrails-review
description: Review an LLM feature for safety and abuse risks. Use before launching any user-facing Gen AI feature.
metadata:
  id: SK-GENAI-ENGINEER-guardrails-review
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: genai-engineer
  category: ai-ml/applied-ai
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/genai-engineer, category/ai-ml/applied-ai, status/seed]
aliases: [guardrails review]
---

# guardrails-review

## Steps

1. Test prompt injection via user input and retrieved content.
2. Check data exposure: system prompt, other users' data, secrets.
3. Check tool permissions follow least privilege.
4. Add input and output filters where needed.
5. Log and rate-limit.

## Done When

- [ ] Red-team set of 20 attacks run and recorded

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-GENAI-ENGINEER-guardrails-review | genai-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/applied-ai/genai-engineer/README|Gen AI Engineer skills]]
- Siblings: [[03-skills/ai-ml/applied-ai/genai-engineer/agent-tool-design/SKILL|agent-tool-design]], [[03-skills/ai-ml/applied-ai/genai-engineer/cost-latency-optimizer/SKILL|cost-latency-optimizer]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
