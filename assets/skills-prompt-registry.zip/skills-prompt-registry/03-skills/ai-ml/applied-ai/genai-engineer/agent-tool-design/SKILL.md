---
name: agent-tool-design
description: Design tools for an LLM agent or MCP server. Use when building agents or exposing an API to Claude.
metadata:
  id: SK-GENAI-ENGINEER-agent-tool-design
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: genai-engineer
  category: ai-ml/applied-ai
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/genai-engineer, category/ai-ml/applied-ai, status/seed]
aliases: [agent tool design]
---

# agent-tool-design

## Steps

1. List user intents the agent must serve.
2. Design few, well-scoped tools with clear names.
3. Write descriptions that say when to use and when not to.
4. Define JSON Schemas with enums and required fields.
5. Mark destructive tools for human approval.

## Done When

- [ ] Agent picks the right tool on 20 test intents

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-GENAI-ENGINEER-agent-tool-design | genai-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/applied-ai/genai-engineer/README|Gen AI Engineer skills]]
- Siblings: [[03-skills/ai-ml/applied-ai/genai-engineer/cost-latency-optimizer/SKILL|cost-latency-optimizer]], [[03-skills/ai-ml/applied-ai/genai-engineer/guardrails-review/SKILL|guardrails-review]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
