---
name: cost-latency-optimizer
description: Cut cost and latency of an LLM feature. Use when bills or response times exceed targets.
metadata:
  id: SK-GENAI-ENGINEER-cost-latency-optimizer
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: genai-engineer
  category: ai-ml/applied-ai
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/genai-engineer, category/ai-ml/applied-ai, status/seed]
aliases: [cost latency optimizer]
---

# cost-latency-optimizer

## Steps

1. Measure tokens and latency per call.
2. Enable prompt caching for stable prefixes.
3. Route simple requests to a smaller model.
4. Batch non-urgent work.
5. Stream responses to cut perceived latency.

## Done When

- [ ] Quality unchanged on the golden set

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-GENAI-ENGINEER-cost-latency-optimizer | genai-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/applied-ai/genai-engineer/README|Gen AI Engineer skills]]
- Siblings: [[03-skills/ai-ml/applied-ai/genai-engineer/agent-tool-design/SKILL|agent-tool-design]], [[03-skills/ai-ml/applied-ai/genai-engineer/guardrails-review/SKILL|guardrails-review]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
