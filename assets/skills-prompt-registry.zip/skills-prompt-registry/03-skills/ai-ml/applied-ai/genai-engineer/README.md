---
type: role-index
role: genai-engineer
category: ai-ml/applied-ai
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/genai-engineer, category/ai-ml/applied-ai]
aliases: [Gen AI Engineer]
updated: 2026-11-15
---

# Gen AI Engineer Skills

| Skill | Use it when | id |
|---|---|---|
| [agent-tool-design](./agent-tool-design/SKILL.md) | when building agents or exposing an API to Claude | SK-GENAI-ENGINEER-agent-tool-design |
| [guardrails-review](./guardrails-review/SKILL.md) | before launching any user-facing Gen AI feature | SK-GENAI-ENGINEER-guardrails-review |
| [cost-latency-optimizer](./cost-latency-optimizer/SKILL.md) | when bills or response times exceed targets | SK-GENAI-ENGINEER-cost-latency-optimizer |

## Links

- Up: [[03-skills/ai-ml/applied-ai/_index|ai-ml/applied-ai]]
