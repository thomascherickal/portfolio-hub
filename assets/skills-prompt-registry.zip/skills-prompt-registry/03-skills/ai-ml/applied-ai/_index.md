---
type: category-index
category: ai-ml/applied-ai
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, category/ai-ml/applied-ai]
parent: ai-ml
updated: 2026-11-15
---

# ai-ml/applied-ai

Building AI features, agents and evals.

- Up: [[03-skills/ai-ml/_index|ai-ml]]

## Roles

- [[03-skills/ai-ml/applied-ai/ai-engineer/README|AI Engineer]]
- [[03-skills/ai-ml/applied-ai/genai-engineer/README|Gen AI Engineer]]
