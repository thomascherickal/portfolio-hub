---
type: category-index
category: ai-ml
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, category/ai-ml]
parent: 03-skills
updated: 2026-11-15
---

# ai-ml

AI and machine learning engineering skills.

- Up: [[03-skills/README|Skills index]]

## Subcategories

- [[03-skills/ai-ml/applied-ai/_index|ai-ml/applied-ai]]: Building AI features, agents and evals
- [[03-skills/ai-ml/llm-systems/_index|ai-ml/llm-systems]]: LLM internals, retrieval and local inference
