---
name: chunking-strategy
description: Choose a chunking strategy for a corpus. Use when building or fixing a RAG index.
metadata:
  id: SK-RAG-ENGINEER-chunking-strategy
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: rag-engineer
  category: ai-ml/llm-systems
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/rag-engineer, category/ai-ml/llm-systems, status/seed]
aliases: [chunking strategy]
---

# chunking-strategy

## Steps

1. Profile documents: length, structure, formats.
2. Start with structure-aware chunks (headings, sections).
3. Test 2 or 3 chunk sizes and overlaps on a retrieval eval.
4. Attach metadata: source, section, date.

## Done When

- [ ] Choice backed by recall numbers

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-RAG-ENGINEER-chunking-strategy | rag-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/llm-systems/rag-engineer/README|RAG Engineer skills]]
- Siblings: [[03-skills/ai-ml/llm-systems/rag-engineer/hybrid-search-rerank/SKILL|hybrid-search-rerank]], [[03-skills/ai-ml/llm-systems/rag-engineer/retrieval-eval/SKILL|retrieval-eval]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
