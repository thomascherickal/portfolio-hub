---
type: role-index
role: rag-engineer
category: ai-ml/llm-systems
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/rag-engineer, category/ai-ml/llm-systems]
aliases: [RAG Engineer]
updated: 2026-11-15
---

# RAG Engineer Skills

| Skill | Use it when | id |
|---|---|---|
| [chunking-strategy](./chunking-strategy/SKILL.md) | when building or fixing a RAG index | SK-RAG-ENGINEER-chunking-strategy |
| [retrieval-eval](./retrieval-eval/SKILL.md) | before changing embeddings, chunking or rerankers | SK-RAG-ENGINEER-retrieval-eval |
| [hybrid-search-rerank](./hybrid-search-rerank/SKILL.md) | when pure vector search misses exact terms or ranks poorly | SK-RAG-ENGINEER-hybrid-search-rerank |

## Links

- Up: [[03-skills/ai-ml/llm-systems/_index|ai-ml/llm-systems]]
