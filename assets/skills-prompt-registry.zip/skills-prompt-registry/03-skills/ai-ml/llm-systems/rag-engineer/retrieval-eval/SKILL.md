---
name: retrieval-eval
description: Evaluate retrieval quality. Use before changing embeddings, chunking or rerankers.
metadata:
  id: SK-RAG-ENGINEER-retrieval-eval
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: rag-engineer
  category: ai-ml/llm-systems
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/rag-engineer, category/ai-ml/llm-systems, status/seed]
aliases: [retrieval eval]
---

# retrieval-eval

## Steps

1. Build 50+ question/relevant-chunk pairs.
2. Measure recall@k and MRR.
3. Measure answer faithfulness separately from retrieval.
4. Track results per change in a table.

## Done When

- [ ] Baseline recorded before any change

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-RAG-ENGINEER-retrieval-eval | rag-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/llm-systems/rag-engineer/README|RAG Engineer skills]]
- Siblings: [[03-skills/ai-ml/llm-systems/rag-engineer/chunking-strategy/SKILL|chunking-strategy]], [[03-skills/ai-ml/llm-systems/rag-engineer/hybrid-search-rerank/SKILL|hybrid-search-rerank]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
