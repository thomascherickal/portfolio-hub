---
name: hybrid-search-rerank
description: Add hybrid search and reranking. Use when pure vector search misses exact terms or ranks poorly.
metadata:
  id: SK-RAG-ENGINEER-hybrid-search-rerank
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: rag-engineer
  category: ai-ml/llm-systems
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/rag-engineer, category/ai-ml/llm-systems, status/seed]
aliases: [hybrid search rerank]
---

# hybrid-search-rerank

## Steps

1. Add BM25 alongside vector search.
2. Fuse results with reciprocal rank fusion.
3. Rerank the top 20 to 50 with a cross-encoder.
4. Re-run retrieval-eval and compare.

## Done When

- [ ] Recall@k improves on the eval set

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-RAG-ENGINEER-hybrid-search-rerank | rag-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/llm-systems/rag-engineer/README|RAG Engineer skills]]
- Siblings: [[03-skills/ai-ml/llm-systems/rag-engineer/chunking-strategy/SKILL|chunking-strategy]], [[03-skills/ai-ml/llm-systems/rag-engineer/retrieval-eval/SKILL|retrieval-eval]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
