---
type: role-index
role: llm-engineer
category: ai-ml/llm-systems
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/llm-engineer, category/ai-ml/llm-systems]
aliases: [LLM Engineer]
updated: 2026-11-15
---

# LLM Engineer Skills

| Skill | Use it when | id |
|---|---|---|
| [finetune-data-prep](./finetune-data-prep/SKILL.md) | when building JSONL training data or diagnosing a bad fine-tune | SK-LLM-ENGINEER-finetune-data-prep |
| [context-budgeting](./context-budgeting/SKILL.md) | when prompts approach the context limit or costs spike | SK-LLM-ENGINEER-context-budgeting |
| [structured-output](./structured-output/SKILL.md) | when downstream code parses model output | SK-LLM-ENGINEER-structured-output |

## Links

- Up: [[03-skills/ai-ml/llm-systems/_index|ai-ml/llm-systems]]
