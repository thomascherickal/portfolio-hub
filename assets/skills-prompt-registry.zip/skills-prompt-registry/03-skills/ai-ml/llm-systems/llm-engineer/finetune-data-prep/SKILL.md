---
name: finetune-data-prep
description: Prepare and audit a dataset for supervised fine-tuning or LoRA. Use when building JSONL training data or diagnosing a bad fine-tune.
metadata:
  id: SK-LLM-ENGINEER-finetune-data-prep
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: llm-engineer
  category: ai-ml/llm-systems
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/llm-engineer, category/ai-ml/llm-systems, status/seed]
aliases: [finetune data prep]
---

# finetune-data-prep

## Steps

1. Validate schema of every record.
2. Deduplicate exact and near-duplicate examples.
3. Scan for PII and secrets; remove or mask.
4. Check label and length distributions.
5. Split train/validation with no leakage.

## Done When

- [ ] No duplicates across splits
- [ ] PII scan report attached

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-LLM-ENGINEER-finetune-data-prep | llm-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/llm-systems/llm-engineer/README|LLM Engineer skills]]
- Siblings: [[03-skills/ai-ml/llm-systems/llm-engineer/context-budgeting/SKILL|context-budgeting]], [[03-skills/ai-ml/llm-systems/llm-engineer/structured-output/SKILL|structured-output]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
