---
name: structured-output
description: Force reliable JSON or schema-conformant output. Use when downstream code parses model output.
metadata:
  id: SK-LLM-ENGINEER-structured-output
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: llm-engineer
  category: ai-ml/llm-systems
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/llm-engineer, category/ai-ml/llm-systems, status/seed]
aliases: [structured output]
---

# structured-output

## Steps

1. Define a JSON Schema.
2. Use the API's structured output or tool-call mode where available.
3. Validate every response; retry once with the validation error.
4. Log failures for prompt fixes.

## Done When

- [ ] 100 percent schema validity on the golden set

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-LLM-ENGINEER-structured-output | llm-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/llm-systems/llm-engineer/README|LLM Engineer skills]]
- Siblings: [[03-skills/ai-ml/llm-systems/llm-engineer/context-budgeting/SKILL|context-budgeting]], [[03-skills/ai-ml/llm-systems/llm-engineer/finetune-data-prep/SKILL|finetune-data-prep]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
