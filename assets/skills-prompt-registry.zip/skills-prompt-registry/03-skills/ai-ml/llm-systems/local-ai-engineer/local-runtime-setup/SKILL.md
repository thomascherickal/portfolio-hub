---
name: local-runtime-setup
description: Set up a local inference runtime. Use when installing Ollama, llama.cpp or LM Studio, or exposing an OpenAI-compatible endpoint.
metadata:
  id: SK-LOCAL-AI-ENGINEER-local-runtime-setup
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: local-ai-engineer
  category: ai-ml/llm-systems
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/local-ai-engineer, category/ai-ml/llm-systems, status/seed]
aliases: [local runtime setup]
---

# local-runtime-setup

## Steps

1. Pick the runtime for the use case: Ollama for simplicity, llama.cpp for control, LM Studio for a GUI.
2. Install and pull the model.
3. Expose the OpenAI-compatible server on localhost.
4. Point the client or IDE tool at it and run a smoke test.
5. Document the start command and model file location.

## Done When

- [ ] Smoke-test request returns within the latency target

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-LOCAL-AI-ENGINEER-local-runtime-setup | local-ai-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/llm-systems/local-ai-engineer/README|Local AI Engineer skills]]
- Siblings: [[03-skills/ai-ml/llm-systems/local-ai-engineer/gguf-quant-selection/SKILL|gguf-quant-selection]], [[03-skills/ai-ml/llm-systems/local-ai-engineer/offline-privacy-check/SKILL|offline-privacy-check]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
