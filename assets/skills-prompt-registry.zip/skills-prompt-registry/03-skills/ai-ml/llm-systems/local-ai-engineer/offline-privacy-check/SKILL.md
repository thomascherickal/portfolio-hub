---
name: offline-privacy-check
description: Verify a local AI setup keeps data on-device. Use when privacy or compliance requires no data egress.
metadata:
  id: SK-LOCAL-AI-ENGINEER-offline-privacy-check
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: local-ai-engineer
  category: ai-ml/llm-systems
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/local-ai-engineer, category/ai-ml/llm-systems, status/seed]
aliases: [offline privacy check]
---

# offline-privacy-check

## Steps

1. List every process and port the stack opens.
2. Block outbound traffic and confirm the workflow still works.
3. Disable telemetry in each tool.
4. Record the verification steps for audit.

## Done When

- [ ] Workflow passes with network disabled

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-LOCAL-AI-ENGINEER-offline-privacy-check | local-ai-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/llm-systems/local-ai-engineer/README|Local AI Engineer skills]]
- Siblings: [[03-skills/ai-ml/llm-systems/local-ai-engineer/gguf-quant-selection/SKILL|gguf-quant-selection]], [[03-skills/ai-ml/llm-systems/local-ai-engineer/local-runtime-setup/SKILL|local-runtime-setup]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
