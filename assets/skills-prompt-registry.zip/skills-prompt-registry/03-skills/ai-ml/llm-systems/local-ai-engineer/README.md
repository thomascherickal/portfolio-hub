---
type: role-index
role: local-ai-engineer
category: ai-ml/llm-systems
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/local-ai-engineer, category/ai-ml/llm-systems]
aliases: [Local AI Engineer]
updated: 2026-11-15
---

# Local AI Engineer Skills

| Skill | Use it when | id |
|---|---|---|
| [gguf-quant-selection](./gguf-quant-selection/SKILL.md) | when deploying an LLM on a laptop, workstation or edge device | SK-LOCAL-AI-ENGINEER-gguf-quant-selection |
| [local-runtime-setup](./local-runtime-setup/SKILL.md) | when installing Ollama, llama.cpp or LM Studio, or exposing an OpenAI-compatible endpoint | SK-LOCAL-AI-ENGINEER-local-runtime-setup |
| [offline-privacy-check](./offline-privacy-check/SKILL.md) | when privacy or compliance requires no data egress | SK-LOCAL-AI-ENGINEER-offline-privacy-check |

## Links

- Up: [[03-skills/ai-ml/llm-systems/_index|ai-ml/llm-systems]]
