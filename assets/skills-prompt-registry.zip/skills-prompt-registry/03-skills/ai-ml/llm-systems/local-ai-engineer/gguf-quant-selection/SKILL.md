---
name: gguf-quant-selection
description: Pick a model size and GGUF quantisation for given hardware. Use when deploying an LLM on a laptop, workstation or edge device.
metadata:
  id: SK-LOCAL-AI-ENGINEER-gguf-quant-selection
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: local-ai-engineer
  category: ai-ml/llm-systems
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/local-ai-engineer, category/ai-ml/llm-systems, status/seed]
aliases: [gguf quant selection]
---

# gguf-quant-selection

## Steps

1. Record RAM, VRAM, CPU and target context length.
2. Estimate weight memory: params x bits / 8, plus KV cache and overhead.
3. Shortlist quantisations (e.g. Q4_K_M, Q5_K_M, Q8_0) that fit.
4. Benchmark tokens per second and quality on a small task set.
5. Recommend one model and quant with the numbers.

## Done When

- [ ] Recommendation fits memory with headroom

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-LOCAL-AI-ENGINEER-gguf-quant-selection | local-ai-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/ai-ml/llm-systems/local-ai-engineer/README|Local AI Engineer skills]]
- Siblings: [[03-skills/ai-ml/llm-systems/local-ai-engineer/local-runtime-setup/SKILL|local-runtime-setup]], [[03-skills/ai-ml/llm-systems/local-ai-engineer/offline-privacy-check/SKILL|offline-privacy-check]]
- Frameworks: [[02-frameworks/react|react]], [[02-frameworks/few-shot|few-shot]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
