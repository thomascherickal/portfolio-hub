---
type: category-index
category: ai-ml/llm-systems
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, category/ai-ml/llm-systems]
parent: ai-ml
updated: 2026-11-15
---

# ai-ml/llm-systems

LLM internals, retrieval and local inference.

- Up: [[03-skills/ai-ml/_index|ai-ml]]

## Roles

- [[03-skills/ai-ml/llm-systems/llm-engineer/README|LLM Engineer]]
- [[03-skills/ai-ml/llm-systems/rag-engineer/README|RAG Engineer]]
- [[03-skills/ai-ml/llm-systems/local-ai-engineer/README|Local AI Engineer]]
