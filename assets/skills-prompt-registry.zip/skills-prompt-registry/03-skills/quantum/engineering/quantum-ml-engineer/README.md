---
type: role-index
role: quantum-ml-engineer
category: quantum/engineering
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/quantum-ml-engineer, category/quantum/engineering]
aliases: [Quantum ML/AI Engineer]
updated: 2026-11-15
---

# Quantum ML/AI Engineer Skills

| Skill | Use it when | id |
|---|---|---|
| [variational-qml-model](./variational-qml-model/SKILL.md) | for quantum classifiers, regressors or QNNs | SK-QUANTUM-ML-ENGINEER-variational-qml-model |
| [quantum-kernel-methods](./quantum-kernel-methods/SKILL.md) | when testing quantum feature maps | SK-QUANTUM-ML-ENGINEER-quantum-kernel-methods |
| [classical-baseline-check](./classical-baseline-check/SKILL.md) | before claiming any quantum advantage | SK-QUANTUM-ML-ENGINEER-classical-baseline-check |

## Links

- Up: [[03-skills/quantum/engineering/_index|quantum/engineering]]
