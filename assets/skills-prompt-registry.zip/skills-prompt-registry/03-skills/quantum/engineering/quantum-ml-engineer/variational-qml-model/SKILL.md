---
name: variational-qml-model
description: Build a variational quantum model (parameterised quantum circuit). Use for quantum classifiers, regressors or QNNs.
metadata:
  id: SK-QUANTUM-ML-ENGINEER-variational-qml-model
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: quantum-ml-engineer
  category: quantum/engineering
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/quantum-ml-engineer, category/quantum/engineering, status/seed]
aliases: [variational qml model]
---

# variational-qml-model

## Steps

1. Choose a data encoding and ansatz suited to the qubit budget.
2. Check gradient variance early for barren plateaus.
3. Train with a hybrid classical optimiser.
4. Track loss, accuracy and circuit evaluations.

## Done When

- [ ] Gradient variance check recorded
- [ ] Training reproducible from a seed

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-QUANTUM-ML-ENGINEER-variational-qml-model | quantum-ml-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/quantum/engineering/quantum-ml-engineer/README|Quantum ML/AI Engineer skills]]
- Siblings: [[03-skills/quantum/engineering/quantum-ml-engineer/classical-baseline-check/SKILL|classical-baseline-check]], [[03-skills/quantum/engineering/quantum-ml-engineer/quantum-kernel-methods/SKILL|quantum-kernel-methods]]
- Frameworks: [[02-frameworks/chain-of-thought|chain-of-thought]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]]
- Tests: [[00-setup/testing-guide|testing guide]]
