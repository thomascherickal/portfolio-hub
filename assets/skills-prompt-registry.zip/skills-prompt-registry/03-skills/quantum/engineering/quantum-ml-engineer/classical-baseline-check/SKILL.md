---
name: classical-baseline-check
description: Compare every quantum ML result with strong classical baselines. Use before claiming any quantum advantage.
metadata:
  id: SK-QUANTUM-ML-ENGINEER-classical-baseline-check
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: quantum-ml-engineer
  category: quantum/engineering
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/quantum-ml-engineer, category/quantum/engineering, status/seed]
aliases: [classical baseline check]
---

# classical-baseline-check

## Steps

1. Run tuned classical models on identical data splits.
2. Match parameter count or compute budget where meaningful.
3. Report all results with confidence intervals.
4. State plainly if classical wins.

## Done When

- [ ] At least two classical baselines
- [ ] No advantage claim without beating them

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-QUANTUM-ML-ENGINEER-classical-baseline-check | quantum-ml-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/quantum/engineering/quantum-ml-engineer/README|Quantum ML/AI Engineer skills]]
- Siblings: [[03-skills/quantum/engineering/quantum-ml-engineer/quantum-kernel-methods/SKILL|quantum-kernel-methods]], [[03-skills/quantum/engineering/quantum-ml-engineer/variational-qml-model/SKILL|variational-qml-model]]
- Frameworks: [[02-frameworks/chain-of-thought|chain-of-thought]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]]
- Tests: [[00-setup/testing-guide|testing guide]]
