---
type: role-index
role: quantum-computing-engineer
category: quantum/engineering
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/quantum-computing-engineer, category/quantum/engineering]
aliases: [Quantum Computing Engineer]
updated: 2026-11-15
---

# Quantum Computing Engineer Skills

| Skill | Use it when | id |
|---|---|---|
| [quantum-circuit-design](./quantum-circuit-design/SKILL.md) | when building a circuit for a simulator or real QPU | SK-QUANTUM-COMPUTING-ENGINEER-quantum-circuit-design |
| [noise-mitigation](./noise-mitigation/SKILL.md) | when hardware results drift from simulation | SK-QUANTUM-COMPUTING-ENGINEER-noise-mitigation |
| [qpu-benchmark](./qpu-benchmark/SKILL.md) | when choosing a backend or reporting results | SK-QUANTUM-COMPUTING-ENGINEER-qpu-benchmark |

## Links

- Up: [[03-skills/quantum/engineering/_index|quantum/engineering]]
