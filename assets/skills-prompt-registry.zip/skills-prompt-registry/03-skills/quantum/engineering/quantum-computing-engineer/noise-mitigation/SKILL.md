---
name: noise-mitigation
description: Apply error mitigation to noisy quantum results. Use when hardware results drift from simulation.
metadata:
  id: SK-QUANTUM-COMPUTING-ENGINEER-noise-mitigation
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: quantum-computing-engineer
  category: quantum/engineering
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/quantum-computing-engineer, category/quantum/engineering, status/seed]
aliases: [noise mitigation]
---

# noise-mitigation

## Steps

1. Characterise readout error and apply readout mitigation.
2. Try zero-noise extrapolation on key observables.
3. Add dynamical decoupling on idle qubits.
4. Compare mitigated, unmitigated and ideal results.

## Done When

- [ ] Improvement measured, not assumed

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-QUANTUM-COMPUTING-ENGINEER-noise-mitigation | quantum-computing-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/quantum/engineering/quantum-computing-engineer/README|Quantum Computing Engineer skills]]
- Siblings: [[03-skills/quantum/engineering/quantum-computing-engineer/qpu-benchmark/SKILL|qpu-benchmark]], [[03-skills/quantum/engineering/quantum-computing-engineer/quantum-circuit-design/SKILL|quantum-circuit-design]]
- Frameworks: [[02-frameworks/chain-of-thought|chain-of-thought]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]]
- Tests: [[00-setup/testing-guide|testing guide]]
