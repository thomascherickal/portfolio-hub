---
name: qpu-benchmark
description: Benchmark a workload across simulators and quantum hardware. Use when choosing a backend or reporting results.
metadata:
  id: SK-QUANTUM-COMPUTING-ENGINEER-qpu-benchmark
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: quantum-computing-engineer
  category: quantum/engineering
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/quantum-computing-engineer, category/quantum/engineering, status/seed]
aliases: [qpu benchmark]
---

# qpu-benchmark

## Steps

1. Fix circuits, shots and seeds.
2. Run on a noiseless simulator, a noisy simulator and hardware.
3. Report fidelity, success probability, queue time and cost.
4. Note calibration date of the hardware.

## Done When

- [ ] Every number tagged with backend and date

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-QUANTUM-COMPUTING-ENGINEER-qpu-benchmark | quantum-computing-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/quantum/engineering/quantum-computing-engineer/README|Quantum Computing Engineer skills]]
- Siblings: [[03-skills/quantum/engineering/quantum-computing-engineer/noise-mitigation/SKILL|noise-mitigation]], [[03-skills/quantum/engineering/quantum-computing-engineer/quantum-circuit-design/SKILL|quantum-circuit-design]]
- Frameworks: [[02-frameworks/chain-of-thought|chain-of-thought]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]]
- Tests: [[00-setup/testing-guide|testing guide]]
