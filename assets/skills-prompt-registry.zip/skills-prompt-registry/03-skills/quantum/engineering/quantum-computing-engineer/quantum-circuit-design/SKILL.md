---
name: quantum-circuit-design
description: Design and optimise quantum circuits in Qiskit, Cirq or PennyLane. Use when building a circuit for a simulator or real QPU.
metadata:
  id: SK-QUANTUM-COMPUTING-ENGINEER-quantum-circuit-design
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: quantum-computing-engineer
  category: quantum/engineering
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/quantum-computing-engineer, category/quantum/engineering, status/seed]
aliases: [quantum circuit design]
---

# quantum-circuit-design

## Steps

1. State the problem and the qubit encoding.
2. Build the circuit and check it on a statevector simulator.
3. Transpile for the target backend's native gates and coupling map.
4. Minimise depth and two-qubit gate count.
5. Record depth, gate counts and expected fidelity.

## Done When

- [ ] Simulator output matches the expected distribution
- [ ] Transpiled depth recorded

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-QUANTUM-COMPUTING-ENGINEER-quantum-circuit-design | quantum-computing-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/quantum/engineering/quantum-computing-engineer/README|Quantum Computing Engineer skills]]
- Siblings: [[03-skills/quantum/engineering/quantum-computing-engineer/noise-mitigation/SKILL|noise-mitigation]], [[03-skills/quantum/engineering/quantum-computing-engineer/qpu-benchmark/SKILL|qpu-benchmark]]
- Frameworks: [[02-frameworks/chain-of-thought|chain-of-thought]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]]
- Tests: [[00-setup/testing-guide|testing guide]]
