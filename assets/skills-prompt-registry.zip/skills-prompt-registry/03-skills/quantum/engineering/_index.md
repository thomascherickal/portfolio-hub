---
type: category-index
category: quantum/engineering
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, category/quantum/engineering]
parent: quantum
updated: 2026-11-15
---

# quantum/engineering

Quantum circuits, hardware and quantum ML.

- Up: [[03-skills/quantum/_index|quantum]]

## Roles

- [[03-skills/quantum/engineering/quantum-computing-engineer/README|Quantum Computing Engineer]]
- [[03-skills/quantum/engineering/quantum-ml-engineer/README|Quantum ML/AI Engineer]]
