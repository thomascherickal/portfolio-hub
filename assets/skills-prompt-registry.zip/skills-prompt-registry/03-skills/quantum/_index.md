---
type: category-index
category: quantum
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, category/quantum]
parent: 03-skills
updated: 2026-11-15
---

# quantum

Quantum computing engineering and research.

- Up: [[03-skills/README|Skills index]]

## Subcategories

- [[03-skills/quantum/engineering/_index|quantum/engineering]]: Quantum circuits, hardware and quantum ML
- [[03-skills/quantum/research/_index|quantum/research]]: Quantum algorithms and research tracking
