---
name: resource-estimation
description: Estimate resources for a quantum algorithm. Use when assessing feasibility on future fault-tolerant hardware.
metadata:
  id: SK-QUANTUM-COMPUTING-RESEARCHER-resource-estimation
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: quantum-computing-researcher
  category: quantum/research
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/quantum-computing-researcher, category/quantum/research, status/seed]
aliases: [resource estimation]
---

# resource-estimation

## Steps

1. Count logical qubits, T gates and depth.
2. Choose an error-correction code and physical error rate.
3. Estimate physical qubits and run time.
4. Compare with best known classical methods.

## Done When

- [ ] Assumptions listed

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-QUANTUM-COMPUTING-RESEARCHER-resource-estimation | quantum-computing-researcher | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/quantum/research/quantum-computing-researcher/README|Quantum Computing Researcher skills]]
- Siblings: [[03-skills/quantum/research/quantum-computing-researcher/quant-ph-tracking/SKILL|quant-ph-tracking]], [[03-skills/quantum/research/quantum-computing-researcher/quantum-paper-reproduction/SKILL|quantum-paper-reproduction]]
- Frameworks: [[02-frameworks/chain-of-thought|chain-of-thought]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]]
- Tests: [[00-setup/testing-guide|testing guide]]
