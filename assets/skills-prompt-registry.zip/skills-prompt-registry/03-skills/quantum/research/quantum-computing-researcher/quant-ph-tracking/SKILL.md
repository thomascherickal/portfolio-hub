---
name: quant-ph-tracking
description: Track new research on arXiv quant-ph. Use for weekly research monitoring.
metadata:
  id: SK-QUANTUM-COMPUTING-RESEARCHER-quant-ph-tracking
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: quantum-computing-researcher
  category: quantum/research
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/quantum-computing-researcher, category/quantum/research, status/seed]
aliases: [quant ph tracking]
---

# quant-ph-tracking

## Steps

1. Query arXiv quant-ph for the week's keywords.
2. Triage papers into read, skim and skip.
3. Summarise key claims of read papers.
4. Link each to the second brain notes.

## Done When

- [ ] Weekly note filed

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-QUANTUM-COMPUTING-RESEARCHER-quant-ph-tracking | quantum-computing-researcher | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/quantum/research/quantum-computing-researcher/README|Quantum Computing Researcher skills]]
- Siblings: [[03-skills/quantum/research/quantum-computing-researcher/quantum-paper-reproduction/SKILL|quantum-paper-reproduction]], [[03-skills/quantum/research/quantum-computing-researcher/resource-estimation/SKILL|resource-estimation]]
- Frameworks: [[02-frameworks/chain-of-thought|chain-of-thought]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]]
- Tests: [[00-setup/testing-guide|testing guide]]
