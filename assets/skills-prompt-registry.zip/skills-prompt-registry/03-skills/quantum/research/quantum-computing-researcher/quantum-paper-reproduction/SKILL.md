---
name: quantum-paper-reproduction
description: Reproduce results from a quantum computing paper. Use when validating or extending published work.
metadata:
  id: SK-QUANTUM-COMPUTING-RESEARCHER-quantum-paper-reproduction
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: quantum-computing-researcher
  category: quantum/research
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/quantum-computing-researcher, category/quantum/research, status/seed]
aliases: [quantum paper reproduction]
---

# quantum-paper-reproduction

## Steps

1. Extract circuits, parameters and noise models from the paper.
2. Rebuild in Qiskit, Cirq or PennyLane.
3. Compare results to the paper's figures.
4. Document every discrepancy.

## Done When

- [ ] Discrepancies explained or flagged

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-QUANTUM-COMPUTING-RESEARCHER-quantum-paper-reproduction | quantum-computing-researcher | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/quantum/research/quantum-computing-researcher/README|Quantum Computing Researcher skills]]
- Siblings: [[03-skills/quantum/research/quantum-computing-researcher/quant-ph-tracking/SKILL|quant-ph-tracking]], [[03-skills/quantum/research/quantum-computing-researcher/resource-estimation/SKILL|resource-estimation]]
- Frameworks: [[02-frameworks/chain-of-thought|chain-of-thought]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]]
- Tests: [[00-setup/testing-guide|testing guide]]
