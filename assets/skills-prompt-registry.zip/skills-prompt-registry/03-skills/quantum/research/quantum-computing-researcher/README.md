---
type: role-index
role: quantum-computing-researcher
category: quantum/research
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/quantum-computing-researcher, category/quantum/research]
aliases: [Quantum Computing Researcher]
updated: 2026-11-15
---

# Quantum Computing Researcher Skills

| Skill | Use it when | id |
|---|---|---|
| [quantum-paper-reproduction](./quantum-paper-reproduction/SKILL.md) | when validating or extending published work | SK-QUANTUM-COMPUTING-RESEARCHER-quantum-paper-reproduction |
| [resource-estimation](./resource-estimation/SKILL.md) | when assessing feasibility on future fault-tolerant hardware | SK-QUANTUM-COMPUTING-RESEARCHER-resource-estimation |
| [quant-ph-tracking](./quant-ph-tracking/SKILL.md) | for weekly research monitoring | SK-QUANTUM-COMPUTING-RESEARCHER-quant-ph-tracking |

## Links

- Up: [[03-skills/quantum/research/_index|quantum/research]]
