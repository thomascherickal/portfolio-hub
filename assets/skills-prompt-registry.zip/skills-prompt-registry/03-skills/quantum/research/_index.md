---
type: category-index
category: quantum/research
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, category/quantum/research]
parent: quantum
updated: 2026-11-15
---

# quantum/research

Quantum algorithms and research tracking.

- Up: [[03-skills/quantum/_index|quantum]]

## Roles

- [[03-skills/quantum/research/quantum-computing-researcher/README|Quantum Computing Researcher]]
