---
name: smart-contract-audit
description: Audit Solidity smart contracts. Use before deploying or upgrading any contract.
metadata:
  id: SK-BLOCKCHAIN-DEFI-ENGINEER-smart-contract-audit
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: blockchain-defi-engineer
  category: web3
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/blockchain-defi-engineer, category/web3, status/seed]
aliases: [smart contract audit]
---

# smart-contract-audit

## Steps

1. Run Slither and fix or justify each finding.
2. Check reentrancy, access control, integer and rounding issues.
3. Write Foundry fuzz and invariant tests.
4. Review upgradeability and storage layout.
5. List residual risks for an external audit.

## Done When

- [ ] Invariant tests pass
- [ ] Every high finding resolved

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-BLOCKCHAIN-DEFI-ENGINEER-smart-contract-audit | blockchain-defi-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/web3/blockchain-defi-engineer/README|Blockchain, DeFi and Web3 Engineer skills]]
- Siblings: [[03-skills/web3/blockchain-defi-engineer/defi-protocol-risk/SKILL|defi-protocol-risk]], [[03-skills/web3/blockchain-defi-engineer/web3-dapp-integration/SKILL|web3-dapp-integration]]
- Frameworks: [[02-frameworks/tidd-ec|tidd-ec]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
