---
name: web3-dapp-integration
description: Integrate a front end with wallets and contracts. Use when building a dApp UI.
metadata:
  id: SK-BLOCKCHAIN-DEFI-ENGINEER-web3-dapp-integration
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: blockchain-defi-engineer
  category: web3
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/blockchain-defi-engineer, category/web3, status/seed]
aliases: [web3 dapp integration]
---

# web3-dapp-integration

## Steps

1. Connect wallets with a standard library (viem, wagmi or ethers).
2. Handle chain switching and wrong-network states.
3. Show transaction states: pending, confirmed, failed.
4. Never request more approval than needed.

## Done When

- [ ] Works on testnet end to end

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-BLOCKCHAIN-DEFI-ENGINEER-web3-dapp-integration | blockchain-defi-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/web3/blockchain-defi-engineer/README|Blockchain, DeFi and Web3 Engineer skills]]
- Siblings: [[03-skills/web3/blockchain-defi-engineer/defi-protocol-risk/SKILL|defi-protocol-risk]], [[03-skills/web3/blockchain-defi-engineer/smart-contract-audit/SKILL|smart-contract-audit]]
- Frameworks: [[02-frameworks/tidd-ec|tidd-ec]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
