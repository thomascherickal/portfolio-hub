---
name: defi-protocol-risk
description: Assess economic and protocol risk in a DeFi design. Use for lending, AMM, vault or bridge work.
metadata:
  id: SK-BLOCKCHAIN-DEFI-ENGINEER-defi-protocol-risk
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: blockchain-defi-engineer
  category: web3
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/blockchain-defi-engineer, category/web3, status/seed]
aliases: [defi protocol risk]
---

# defi-protocol-risk

## Steps

1. Map oracle sources and manipulation paths.
2. Model flash-loan attack scenarios.
3. Stress-test liquidation and price-shock cases.
4. Review admin keys, timelocks and pause controls.

## Done When

- [ ] Each risk has a mitigation or owner

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-BLOCKCHAIN-DEFI-ENGINEER-defi-protocol-risk | blockchain-defi-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/web3/blockchain-defi-engineer/README|Blockchain, DeFi and Web3 Engineer skills]]
- Siblings: [[03-skills/web3/blockchain-defi-engineer/smart-contract-audit/SKILL|smart-contract-audit]], [[03-skills/web3/blockchain-defi-engineer/web3-dapp-integration/SKILL|web3-dapp-integration]]
- Frameworks: [[02-frameworks/tidd-ec|tidd-ec]], [[02-frameworks/risen|risen]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
