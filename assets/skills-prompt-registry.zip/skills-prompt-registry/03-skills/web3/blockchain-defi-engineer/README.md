---
type: role-index
role: blockchain-defi-engineer
category: web3
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/blockchain-defi-engineer, category/web3]
aliases: [Blockchain, DeFi and Web3 Engineer]
updated: 2026-11-15
---

# Blockchain, DeFi and Web3 Engineer Skills

| Skill | Use it when | id |
|---|---|---|
| [smart-contract-audit](./smart-contract-audit/SKILL.md) | before deploying or upgrading any contract | SK-BLOCKCHAIN-DEFI-ENGINEER-smart-contract-audit |
| [defi-protocol-risk](./defi-protocol-risk/SKILL.md) | for lending, AMM, vault or bridge work | SK-BLOCKCHAIN-DEFI-ENGINEER-defi-protocol-risk |
| [web3-dapp-integration](./web3-dapp-integration/SKILL.md) | when building a dApp UI | SK-BLOCKCHAIN-DEFI-ENGINEER-web3-dapp-integration |

## Links

- Up: [[03-skills/web3/_index|web3]]
