---
type: category-index
category: web3
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, category/web3]
parent: 03-skills
updated: 2026-11-15
---

# web3

Blockchain, DeFi and Web3 engineering.

- Up: [[03-skills/README|Skills index]]

## Roles

- [[03-skills/web3/blockchain-defi-engineer/README|Blockchain, DeFi and Web3 Engineer]]
