---
type: category-index
category: software-engineering
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, category/software-engineering]
parent: 03-skills
updated: 2026-11-15
---

# software-engineering

Core software engineering skills.

- Up: [[03-skills/README|Skills index]]

## Subcategories

- [[03-skills/software-engineering/application/_index|software-engineering/application]]: Back-end, front-end, full-stack and PWA skills
- [[03-skills/software-engineering/general/_index|software-engineering/general]]: Language-agnostic engineering practice
- [[03-skills/software-engineering/languages/_index|software-engineering/languages]]: Language-specific engineering skills
