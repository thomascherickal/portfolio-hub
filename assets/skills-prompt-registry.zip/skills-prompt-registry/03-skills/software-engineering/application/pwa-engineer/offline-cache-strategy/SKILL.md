---
name: offline-cache-strategy
description: Choose caching strategies for a PWA. Use when adding offline support.
metadata:
  id: SK-PWA-ENGINEER-offline-cache-strategy
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: pwa-engineer
  category: software-engineering/application
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/pwa-engineer, category/software-engineering/application, status/seed]
aliases: [offline cache strategy]
---

# offline-cache-strategy

## Steps

1. Precache the app shell on install.
2. Use cache-first for static assets, network-first for HTML and API data.
3. Version caches and delete old ones on activate.
4. Add an offline fallback page.

## Done When

- [ ] App shell loads with network disabled

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-PWA-ENGINEER-offline-cache-strategy | pwa-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/software-engineering/application/pwa-engineer/README|HTML-CSS-JS PWA Engineer skills]]
- Siblings: [[03-skills/software-engineering/application/pwa-engineer/pwa-manifest-sw/SKILL|pwa-manifest-sw]], [[03-skills/software-engineering/application/pwa-engineer/vanilla-js-component/SKILL|vanilla-js-component]]
- Frameworks: [[02-frameworks/rtf|rtf]], [[02-frameworks/tidd-ec|tidd-ec]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
