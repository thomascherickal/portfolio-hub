---
type: role-index
role: pwa-engineer
category: software-engineering/application
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/pwa-engineer, category/software-engineering/application]
aliases: [HTML-CSS-JS PWA Engineer]
updated: 2026-11-15
---

# HTML-CSS-JS PWA Engineer Skills

| Skill | Use it when | id |
|---|---|---|
| [pwa-manifest-sw](./pwa-manifest-sw/SKILL.md) | when converting a static HTML/CSS/JS site into a PWA | SK-PWA-ENGINEER-pwa-manifest-sw |
| [offline-cache-strategy](./offline-cache-strategy/SKILL.md) | when adding offline support | SK-PWA-ENGINEER-offline-cache-strategy |
| [vanilla-js-component](./vanilla-js-component/SKILL.md) | when a PWA must stay plain HTML, CSS and JS | SK-PWA-ENGINEER-vanilla-js-component |

## Links

- Up: [[03-skills/software-engineering/application/_index|software-engineering/application]]
