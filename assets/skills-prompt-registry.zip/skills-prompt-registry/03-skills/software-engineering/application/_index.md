---
type: category-index
category: software-engineering/application
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, category/software-engineering/application]
parent: software-engineering
updated: 2026-11-15
---

# software-engineering/application

Back-end, front-end, full-stack and PWA skills.

- Up: [[03-skills/software-engineering/_index|software-engineering]]

## Roles

- [[03-skills/software-engineering/application/backend-engineer/README|Back-End Engineer]]
- [[03-skills/software-engineering/application/frontend-engineer/README|Front-End Engineer]]
- [[03-skills/software-engineering/application/fullstack-engineer/README|Full-Stack Engineer]]
- [[03-skills/software-engineering/application/pwa-engineer/README|HTML-CSS-JS PWA Engineer]]
