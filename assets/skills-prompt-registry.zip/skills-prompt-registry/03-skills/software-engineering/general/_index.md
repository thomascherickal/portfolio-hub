---
type: category-index
category: software-engineering/general
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, category/software-engineering/general]
parent: software-engineering
updated: 2026-11-15
---

# software-engineering/general

Language-agnostic engineering practice.

- Up: [[03-skills/software-engineering/_index|software-engineering]]

## Roles

- [[03-skills/software-engineering/general/software-engineer/README|Software Engineer]]
