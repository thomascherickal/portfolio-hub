---
name: refactor-plan
description: Plan a safe refactor. Use before restructuring code that lacks tests or spans many files.
metadata:
  id: SK-SOFTWARE-ENGINEER-refactor-plan
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: software-engineer
  category: software-engineering/general
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/software-engineer, category/software-engineering/general, status/seed]
aliases: [refactor plan]
---

# refactor-plan

## Steps

1. Write characterisation tests around current behaviour.
2. Break the refactor into steps that each keep the build green.
3. Order steps to minimise merge conflicts.
4. Define the done criteria.

## Done When

- [ ] Each step is independently shippable

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-SOFTWARE-ENGINEER-refactor-plan | software-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/software-engineering/general/software-engineer/README|Software Engineer skills]]
- Siblings: [[03-skills/software-engineering/general/software-engineer/adr-writer/SKILL|adr-writer]], [[03-skills/software-engineering/general/software-engineer/code-review-checklist/SKILL|code-review-checklist]]
- Frameworks: [[02-frameworks/rtf|rtf]], [[02-frameworks/tidd-ec|tidd-ec]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
