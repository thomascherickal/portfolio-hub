---
name: code-review-checklist
description: Review any code change. Use on every PR when no language-specific review skill applies.
metadata:
  id: SK-SOFTWARE-ENGINEER-code-review-checklist
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: software-engineer
  category: software-engineering/general
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/software-engineer, category/software-engineering/general, status/seed]
aliases: [code review checklist]
---

# code-review-checklist

## Steps

1. Read the PR description and linked issue first.
2. Check correctness, then tests, then readability, then performance.
3. Look for missing error handling and edge cases.
4. Leave comments as must-fix, should-fix or nit.

## Done When

- [ ] Every must-fix has a concrete suggestion

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-SOFTWARE-ENGINEER-code-review-checklist | software-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/software-engineering/general/software-engineer/README|Software Engineer skills]]
- Siblings: [[03-skills/software-engineering/general/software-engineer/adr-writer/SKILL|adr-writer]], [[03-skills/software-engineering/general/software-engineer/refactor-plan/SKILL|refactor-plan]]
- Frameworks: [[02-frameworks/rtf|rtf]], [[02-frameworks/tidd-ec|tidd-ec]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
