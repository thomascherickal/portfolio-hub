---
type: role-index
role: software-engineer
category: software-engineering/general
owner: Thomas Cherickal
curator: Thomas Cherickal
tags: [moc, role/software-engineer, category/software-engineering/general]
aliases: [Software Engineer]
updated: 2026-11-15
---

# Software Engineer Skills

| Skill | Use it when | id |
|---|---|---|
| [code-review-checklist](./code-review-checklist/SKILL.md) | on every PR when no language-specific review skill applies | SK-SOFTWARE-ENGINEER-code-review-checklist |
| [adr-writer](./adr-writer/SKILL.md) | when a technical decision with lasting impact is made | SK-SOFTWARE-ENGINEER-adr-writer |
| [refactor-plan](./refactor-plan/SKILL.md) | before restructuring code that lacks tests or spans many files | SK-SOFTWARE-ENGINEER-refactor-plan |

## Links

- Up: [[03-skills/software-engineering/general/_index|software-engineering/general]]
