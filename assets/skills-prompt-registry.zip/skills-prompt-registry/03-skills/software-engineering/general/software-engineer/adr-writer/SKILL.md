---
name: adr-writer
description: Write an Architecture Decision Record. Use when a technical decision with lasting impact is made.
metadata:
  id: SK-SOFTWARE-ENGINEER-adr-writer
  type: skill
  owner: Thomas Cherickal
  curator: Thomas Cherickal
  role: software-engineer
  category: software-engineering/general
  version: 0.1.0
  status: seed
  created: 2026-11-15
  updated: 2026-11-15
tags: [skill, role/software-engineer, category/software-engineering/general, status/seed]
aliases: [adr writer]
---

# adr-writer

## Steps

1. State context and the forces at play.
2. List options considered with pros and cons.
3. Record the decision and its consequences.
4. Number and date the ADR; link superseded ADRs.

## Done When

- [ ] ADR is under one page

## Registry

| id | role | version | status | owner | last_tested |
|---|---|---|---|---|---|
| SK-SOFTWARE-ENGINEER-adr-writer | software-engineer | 0.1.0 | seed | Thomas Cherickal | - |

## Links

- Up: [[03-skills/software-engineering/general/software-engineer/README|Software Engineer skills]]
- Siblings: [[03-skills/software-engineering/general/software-engineer/code-review-checklist/SKILL|code-review-checklist]], [[03-skills/software-engineering/general/software-engineer/refactor-plan/SKILL|refactor-plan]]
- Frameworks: [[02-frameworks/rtf|rtf]], [[02-frameworks/tidd-ec|tidd-ec]], [[02-frameworks/xml-structured|xml-structured]], [[02-frameworks/chain-of-thought|chain-of-thought]]
- Tests: [[00-setup/testing-guide|testing guide]]
