---
type: moc
curator: Thomas Cherickal
collected: 2026-11-15
unique_skills: 366
role_listings: 390
source_repos: 20
tags: [moc, public-skill]
---

# Public Skills Directory

366 unique public skills from 20 GitHub repositories, giving 390 role listings across 22 roles. Each skill's **owner** is its original author on GitHub. **Curator** for every entry is Thomas Cherickal.

## How It Was Built

- Cloned the source repositories on 2026-11-15 and read the front matter of every `SKILL.md` (12,926 files).
- Removed duplicates by skill name and kept the copy from the most-starred repo; other copies are listed under `mirrors`.
- Assigned skills to roles by matching role terms in the skill name.
- Kept 10 to 20 per role, at most 5 per repo at first so one large collection does not fill a role.
- **Popularity = GitHub stars of the source repo** on 2026-11-15. GitHub has no per-skill star or install count, so skills from the same repo share a score.

## Caveats

- Listing is not endorsement. Read a skill before installing it; scanners such as NVIDIA SkillSpector exist for this.
- Several large repos re-publish skills from others. Check `mirrors` and the license before reuse.
- Quantum ML has few dedicated public skills; that role also lists supporting classical ML and interpretability skills.

## Entry Points

- By role: [[04-public-skills-directory/roles/ai-ml/_index|ai-ml]], [[04-public-skills-directory/roles/consulting/_index|consulting]], [[04-public-skills-directory/roles/design-and-content/_index|design-and-content]], [[04-public-skills-directory/roles/quantum/_index|quantum]], [[04-public-skills-directory/roles/research/_index|research]], [[04-public-skills-directory/roles/software-engineering/_index|software-engineering]], [[04-public-skills-directory/roles/web3/_index|web3]]
- [[04-public-skills-directory/all-skills|All skills, ranked]]
- [[04-public-skills-directory/sources/_index|Source repositories, ranked]]
- Up: [[README|Registry home]]

## Role Counts

| Role | Category | Skills |
|---|---|---|
| [[04-public-skills-directory/roles/ai-ml/applied-ai/ai-engineer|ai-engineer]] | ai-ml/applied-ai | 20 |
| [[04-public-skills-directory/roles/ai-ml/applied-ai/genai-engineer|genai-engineer]] | ai-ml/applied-ai | 20 |
| [[04-public-skills-directory/roles/ai-ml/llm-systems/llm-engineer|llm-engineer]] | ai-ml/llm-systems | 20 |
| [[04-public-skills-directory/roles/ai-ml/llm-systems/local-ai-engineer|local-ai-engineer]] | ai-ml/llm-systems | 20 |
| [[04-public-skills-directory/roles/ai-ml/llm-systems/rag-engineer|rag-engineer]] | ai-ml/llm-systems | 19 |
| [[04-public-skills-directory/roles/consulting/genai-consultant|genai-consultant]] | consulting | 13 |
| [[04-public-skills-directory/roles/design-and-content/technical-writer|technical-writer]] | design-and-content | 20 |
| [[04-public-skills-directory/roles/design-and-content/web-designer|web-designer]] | design-and-content | 14 |
| [[04-public-skills-directory/roles/quantum/engineering/quantum-computing-engineer|quantum-computing-engineer]] | quantum/engineering | 18 |
| [[04-public-skills-directory/roles/quantum/engineering/quantum-ml-engineer|quantum-ml-engineer]] | quantum/engineering | 11 |
| [[04-public-skills-directory/roles/quantum/research/quantum-computing-researcher|quantum-computing-researcher]] | quantum/research | 16 |
| [[04-public-skills-directory/roles/research/research-scientist|research-scientist]] | research | 19 |
| [[04-public-skills-directory/roles/research/industry-researcher|industry-researcher]] | research | 18 |
| [[04-public-skills-directory/roles/software-engineering/application/backend-engineer|backend-engineer]] | software-engineering/application | 20 |
| [[04-public-skills-directory/roles/software-engineering/application/frontend-engineer|frontend-engineer]] | software-engineering/application | 20 |
| [[04-public-skills-directory/roles/software-engineering/application/fullstack-engineer|fullstack-engineer]] | software-engineering/application | 18 |
| [[04-public-skills-directory/roles/software-engineering/application/pwa-engineer|pwa-engineer]] | software-engineering/application | 15 |
| [[04-public-skills-directory/roles/software-engineering/general/software-engineer|software-engineer]] | software-engineering/general | 20 |
| [[04-public-skills-directory/roles/software-engineering/languages/rust-engineer|rust-engineer]] | software-engineering/languages | 16 |
| [[04-public-skills-directory/roles/software-engineering/languages/python-engineer|python-engineer]] | software-engineering/languages | 20 |
| [[04-public-skills-directory/roles/software-engineering/languages/go-engineer|go-engineer]] | software-engineering/languages | 13 |
| [[04-public-skills-directory/roles/web3/blockchain-defi-engineer|blockchain-defi-engineer]] | web3 | 20 |
