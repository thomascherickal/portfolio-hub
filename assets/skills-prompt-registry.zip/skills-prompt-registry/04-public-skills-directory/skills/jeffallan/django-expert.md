---
type: public-skill
name: django-expert
owner: Jeffallan
curator: Thomas Cherickal
source_repo: jeffallan/claude-skills
source_url: https://github.com/Jeffallan/claude-skills/blob/HEAD/skills/django-expert/SKILL.md
repo_stars: 12361
license: MIT
repo_last_push: 2026-11-11
roles: [python-engineer]
categories: [software-engineering/languages]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/python-engineer, owner/jeffallan]
---

# django-expert

> Use when building Django web applications or REST APIs with Django REST Framework. Invoke when working with settings.py, models.py, manage.py, or any Django project file. Creates Django models with proper indexes, optimizes ORM queries using select_related/prefetch_related, builds DRF serializers and viewsets, and configures JWT authentication. Trigger terms: Django, DRF, Django REST Framework,...

| Field | Value |
|---|---|
| Owner | Jeffallan |
| Curator | Thomas Cherickal |
| Source | [jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills/blob/HEAD/skills/django-expert/SKILL.md) |
| Repo stars | 12,361 |
| License | MIT |
| Repo last push | 2026-11-11 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/languages/python-engineer|python-engineer]]
- Source repo: [[04-public-skills-directory/sources/jeffallan-claude-skills|jeffallan/claude-skills]]
- Same repo: [[04-public-skills-directory/skills/jeffallan/fine-tuning-expert|fine-tuning-expert]], [[04-public-skills-directory/skills/jeffallan/rust-engineer|rust-engineer]], [[04-public-skills-directory/skills/jeffallan/django-storages-s3|django-storages-s3]], [[04-public-skills-directory/skills/jeffallan/fastapi-expert|fastapi-expert]], [[04-public-skills-directory/skills/jeffallan/microservices-architect|microservices-architect]], [[04-public-skills-directory/skills/jeffallan/postgres-pro|postgres-pro]], [[04-public-skills-directory/skills/jeffallan/fullstack-guardian|fullstack-guardian]], [[04-public-skills-directory/skills/jeffallan/nextjs-developer|nextjs-developer]]
- Registry seed skills for this role: [[03-skills/software-engineering/languages/python-engineer/README|python-engineer seed skills]]
