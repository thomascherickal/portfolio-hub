---
type: public-skill
name: microservices-architect
owner: Jeffallan
curator: Thomas Cherickal
source_repo: jeffallan/claude-skills
source_url: https://github.com/Jeffallan/claude-skills/blob/HEAD/skills/microservices-architect/SKILL.md
repo_stars: 12361
license: MIT
repo_last_push: 2026-11-11
roles: [backend-engineer]
categories: [software-engineering/application]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/backend-engineer, owner/jeffallan]
---

# microservices-architect

> Designs distributed system architectures, decomposes monoliths into bounded-context services, recommends communication patterns, and produces service boundary diagrams and resilience strategies. Use when designing distributed systems, decomposing monoliths, or implementing microservices patterns — including service boundaries, DDD, saga patterns, event sourcing, CQRS, service mesh, or distributed...

| Field | Value |
|---|---|
| Owner | Jeffallan |
| Curator | Thomas Cherickal |
| Source | [jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills/blob/HEAD/skills/microservices-architect/SKILL.md) |
| Repo stars | 12,361 |
| License | MIT |
| Repo last push | 2026-11-11 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/application/backend-engineer|backend-engineer]]
- Source repo: [[04-public-skills-directory/sources/jeffallan-claude-skills|jeffallan/claude-skills]]
- Same repo: [[04-public-skills-directory/skills/jeffallan/fine-tuning-expert|fine-tuning-expert]], [[04-public-skills-directory/skills/jeffallan/rust-engineer|rust-engineer]], [[04-public-skills-directory/skills/jeffallan/django-expert|django-expert]], [[04-public-skills-directory/skills/jeffallan/django-storages-s3|django-storages-s3]], [[04-public-skills-directory/skills/jeffallan/fastapi-expert|fastapi-expert]], [[04-public-skills-directory/skills/jeffallan/postgres-pro|postgres-pro]], [[04-public-skills-directory/skills/jeffallan/fullstack-guardian|fullstack-guardian]], [[04-public-skills-directory/skills/jeffallan/nextjs-developer|nextjs-developer]]
- Registry seed skills for this role: [[03-skills/software-engineering/application/backend-engineer/README|backend-engineer seed skills]]
