---
type: public-skill
name: nextjs-developer
owner: Jeffallan
curator: Thomas Cherickal
source_repo: jeffallan/claude-skills
source_url: https://github.com/Jeffallan/claude-skills/blob/HEAD/skills/nextjs-developer/SKILL.md
repo_stars: 12361
license: MIT
repo_last_push: 2026-11-11
roles: [fullstack-engineer]
categories: [software-engineering/application]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/fullstack-engineer, owner/jeffallan]
---

# nextjs-developer

> Use when building Next.js 14+ applications with App Router, server components, or server actions. Invoke to configure route handlers, implement middleware, set up API routes, add streaming SSR, write generateMetadata for SEO, scaffold loading.tsx/error.tsx boundaries, or deploy to Vercel. Triggers on: Next.js, Next.js 14, App Router, RSC, use server, Server Components, Server Actions, React...

| Field | Value |
|---|---|
| Owner | Jeffallan |
| Curator | Thomas Cherickal |
| Source | [jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills/blob/HEAD/skills/nextjs-developer/SKILL.md) |
| Repo stars | 12,361 |
| License | MIT |
| Repo last push | 2026-11-11 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/application/fullstack-engineer|fullstack-engineer]]
- Source repo: [[04-public-skills-directory/sources/jeffallan-claude-skills|jeffallan/claude-skills]]
- Same repo: [[04-public-skills-directory/skills/jeffallan/fine-tuning-expert|fine-tuning-expert]], [[04-public-skills-directory/skills/jeffallan/rust-engineer|rust-engineer]], [[04-public-skills-directory/skills/jeffallan/django-expert|django-expert]], [[04-public-skills-directory/skills/jeffallan/django-storages-s3|django-storages-s3]], [[04-public-skills-directory/skills/jeffallan/fastapi-expert|fastapi-expert]], [[04-public-skills-directory/skills/jeffallan/microservices-architect|microservices-architect]], [[04-public-skills-directory/skills/jeffallan/postgres-pro|postgres-pro]], [[04-public-skills-directory/skills/jeffallan/fullstack-guardian|fullstack-guardian]]
- Registry seed skills for this role: [[03-skills/software-engineering/application/fullstack-engineer/README|fullstack-engineer seed skills]]
