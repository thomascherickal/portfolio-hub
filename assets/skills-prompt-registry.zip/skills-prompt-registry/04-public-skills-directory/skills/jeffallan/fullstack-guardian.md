---
type: public-skill
name: fullstack-guardian
owner: Jeffallan
curator: Thomas Cherickal
source_repo: jeffallan/claude-skills
source_url: https://github.com/Jeffallan/claude-skills/blob/HEAD/skills/fullstack-guardian/SKILL.md
repo_stars: 12361
license: MIT
repo_last_push: 2026-11-11
roles: [fullstack-engineer]
categories: [software-engineering/application]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/fullstack-engineer, owner/jeffallan]
---

# fullstack-guardian

> Builds security-focused full-stack web applications by implementing integrated frontend and backend components with layered security at every level. Covers the complete stack from database to UI, enforcing auth, input validation, output encoding, and parameterized queries across all layers. Use when implementing features across frontend and backend, building REST APIs with corresponding UI,...

| Field | Value |
|---|---|
| Owner | Jeffallan |
| Curator | Thomas Cherickal |
| Source | [jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills/blob/HEAD/skills/fullstack-guardian/SKILL.md) |
| Repo stars | 12,361 |
| License | MIT |
| Repo last push | 2026-11-11 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/application/fullstack-engineer|fullstack-engineer]]
- Source repo: [[04-public-skills-directory/sources/jeffallan-claude-skills|jeffallan/claude-skills]]
- Same repo: [[04-public-skills-directory/skills/jeffallan/fine-tuning-expert|fine-tuning-expert]], [[04-public-skills-directory/skills/jeffallan/rust-engineer|rust-engineer]], [[04-public-skills-directory/skills/jeffallan/django-expert|django-expert]], [[04-public-skills-directory/skills/jeffallan/django-storages-s3|django-storages-s3]], [[04-public-skills-directory/skills/jeffallan/fastapi-expert|fastapi-expert]], [[04-public-skills-directory/skills/jeffallan/microservices-architect|microservices-architect]], [[04-public-skills-directory/skills/jeffallan/postgres-pro|postgres-pro]], [[04-public-skills-directory/skills/jeffallan/nextjs-developer|nextjs-developer]]
- Registry seed skills for this role: [[03-skills/software-engineering/application/fullstack-engineer/README|fullstack-engineer seed skills]]
