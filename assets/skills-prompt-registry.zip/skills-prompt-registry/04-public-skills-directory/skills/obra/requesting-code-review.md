---
type: public-skill
name: requesting-code-review
owner: obra
curator: Thomas Cherickal
source_repo: obra/superpowers
source_url: https://github.com/obra/superpowers/blob/HEAD/skills/requesting-code-review/SKILL.md
repo_stars: 317619
license: MIT
repo_last_push: 2026-11-03
roles: [software-engineer]
categories: [software-engineering/general]
mirrors: [davila7/claude-code-templates, sickn33/agentic-awesome-skills]
status: listed
collected: 2026-11-15
tags: [public-skill, role/software-engineer, owner/obra]
---

# requesting-code-review

> Use when completing tasks, implementing major features, or before merging to verify work meets requirements

| Field | Value |
|---|---|
| Owner | obra |
| Curator | Thomas Cherickal |
| Source | [obra/superpowers](https://github.com/obra/superpowers/blob/HEAD/skills/requesting-code-review/SKILL.md) |
| Repo stars | 317,619 |
| License | MIT |
| Repo last push | 2026-11-03 |
| Also published in | davila7/claude-code-templates, sickn33/agentic-awesome-skills |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/general/software-engineer|software-engineer]]
- Source repo: [[04-public-skills-directory/sources/obra-superpowers|obra/superpowers]]
- Same repo: [[04-public-skills-directory/skills/obra/brainstorming|brainstorming]], [[04-public-skills-directory/skills/obra/executing-plans|executing-plans]], [[04-public-skills-directory/skills/obra/finishing-a-development-branch|finishing-a-development-branch]], [[04-public-skills-directory/skills/obra/receiving-code-review|receiving-code-review]], [[04-public-skills-directory/skills/obra/dispatching-parallel-agents|dispatching-parallel-agents]], [[04-public-skills-directory/skills/obra/subagent-driven-development|subagent-driven-development]], [[04-public-skills-directory/skills/obra/writing-skills|writing-skills]]
- Registry seed skills for this role: [[03-skills/software-engineering/general/software-engineer/README|software-engineer seed skills]]
