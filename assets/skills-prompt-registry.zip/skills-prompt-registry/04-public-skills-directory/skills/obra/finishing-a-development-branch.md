---
type: public-skill
name: finishing-a-development-branch
owner: obra
curator: Thomas Cherickal
source_repo: obra/superpowers
source_url: https://github.com/obra/superpowers/blob/HEAD/skills/finishing-a-development-branch/SKILL.md
repo_stars: 317619
license: MIT
repo_last_push: 2026-11-03
roles: [software-engineer]
categories: [software-engineering/general]
mirrors: [davila7/claude-code-templates, sickn33/agentic-awesome-skills]
status: listed
collected: 2026-11-15
tags: [public-skill, role/software-engineer, owner/obra]
---

# finishing-a-development-branch

> Use when implementation is complete, all tests pass, and you need to decide how to integrate the work

| Field | Value |
|---|---|
| Owner | obra |
| Curator | Thomas Cherickal |
| Source | [obra/superpowers](https://github.com/obra/superpowers/blob/HEAD/skills/finishing-a-development-branch/SKILL.md) |
| Repo stars | 317,619 |
| License | MIT |
| Repo last push | 2026-11-03 |
| Also published in | davila7/claude-code-templates, sickn33/agentic-awesome-skills |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/general/software-engineer|software-engineer]]
- Source repo: [[04-public-skills-directory/sources/obra-superpowers|obra/superpowers]]
- Same repo: [[04-public-skills-directory/skills/obra/brainstorming|brainstorming]], [[04-public-skills-directory/skills/obra/executing-plans|executing-plans]], [[04-public-skills-directory/skills/obra/receiving-code-review|receiving-code-review]], [[04-public-skills-directory/skills/obra/requesting-code-review|requesting-code-review]], [[04-public-skills-directory/skills/obra/dispatching-parallel-agents|dispatching-parallel-agents]], [[04-public-skills-directory/skills/obra/subagent-driven-development|subagent-driven-development]], [[04-public-skills-directory/skills/obra/writing-skills|writing-skills]]
- Registry seed skills for this role: [[03-skills/software-engineering/general/software-engineer/README|software-engineer seed skills]]
