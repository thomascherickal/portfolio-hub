---
type: public-skill
name: subagent-driven-development
owner: obra
curator: Thomas Cherickal
source_repo: obra/superpowers
source_url: https://github.com/obra/superpowers/blob/HEAD/skills/subagent-driven-development/SKILL.md
repo_stars: 317619
license: MIT
repo_last_push: 2026-11-03
roles: [genai-engineer]
categories: [ai-ml/applied-ai]
mirrors: [davila7/claude-code-templates, sickn33/agentic-awesome-skills]
status: listed
collected: 2026-11-15
tags: [public-skill, role/genai-engineer, owner/obra]
---

# subagent-driven-development

> Use when executing implementation plans with independent tasks in the current session

| Field | Value |
|---|---|
| Owner | obra |
| Curator | Thomas Cherickal |
| Source | [obra/superpowers](https://github.com/obra/superpowers/blob/HEAD/skills/subagent-driven-development/SKILL.md) |
| Repo stars | 317,619 |
| License | MIT |
| Repo last push | 2026-11-03 |
| Also published in | davila7/claude-code-templates, sickn33/agentic-awesome-skills |

## Links

- Roles: [[04-public-skills-directory/roles/ai-ml/applied-ai/genai-engineer|genai-engineer]]
- Source repo: [[04-public-skills-directory/sources/obra-superpowers|obra/superpowers]]
- Same repo: [[04-public-skills-directory/skills/obra/brainstorming|brainstorming]], [[04-public-skills-directory/skills/obra/executing-plans|executing-plans]], [[04-public-skills-directory/skills/obra/finishing-a-development-branch|finishing-a-development-branch]], [[04-public-skills-directory/skills/obra/receiving-code-review|receiving-code-review]], [[04-public-skills-directory/skills/obra/requesting-code-review|requesting-code-review]], [[04-public-skills-directory/skills/obra/dispatching-parallel-agents|dispatching-parallel-agents]], [[04-public-skills-directory/skills/obra/writing-skills|writing-skills]]
- Registry seed skills for this role: [[03-skills/ai-ml/applied-ai/genai-engineer/README|genai-engineer seed skills]]
