---
type: public-skill
name: ruzzy
owner: trailofbits
curator: Thomas Cherickal
source_repo: trailofbits/skills
source_url: https://github.com/trailofbits/skills/blob/HEAD/plugins/testing-handbook-skills/skills/ruzzy/SKILL.md
repo_stars: 8189
license: CC-BY-SA-4.0
repo_last_push: 2026-11-12
roles: [rust-engineer]
categories: [software-engineering/languages]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/rust-engineer, owner/trailofbits]
---

# ruzzy

> Sets up and runs Ruzzy, Trail of Bits' coverage-guided Ruby fuzzer and the only production-ready one for the language. Covers harness structure, fuzzing pure Ruby and the native C extensions in gems, and sanitizer builds. Use when fuzzing a Ruby library or gem, testing a Ruby C extension for memory safety, or asking how to fuzz Ruby at all.

| Field | Value |
|---|---|
| Owner | trailofbits |
| Curator | Thomas Cherickal |
| Source | [trailofbits/skills](https://github.com/trailofbits/skills/blob/HEAD/plugins/testing-handbook-skills/skills/ruzzy/SKILL.md) |
| Repo stars | 8,189 |
| License | CC-BY-SA-4.0 |
| Repo last push | 2026-11-12 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/languages/rust-engineer|rust-engineer]]
- Source repo: [[04-public-skills-directory/sources/trailofbits-skills|trailofbits/skills]]
- Same repo: [[04-public-skills-directory/skills/trailofbits/cargo-fuzz|cargo-fuzz]], [[04-public-skills-directory/skills/trailofbits/rust-review|rust-review]], [[04-public-skills-directory/skills/trailofbits/vector-forge|vector-forge]], [[04-public-skills-directory/skills/trailofbits/guidelines-advisor|guidelines-advisor]], [[04-public-skills-directory/skills/trailofbits/algorand-vulnerability-scanner|algorand-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/cairo-vulnerability-scanner|cairo-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/cosmos-vulnerability-scanner|cosmos-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/solana-vulnerability-scanner|solana-vulnerability-scanner]]
- Registry seed skills for this role: [[03-skills/software-engineering/languages/rust-engineer/README|rust-engineer seed skills]]
