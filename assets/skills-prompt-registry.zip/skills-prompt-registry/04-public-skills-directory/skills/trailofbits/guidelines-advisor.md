---
type: public-skill
name: guidelines-advisor
owner: trailofbits
curator: Thomas Cherickal
source_repo: trailofbits/skills
source_url: https://github.com/trailofbits/skills/blob/HEAD/plugins/building-secure-contracts/skills/guidelines-advisor/SKILL.md
repo_stars: 8189
license: CC-BY-SA-4.0
repo_last_push: 2026-11-12
roles: [genai-consultant]
categories: [consulting]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/genai-consultant, owner/trailofbits]
---

# guidelines-advisor

> Smart contract development advisor based on Trail of Bits' best practices. Analyzes codebase to generate documentation/specifications, review architecture, check upgradeability patterns, assess implementation quality, identify pitfalls, review dependencies, and evaluate testing. Use when asking whether a smart contract project follows development best practices, reviewing on-chain/off-chain...

| Field | Value |
|---|---|
| Owner | trailofbits |
| Curator | Thomas Cherickal |
| Source | [trailofbits/skills](https://github.com/trailofbits/skills/blob/HEAD/plugins/building-secure-contracts/skills/guidelines-advisor/SKILL.md) |
| Repo stars | 8,189 |
| License | CC-BY-SA-4.0 |
| Repo last push | 2026-11-12 |

## Links

- Roles: [[04-public-skills-directory/roles/consulting/genai-consultant|genai-consultant]]
- Source repo: [[04-public-skills-directory/sources/trailofbits-skills|trailofbits/skills]]
- Same repo: [[04-public-skills-directory/skills/trailofbits/cargo-fuzz|cargo-fuzz]], [[04-public-skills-directory/skills/trailofbits/rust-review|rust-review]], [[04-public-skills-directory/skills/trailofbits/ruzzy|ruzzy]], [[04-public-skills-directory/skills/trailofbits/vector-forge|vector-forge]], [[04-public-skills-directory/skills/trailofbits/algorand-vulnerability-scanner|algorand-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/cairo-vulnerability-scanner|cairo-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/cosmos-vulnerability-scanner|cosmos-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/solana-vulnerability-scanner|solana-vulnerability-scanner]]
- Registry seed skills for this role: [[03-skills/consulting/genai-consultant/README|genai-consultant seed skills]]
