---
type: public-skill
name: cargo-fuzz
owner: trailofbits
curator: Thomas Cherickal
source_repo: trailofbits/skills
source_url: https://github.com/trailofbits/skills/blob/HEAD/plugins/testing-handbook-skills/skills/cargo-fuzz/SKILL.md
repo_stars: 8189
license: CC-BY-SA-4.0
repo_last_push: 2026-11-12
roles: [rust-engineer]
categories: [software-engineering/languages]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/rust-engineer, owner/trailofbits]
---

# cargo-fuzz

> Sets up and runs cargo-fuzz, the standard fuzzing tool for Cargo-based Rust projects. Covers cargo fuzz init, the nightly toolchain requirement, fuzz_target! harnesses, Arbitrary-derived structured inputs, sanitizer options, cargo fuzz coverage, and reproducing a crash artifact. Use when fuzzing a Rust crate, writing a fuzz_target!, exercising unsafe blocks or FFI in Rust, or triaging a cargo...

| Field | Value |
|---|---|
| Owner | trailofbits |
| Curator | Thomas Cherickal |
| Source | [trailofbits/skills](https://github.com/trailofbits/skills/blob/HEAD/plugins/testing-handbook-skills/skills/cargo-fuzz/SKILL.md) |
| Repo stars | 8,189 |
| License | CC-BY-SA-4.0 |
| Repo last push | 2026-11-12 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/languages/rust-engineer|rust-engineer]]
- Source repo: [[04-public-skills-directory/sources/trailofbits-skills|trailofbits/skills]]
- Same repo: [[04-public-skills-directory/skills/trailofbits/rust-review|rust-review]], [[04-public-skills-directory/skills/trailofbits/ruzzy|ruzzy]], [[04-public-skills-directory/skills/trailofbits/vector-forge|vector-forge]], [[04-public-skills-directory/skills/trailofbits/guidelines-advisor|guidelines-advisor]], [[04-public-skills-directory/skills/trailofbits/algorand-vulnerability-scanner|algorand-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/cairo-vulnerability-scanner|cairo-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/cosmos-vulnerability-scanner|cosmos-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/solana-vulnerability-scanner|solana-vulnerability-scanner]]
- Registry seed skills for this role: [[03-skills/software-engineering/languages/rust-engineer/README|rust-engineer seed skills]]
