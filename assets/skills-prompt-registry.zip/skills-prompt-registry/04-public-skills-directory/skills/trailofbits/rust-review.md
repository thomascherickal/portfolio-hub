---
type: public-skill
name: rust-review
owner: trailofbits
curator: Thomas Cherickal
source_repo: trailofbits/skills
source_url: https://github.com/trailofbits/skills/blob/HEAD/plugins/rust-review/skills/rust-review/SKILL.md
repo_stars: 8189
license: CC-BY-SA-4.0
repo_last_push: 2026-11-12
roles: [rust-engineer]
categories: [software-engineering/languages]
mirrors: [morganlinton/BeautifulRust]
status: listed
collected: 2026-11-15
tags: [public-skill, role/rust-engineer, owner/trailofbits]
---

# rust-review

> Performs comprehensive Rust security review for safe/unsafe boundary issues, memory safety in unsafe blocks, concurrency hazards, panic-induced DoS, FFI safety, and async runtime mistakes. Use when auditing Rust crates, services, or libraries — particularly those with `unsafe`, FFI, or concurrent code.

| Field | Value |
|---|---|
| Owner | trailofbits |
| Curator | Thomas Cherickal |
| Source | [trailofbits/skills](https://github.com/trailofbits/skills/blob/HEAD/plugins/rust-review/skills/rust-review/SKILL.md) |
| Repo stars | 8,189 |
| License | CC-BY-SA-4.0 |
| Repo last push | 2026-11-12 |
| Also published in | morganlinton/BeautifulRust |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/languages/rust-engineer|rust-engineer]]
- Source repo: [[04-public-skills-directory/sources/trailofbits-skills|trailofbits/skills]]
- Same repo: [[04-public-skills-directory/skills/trailofbits/cargo-fuzz|cargo-fuzz]], [[04-public-skills-directory/skills/trailofbits/ruzzy|ruzzy]], [[04-public-skills-directory/skills/trailofbits/vector-forge|vector-forge]], [[04-public-skills-directory/skills/trailofbits/guidelines-advisor|guidelines-advisor]], [[04-public-skills-directory/skills/trailofbits/algorand-vulnerability-scanner|algorand-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/cairo-vulnerability-scanner|cairo-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/cosmos-vulnerability-scanner|cosmos-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/solana-vulnerability-scanner|solana-vulnerability-scanner]]
- Registry seed skills for this role: [[03-skills/software-engineering/languages/rust-engineer/README|rust-engineer seed skills]]
