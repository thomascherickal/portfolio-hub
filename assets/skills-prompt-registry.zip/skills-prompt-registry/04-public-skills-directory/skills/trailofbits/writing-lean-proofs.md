---
type: public-skill
name: writing-lean-proofs
owner: trailofbits
curator: Thomas Cherickal
source_repo: trailofbits/skills
source_url: https://github.com/trailofbits/skills/blob/HEAD/plugins/writing-lean-proofs/skills/writing-lean-proofs/SKILL.md
repo_stars: 8189
license: CC-BY-SA-4.0
repo_last_push: 2026-11-12
roles: [quantum-computing-researcher]
categories: [quantum/research]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/quantum-computing-researcher, owner/trailofbits]
---

# writing-lean-proofs

> Writes and reviews structured Lean 4 proofs and designs Lean libraries following Mathlib conventions. Use when proving theorems in Lean, formalizing mathematics or specifications in Lean 4, defining new types or definitions in a Lean library, reviewing Lean proofs for readability and maintainability, refactoring long tactic proofs into lemmas, filling in sorry placeholders in a Lean development,...

| Field | Value |
|---|---|
| Owner | trailofbits |
| Curator | Thomas Cherickal |
| Source | [trailofbits/skills](https://github.com/trailofbits/skills/blob/HEAD/plugins/writing-lean-proofs/skills/writing-lean-proofs/SKILL.md) |
| Repo stars | 8,189 |
| License | CC-BY-SA-4.0 |
| Repo last push | 2026-11-12 |

## Links

- Roles: [[04-public-skills-directory/roles/quantum/research/quantum-computing-researcher|quantum-computing-researcher]]
- Source repo: [[04-public-skills-directory/sources/trailofbits-skills|trailofbits/skills]]
- Same repo: [[04-public-skills-directory/skills/trailofbits/cargo-fuzz|cargo-fuzz]], [[04-public-skills-directory/skills/trailofbits/rust-review|rust-review]], [[04-public-skills-directory/skills/trailofbits/ruzzy|ruzzy]], [[04-public-skills-directory/skills/trailofbits/vector-forge|vector-forge]], [[04-public-skills-directory/skills/trailofbits/guidelines-advisor|guidelines-advisor]], [[04-public-skills-directory/skills/trailofbits/algorand-vulnerability-scanner|algorand-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/cairo-vulnerability-scanner|cairo-vulnerability-scanner]], [[04-public-skills-directory/skills/trailofbits/cosmos-vulnerability-scanner|cosmos-vulnerability-scanner]]
- Registry seed skills for this role: [[03-skills/quantum/research/quantum-computing-researcher/README|quantum-computing-researcher seed skills]]
