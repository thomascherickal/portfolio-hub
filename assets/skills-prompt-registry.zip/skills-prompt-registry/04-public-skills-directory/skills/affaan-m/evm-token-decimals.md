---
type: public-skill
name: evm-token-decimals
owner: affaan-m
curator: Thomas Cherickal
source_repo: affaan-m/ECC
source_url: https://github.com/affaan-m/ECC/blob/HEAD/skills/evm-token-decimals/SKILL.md
repo_stars: 302998
license: MIT
repo_last_push: 2026-11-09
roles: [blockchain-defi-engineer]
categories: [web3]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/blockchain-defi-engineer, owner/affaan-m]
---

# evm-token-decimals

> Prevent silent decimal mismatch bugs across EVM chains. Covers runtime decimal lookup, chain-aware caching, bridged-token precision drift, and safe normalization for bots, dashboards, and DeFi tools. Use when handling token amounts across EVM chains, or when a balance, price, or transfer amount is off by orders of magnitude.

| Field | Value |
|---|---|
| Owner | affaan-m |
| Curator | Thomas Cherickal |
| Source | [affaan-m/ECC](https://github.com/affaan-m/ECC/blob/HEAD/skills/evm-token-decimals/SKILL.md) |
| Repo stars | 302,998 |
| License | MIT |
| Repo last push | 2026-11-09 |

## Links

- Roles: [[04-public-skills-directory/roles/web3/blockchain-defi-engineer|blockchain-defi-engineer]]
- Source repo: [[04-public-skills-directory/sources/affaan-m-ecc|affaan-m/ECC]]
- Same repo: [[04-public-skills-directory/skills/affaan-m/agent-eval|agent-eval]], [[04-public-skills-directory/skills/affaan-m/agent-self-evaluation|agent-self-evaluation]], [[04-public-skills-directory/skills/affaan-m/eval-harness|eval-harness]], [[04-public-skills-directory/skills/affaan-m/healthcare-eval-harness|healthcare-eval-harness]], [[04-public-skills-directory/skills/affaan-m/scientific-thinking-scholar-evaluation|scientific-thinking-scholar-evaluation]], [[04-public-skills-directory/skills/affaan-m/rust-patterns|rust-patterns]], [[04-public-skills-directory/skills/affaan-m/rust-testing|rust-testing]], [[04-public-skills-directory/skills/affaan-m/django-celery|django-celery]]
- Registry seed skills for this role: [[03-skills/web3/blockchain-defi-engineer/README|blockchain-defi-engineer seed skills]]
