---
type: public-skill
name: exa-search
owner: affaan-m
curator: Thomas Cherickal
source_repo: affaan-m/ECC
source_url: https://github.com/affaan-m/ECC/blob/HEAD/skills/exa-search/SKILL.md
repo_stars: 302998
license: MIT
repo_last_push: 2026-11-09
roles: [industry-researcher]
categories: [research]
mirrors: [K-Dense-AI/scientific-agent-skills, davila7/claude-code-templates, sickn33/agentic-awesome-skills, wanshuiyin/Auto-claude-code-research-in-sleep]
status: listed
collected: 2026-11-15
tags: [public-skill, role/industry-researcher, owner/affaan-m]
---

# exa-search

> Neural search via Exa MCP for web, code, and company research. Use when the user needs web search, code examples, company intel, people lookup, or AI-powered deep research with Exa's neural search engine.

| Field | Value |
|---|---|
| Owner | affaan-m |
| Curator | Thomas Cherickal |
| Source | [affaan-m/ECC](https://github.com/affaan-m/ECC/blob/HEAD/skills/exa-search/SKILL.md) |
| Repo stars | 302,998 |
| License | MIT |
| Repo last push | 2026-11-09 |
| Also published in | K-Dense-AI/scientific-agent-skills, davila7/claude-code-templates, sickn33/agentic-awesome-skills, wanshuiyin/Auto-claude-code-research-in-sleep |

## Links

- Roles: [[04-public-skills-directory/roles/research/industry-researcher|industry-researcher]]
- Source repo: [[04-public-skills-directory/sources/affaan-m-ecc|affaan-m/ECC]]
- Same repo: [[04-public-skills-directory/skills/affaan-m/agent-eval|agent-eval]], [[04-public-skills-directory/skills/affaan-m/agent-self-evaluation|agent-self-evaluation]], [[04-public-skills-directory/skills/affaan-m/eval-harness|eval-harness]], [[04-public-skills-directory/skills/affaan-m/healthcare-eval-harness|healthcare-eval-harness]], [[04-public-skills-directory/skills/affaan-m/scientific-thinking-scholar-evaluation|scientific-thinking-scholar-evaluation]], [[04-public-skills-directory/skills/affaan-m/rust-patterns|rust-patterns]], [[04-public-skills-directory/skills/affaan-m/rust-testing|rust-testing]], [[04-public-skills-directory/skills/affaan-m/django-celery|django-celery]]
- Registry seed skills for this role: [[03-skills/research/industry-researcher/README|industry-researcher seed skills]]
