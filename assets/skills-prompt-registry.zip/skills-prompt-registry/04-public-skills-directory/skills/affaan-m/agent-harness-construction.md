---
type: public-skill
name: agent-harness-construction
owner: affaan-m
curator: Thomas Cherickal
source_repo: affaan-m/ECC
source_url: https://github.com/affaan-m/ECC/blob/HEAD/skills/agent-harness-construction/SKILL.md
repo_stars: 302998
license: MIT
repo_last_push: 2026-11-09
roles: [genai-engineer]
categories: [ai-ml/applied-ai]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/genai-engineer, owner/affaan-m]
---

# agent-harness-construction

> Design and optimize AI agent action spaces, tool definitions, and observation formatting for higher completion rates. Use when defining or revising an agent's tool set, action space, or observation format.

| Field | Value |
|---|---|
| Owner | affaan-m |
| Curator | Thomas Cherickal |
| Source | [affaan-m/ECC](https://github.com/affaan-m/ECC/blob/HEAD/skills/agent-harness-construction/SKILL.md) |
| Repo stars | 302,998 |
| License | MIT |
| Repo last push | 2026-11-09 |

## Links

- Roles: [[04-public-skills-directory/roles/ai-ml/applied-ai/genai-engineer|genai-engineer]]
- Source repo: [[04-public-skills-directory/sources/affaan-m-ecc|affaan-m/ECC]]
- Same repo: [[04-public-skills-directory/skills/affaan-m/agent-eval|agent-eval]], [[04-public-skills-directory/skills/affaan-m/agent-self-evaluation|agent-self-evaluation]], [[04-public-skills-directory/skills/affaan-m/eval-harness|eval-harness]], [[04-public-skills-directory/skills/affaan-m/healthcare-eval-harness|healthcare-eval-harness]], [[04-public-skills-directory/skills/affaan-m/scientific-thinking-scholar-evaluation|scientific-thinking-scholar-evaluation]], [[04-public-skills-directory/skills/affaan-m/rust-patterns|rust-patterns]], [[04-public-skills-directory/skills/affaan-m/rust-testing|rust-testing]], [[04-public-skills-directory/skills/affaan-m/django-celery|django-celery]]
- Registry seed skills for this role: [[03-skills/ai-ml/applied-ai/genai-engineer/README|genai-engineer seed skills]]
