---
type: public-skill
name: competitive-platform-analysis
owner: affaan-m
curator: Thomas Cherickal
source_repo: affaan-m/ECC
source_url: https://github.com/affaan-m/ECC/blob/HEAD/skills/competitive-platform-analysis/SKILL.md
repo_stars: 302998
license: MIT
repo_last_push: 2026-11-09
roles: [industry-researcher]
categories: [research]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/industry-researcher, owner/affaan-m]
---

# competitive-platform-analysis

> Use when scoping a competitive landscape — identifying, categorising, and score-filtering a competitor set before any benchmarking begins. Decides who counts as a competitor, which tier they belong to, and which sources to mine. First step in the three-skill competitive pipeline; precedes benchmark-methodology.

| Field | Value |
|---|---|
| Owner | affaan-m |
| Curator | Thomas Cherickal |
| Source | [affaan-m/ECC](https://github.com/affaan-m/ECC/blob/HEAD/skills/competitive-platform-analysis/SKILL.md) |
| Repo stars | 302,998 |
| License | MIT |
| Repo last push | 2026-11-09 |

## Links

- Roles: [[04-public-skills-directory/roles/research/industry-researcher|industry-researcher]]
- Source repo: [[04-public-skills-directory/sources/affaan-m-ecc|affaan-m/ECC]]
- Same repo: [[04-public-skills-directory/skills/affaan-m/agent-eval|agent-eval]], [[04-public-skills-directory/skills/affaan-m/agent-self-evaluation|agent-self-evaluation]], [[04-public-skills-directory/skills/affaan-m/eval-harness|eval-harness]], [[04-public-skills-directory/skills/affaan-m/healthcare-eval-harness|healthcare-eval-harness]], [[04-public-skills-directory/skills/affaan-m/scientific-thinking-scholar-evaluation|scientific-thinking-scholar-evaluation]], [[04-public-skills-directory/skills/affaan-m/rust-patterns|rust-patterns]], [[04-public-skills-directory/skills/affaan-m/rust-testing|rust-testing]], [[04-public-skills-directory/skills/affaan-m/django-celery|django-celery]]
- Registry seed skills for this role: [[03-skills/research/industry-researcher/README|industry-researcher seed skills]]
