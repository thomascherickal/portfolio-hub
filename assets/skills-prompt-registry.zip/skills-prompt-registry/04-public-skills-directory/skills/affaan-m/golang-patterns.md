---
type: public-skill
name: golang-patterns
owner: affaan-m
curator: Thomas Cherickal
source_repo: affaan-m/ECC
source_url: https://github.com/affaan-m/ECC/blob/HEAD/skills/golang-patterns/SKILL.md
repo_stars: 302998
license: MIT
repo_last_push: 2026-11-09
roles: [go-engineer]
categories: [software-engineering/languages]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/go-engineer, owner/affaan-m]
---

# golang-patterns

> Idiomatic Go patterns, best practices, and conventions for building robust, efficient, and maintainable Go applications. Use when writing or reviewing Go code and idiomatic structure or conventions are in question.

| Field | Value |
|---|---|
| Owner | affaan-m |
| Curator | Thomas Cherickal |
| Source | [affaan-m/ECC](https://github.com/affaan-m/ECC/blob/HEAD/skills/golang-patterns/SKILL.md) |
| Repo stars | 302,998 |
| License | MIT |
| Repo last push | 2026-11-09 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/languages/go-engineer|go-engineer]]
- Source repo: [[04-public-skills-directory/sources/affaan-m-ecc|affaan-m/ECC]]
- Same repo: [[04-public-skills-directory/skills/affaan-m/agent-eval|agent-eval]], [[04-public-skills-directory/skills/affaan-m/agent-self-evaluation|agent-self-evaluation]], [[04-public-skills-directory/skills/affaan-m/eval-harness|eval-harness]], [[04-public-skills-directory/skills/affaan-m/healthcare-eval-harness|healthcare-eval-harness]], [[04-public-skills-directory/skills/affaan-m/scientific-thinking-scholar-evaluation|scientific-thinking-scholar-evaluation]], [[04-public-skills-directory/skills/affaan-m/rust-patterns|rust-patterns]], [[04-public-skills-directory/skills/affaan-m/rust-testing|rust-testing]], [[04-public-skills-directory/skills/affaan-m/django-celery|django-celery]]
- Registry seed skills for this role: [[03-skills/software-engineering/languages/go-engineer/README|go-engineer seed skills]]
