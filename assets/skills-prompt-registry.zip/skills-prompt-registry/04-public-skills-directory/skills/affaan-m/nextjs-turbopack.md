---
type: public-skill
name: nextjs-turbopack
owner: affaan-m
curator: Thomas Cherickal
source_repo: affaan-m/ECC
source_url: https://github.com/affaan-m/ECC/blob/HEAD/skills/nextjs-turbopack/SKILL.md
repo_stars: 302998
license: MIT
repo_last_push: 2026-11-09
roles: [fullstack-engineer]
categories: [software-engineering/application]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/fullstack-engineer, owner/affaan-m]
---

# nextjs-turbopack

> Next.js 16+ and Turbopack guidance — incremental Rust bundling, file-system caching, faster dev startup and HMR, Turbopack vs webpack tradeoffs, and the middleware.ts to proxy.ts filename change. Use when developing or debugging Next.js 16+ apps, diagnosing slow dev startup or hot reload, choosing between bundlers, or reviewing middleware/proxy file naming.

| Field | Value |
|---|---|
| Owner | affaan-m |
| Curator | Thomas Cherickal |
| Source | [affaan-m/ECC](https://github.com/affaan-m/ECC/blob/HEAD/skills/nextjs-turbopack/SKILL.md) |
| Repo stars | 302,998 |
| License | MIT |
| Repo last push | 2026-11-09 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/application/fullstack-engineer|fullstack-engineer]]
- Source repo: [[04-public-skills-directory/sources/affaan-m-ecc|affaan-m/ECC]]
- Same repo: [[04-public-skills-directory/skills/affaan-m/agent-eval|agent-eval]], [[04-public-skills-directory/skills/affaan-m/agent-self-evaluation|agent-self-evaluation]], [[04-public-skills-directory/skills/affaan-m/eval-harness|eval-harness]], [[04-public-skills-directory/skills/affaan-m/healthcare-eval-harness|healthcare-eval-harness]], [[04-public-skills-directory/skills/affaan-m/scientific-thinking-scholar-evaluation|scientific-thinking-scholar-evaluation]], [[04-public-skills-directory/skills/affaan-m/rust-patterns|rust-patterns]], [[04-public-skills-directory/skills/affaan-m/rust-testing|rust-testing]], [[04-public-skills-directory/skills/affaan-m/django-celery|django-celery]]
- Registry seed skills for this role: [[03-skills/software-engineering/application/fullstack-engineer/README|fullstack-engineer seed skills]]
