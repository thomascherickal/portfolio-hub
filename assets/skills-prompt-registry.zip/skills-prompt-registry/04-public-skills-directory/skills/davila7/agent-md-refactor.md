---
type: public-skill
name: agent-md-refactor
owner: davila7
curator: Thomas Cherickal
source_repo: davila7/claude-code-templates
source_url: https://github.com/davila7/claude-code-templates/blob/HEAD/cli-tool/components/skills/development/agent-md-refactor/SKILL.md
repo_stars: 33617
license: MIT
repo_last_push: 2026-11-14
roles: [software-engineer, genai-engineer]
categories: [ai-ml/applied-ai, software-engineering/general]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/software-engineer, role/genai-engineer, owner/davila7]
---

# agent-md-refactor

> Refactor bloated AGENTS.md, CLAUDE.md, or similar agent instruction files to follow progressive disclosure principles. Splits monolithic files into organized, linked documentation.

| Field | Value |
|---|---|
| Owner | davila7 |
| Curator | Thomas Cherickal |
| Source | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates/blob/HEAD/cli-tool/components/skills/development/agent-md-refactor/SKILL.md) |
| Repo stars | 33,617 |
| License | MIT |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/general/software-engineer|software-engineer]], [[04-public-skills-directory/roles/ai-ml/applied-ai/genai-engineer|genai-engineer]]
- Source repo: [[04-public-skills-directory/sources/davila7-claude-code-templates|davila7/claude-code-templates]]
- Same repo: [[04-public-skills-directory/skills/davila7/eval-genius|eval-genius]], [[04-public-skills-directory/skills/davila7/evaluation-bigcode-evaluation-harness|evaluation-bigcode-evaluation-harness]], [[04-public-skills-directory/skills/davila7/evaluation-lm-evaluation-harness|evaluation-lm-evaluation-harness]], [[04-public-skills-directory/skills/davila7/evaluation-nemo-evaluator|evaluation-nemo-evaluator]], [[04-public-skills-directory/skills/davila7/prompt-engineering-dspy|prompt-engineering-dspy]], [[04-public-skills-directory/skills/davila7/distributed-training-deepspeed|distributed-training-deepspeed]], [[04-public-skills-directory/skills/davila7/distributed-training-megatron-core|distributed-training-megatron-core]], [[04-public-skills-directory/skills/davila7/distributed-training-pytorch-fsdp|distributed-training-pytorch-fsdp]]
- Registry seed skills for this role: [[03-skills/software-engineering/general/software-engineer/README|software-engineer seed skills]]
