---
type: public-skill
name: backend-to-frontend-handoff-docs
owner: davila7
curator: Thomas Cherickal
source_repo: davila7/claude-code-templates
source_url: https://github.com/davila7/claude-code-templates/blob/HEAD/cli-tool/components/skills/enterprise-communication/backend-to-frontend-handoff-docs/SKILL.md
repo_stars: 33617
license: MIT
repo_last_push: 2026-11-14
roles: [backend-engineer, frontend-engineer, technical-writer]
categories: [design-and-content, software-engineering/application]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/backend-engineer, role/frontend-engineer, role/technical-writer, owner/davila7]
---

# backend-to-frontend-handoff-docs

> Create API handoff documentation for frontend developers. Use when backend work is complete and needs to be documented for frontend integration, or user says 'create handoff', 'document API', 'frontend handoff', or 'API documentation'.

| Field | Value |
|---|---|
| Owner | davila7 |
| Curator | Thomas Cherickal |
| Source | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates/blob/HEAD/cli-tool/components/skills/enterprise-communication/backend-to-frontend-handoff-docs/SKILL.md) |
| Repo stars | 33,617 |
| License | MIT |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/application/backend-engineer|backend-engineer]], [[04-public-skills-directory/roles/software-engineering/application/frontend-engineer|frontend-engineer]], [[04-public-skills-directory/roles/design-and-content/technical-writer|technical-writer]]
- Source repo: [[04-public-skills-directory/sources/davila7-claude-code-templates|davila7/claude-code-templates]]
- Same repo: [[04-public-skills-directory/skills/davila7/eval-genius|eval-genius]], [[04-public-skills-directory/skills/davila7/evaluation-bigcode-evaluation-harness|evaluation-bigcode-evaluation-harness]], [[04-public-skills-directory/skills/davila7/evaluation-lm-evaluation-harness|evaluation-lm-evaluation-harness]], [[04-public-skills-directory/skills/davila7/evaluation-nemo-evaluator|evaluation-nemo-evaluator]], [[04-public-skills-directory/skills/davila7/prompt-engineering-dspy|prompt-engineering-dspy]], [[04-public-skills-directory/skills/davila7/distributed-training-deepspeed|distributed-training-deepspeed]], [[04-public-skills-directory/skills/davila7/distributed-training-megatron-core|distributed-training-megatron-core]], [[04-public-skills-directory/skills/davila7/distributed-training-pytorch-fsdp|distributed-training-pytorch-fsdp]]
- Registry seed skills for this role: [[03-skills/software-engineering/application/backend-engineer/README|backend-engineer seed skills]]
