---
type: public-skill
name: eval-genius
owner: davila7
curator: Thomas Cherickal
source_repo: davila7/claude-code-templates
source_url: https://github.com/davila7/claude-code-templates/blob/HEAD/cli-tool/components/skills/development/eval-genius/SKILL.md
repo_stars: 33617
license: MIT
repo_last_push: 2026-11-14
roles: [ai-engineer]
categories: [ai-ml/applied-ai]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/ai-engineer, owner/davila7]
---

# eval-genius

> - Decide whether an AI/LLM/agent/retrieval system needs an eval, where it fits in the dev process, which one to run, and how to read the result; then design, gate, judge, and defend it. Not ordinary unit tests.

| Field | Value |
|---|---|
| Owner | davila7 |
| Curator | Thomas Cherickal |
| Source | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates/blob/HEAD/cli-tool/components/skills/development/eval-genius/SKILL.md) |
| Repo stars | 33,617 |
| License | MIT |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/ai-ml/applied-ai/ai-engineer|ai-engineer]]
- Source repo: [[04-public-skills-directory/sources/davila7-claude-code-templates|davila7/claude-code-templates]]
- Same repo: [[04-public-skills-directory/skills/davila7/evaluation-bigcode-evaluation-harness|evaluation-bigcode-evaluation-harness]], [[04-public-skills-directory/skills/davila7/evaluation-lm-evaluation-harness|evaluation-lm-evaluation-harness]], [[04-public-skills-directory/skills/davila7/evaluation-nemo-evaluator|evaluation-nemo-evaluator]], [[04-public-skills-directory/skills/davila7/prompt-engineering-dspy|prompt-engineering-dspy]], [[04-public-skills-directory/skills/davila7/distributed-training-deepspeed|distributed-training-deepspeed]], [[04-public-skills-directory/skills/davila7/distributed-training-megatron-core|distributed-training-megatron-core]], [[04-public-skills-directory/skills/davila7/distributed-training-pytorch-fsdp|distributed-training-pytorch-fsdp]], [[04-public-skills-directory/skills/davila7/emerging-techniques-knowledge-distillation|emerging-techniques-knowledge-distillation]]
- Registry seed skills for this role: [[03-skills/ai-ml/applied-ai/ai-engineer/README|ai-engineer seed skills]]
