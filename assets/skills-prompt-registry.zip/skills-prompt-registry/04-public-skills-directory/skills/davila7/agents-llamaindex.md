---
type: public-skill
name: agents-llamaindex
owner: davila7
curator: Thomas Cherickal
source_repo: davila7/claude-code-templates
source_url: https://github.com/davila7/claude-code-templates/blob/HEAD/cli-tool/components/skills/ai-research/agents-llamaindex/SKILL.md
repo_stars: 33617
license: MIT
repo_last_push: 2026-11-14
roles: [rag-engineer]
categories: [ai-ml/llm-systems]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/rag-engineer, owner/davila7]
---

# agents-llamaindex

> Data framework for building LLM applications with RAG. Specializes in document ingestion (300+ connectors), indexing, and querying. Features vector indices, query engines, agents, and multi-modal support. Use for document Q&A, chatbots, knowledge retrieval, or building RAG pipelines. Best for data-centric LLM applications.

| Field | Value |
|---|---|
| Owner | davila7 |
| Curator | Thomas Cherickal |
| Source | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates/blob/HEAD/cli-tool/components/skills/ai-research/agents-llamaindex/SKILL.md) |
| Repo stars | 33,617 |
| License | MIT |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/ai-ml/llm-systems/rag-engineer|rag-engineer]]
- Source repo: [[04-public-skills-directory/sources/davila7-claude-code-templates|davila7/claude-code-templates]]
- Same repo: [[04-public-skills-directory/skills/davila7/eval-genius|eval-genius]], [[04-public-skills-directory/skills/davila7/evaluation-bigcode-evaluation-harness|evaluation-bigcode-evaluation-harness]], [[04-public-skills-directory/skills/davila7/evaluation-lm-evaluation-harness|evaluation-lm-evaluation-harness]], [[04-public-skills-directory/skills/davila7/evaluation-nemo-evaluator|evaluation-nemo-evaluator]], [[04-public-skills-directory/skills/davila7/prompt-engineering-dspy|prompt-engineering-dspy]], [[04-public-skills-directory/skills/davila7/distributed-training-deepspeed|distributed-training-deepspeed]], [[04-public-skills-directory/skills/davila7/distributed-training-megatron-core|distributed-training-megatron-core]], [[04-public-skills-directory/skills/davila7/distributed-training-pytorch-fsdp|distributed-training-pytorch-fsdp]]
- Registry seed skills for this role: [[03-skills/ai-ml/llm-systems/rag-engineer/README|rag-engineer seed skills]]
