---
type: public-skill
name: multimodal-whisper
owner: davila7
curator: Thomas Cherickal
source_repo: davila7/claude-code-templates
source_url: https://github.com/davila7/claude-code-templates/blob/HEAD/cli-tool/components/skills/ai-research/multimodal-whisper/SKILL.md
repo_stars: 33617
license: MIT
repo_last_push: 2026-11-14
roles: [local-ai-engineer]
categories: [ai-ml/llm-systems]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/local-ai-engineer, owner/davila7]
---

# multimodal-whisper

> OpenAI's general-purpose speech recognition model. Supports 99 languages, transcription, translation to English, and language identification. Six model sizes from tiny (39M params) to large (1550M params). Use for speech-to-text, podcast transcription, or multilingual audio processing. Best for robust, multilingual ASR.

| Field | Value |
|---|---|
| Owner | davila7 |
| Curator | Thomas Cherickal |
| Source | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates/blob/HEAD/cli-tool/components/skills/ai-research/multimodal-whisper/SKILL.md) |
| Repo stars | 33,617 |
| License | MIT |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/ai-ml/llm-systems/local-ai-engineer|local-ai-engineer]]
- Source repo: [[04-public-skills-directory/sources/davila7-claude-code-templates|davila7/claude-code-templates]]
- Same repo: [[04-public-skills-directory/skills/davila7/eval-genius|eval-genius]], [[04-public-skills-directory/skills/davila7/evaluation-bigcode-evaluation-harness|evaluation-bigcode-evaluation-harness]], [[04-public-skills-directory/skills/davila7/evaluation-lm-evaluation-harness|evaluation-lm-evaluation-harness]], [[04-public-skills-directory/skills/davila7/evaluation-nemo-evaluator|evaluation-nemo-evaluator]], [[04-public-skills-directory/skills/davila7/prompt-engineering-dspy|prompt-engineering-dspy]], [[04-public-skills-directory/skills/davila7/distributed-training-deepspeed|distributed-training-deepspeed]], [[04-public-skills-directory/skills/davila7/distributed-training-megatron-core|distributed-training-megatron-core]], [[04-public-skills-directory/skills/davila7/distributed-training-pytorch-fsdp|distributed-training-pytorch-fsdp]]
- Registry seed skills for this role: [[03-skills/ai-ml/llm-systems/local-ai-engineer/README|local-ai-engineer seed skills]]
