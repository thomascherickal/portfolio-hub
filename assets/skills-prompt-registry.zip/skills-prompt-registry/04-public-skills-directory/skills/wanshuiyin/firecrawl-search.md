---
type: public-skill
name: firecrawl-search
owner: wanshuiyin
curator: Thomas Cherickal
source_repo: wanshuiyin/Auto-claude-code-research-in-sleep
source_url: https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep/blob/HEAD/skills/skills-codex/firecrawl-search/SKILL.md
repo_stars: 19200
license: MIT
repo_last_push: 2026-11-14
roles: [industry-researcher]
categories: [research]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/industry-researcher, owner/wanshuiyin]
---

# firecrawl-search

> Web search and page scraping via Firecrawl, returning full-page markdown. Use when user says "firecrawl search", "firecrawl scrape" or "/firecrawl-search".

| Field | Value |
|---|---|
| Owner | wanshuiyin |
| Curator | Thomas Cherickal |
| Source | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep/blob/HEAD/skills/skills-codex/firecrawl-search/SKILL.md) |
| Repo stars | 19,200 |
| License | MIT |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/research/industry-researcher|industry-researcher]]
- Source repo: [[04-public-skills-directory/sources/wanshuiyin-auto-claude-code-research-in-sleep|wanshuiyin/Auto-claude-code-research-in-sleep]]
- Same repo: [[04-public-skills-directory/skills/wanshuiyin/render-html|render-html]], [[04-public-skills-directory/skills/wanshuiyin/mermaid-diagram|mermaid-diagram]], [[04-public-skills-directory/skills/wanshuiyin/specification-writing|specification-writing]], [[04-public-skills-directory/skills/wanshuiyin/ablation-planner|ablation-planner]], [[04-public-skills-directory/skills/wanshuiyin/arxiv|arxiv]], [[04-public-skills-directory/skills/wanshuiyin/experiment-plan|experiment-plan]], [[04-public-skills-directory/skills/wanshuiyin/novelty-check|novelty-check]], [[04-public-skills-directory/skills/wanshuiyin/openalex|openalex]]
- Registry seed skills for this role: [[03-skills/research/industry-researcher/README|industry-researcher seed skills]]
