---
type: public-skill
name: proof-checker
owner: wanshuiyin
curator: Thomas Cherickal
source_repo: wanshuiyin/Auto-claude-code-research-in-sleep
source_url: https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep/blob/HEAD/skills/skills-codex/proof-checker/SKILL.md
repo_stars: 19200
license: MIT
repo_last_push: 2026-11-14
roles: [quantum-computing-researcher]
categories: [quantum/research]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/quantum-computing-researcher, owner/wanshuiyin]
---

# proof-checker

> Rigorous mathematical proof verification and fixing workflow. Reads a LaTeX proof, identifies gaps via fresh-agent Codex GPT-6-Astra ultra review, fixes each gap with full derivations, re-reviews, and generates an audit report. Base review is same-family provisional. Use when user says "检查证明", "verify proof", "proof check", "审证明", "check this proof", or wants rigorous mathematical verification of...

| Field | Value |
|---|---|
| Owner | wanshuiyin |
| Curator | Thomas Cherickal |
| Source | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep/blob/HEAD/skills/skills-codex/proof-checker/SKILL.md) |
| Repo stars | 19,200 |
| License | MIT |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/quantum/research/quantum-computing-researcher|quantum-computing-researcher]]
- Source repo: [[04-public-skills-directory/sources/wanshuiyin-auto-claude-code-research-in-sleep|wanshuiyin/Auto-claude-code-research-in-sleep]]
- Same repo: [[04-public-skills-directory/skills/wanshuiyin/render-html|render-html]], [[04-public-skills-directory/skills/wanshuiyin/mermaid-diagram|mermaid-diagram]], [[04-public-skills-directory/skills/wanshuiyin/specification-writing|specification-writing]], [[04-public-skills-directory/skills/wanshuiyin/ablation-planner|ablation-planner]], [[04-public-skills-directory/skills/wanshuiyin/arxiv|arxiv]], [[04-public-skills-directory/skills/wanshuiyin/experiment-plan|experiment-plan]], [[04-public-skills-directory/skills/wanshuiyin/novelty-check|novelty-check]], [[04-public-skills-directory/skills/wanshuiyin/openalex|openalex]]
- Registry seed skills for this role: [[03-skills/quantum/research/quantum-computing-researcher/README|quantum-computing-researcher seed skills]]
