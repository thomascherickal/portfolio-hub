---
type: public-skill
name: specification-writing
owner: wanshuiyin
curator: Thomas Cherickal
source_repo: wanshuiyin/Auto-claude-code-research-in-sleep
source_url: https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep/blob/HEAD/skills/skills-codex/specification-writing/SKILL.md
repo_stars: 19200
license: MIT
repo_last_push: 2026-11-14
roles: [technical-writer]
categories: [design-and-content]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/technical-writer, owner/wanshuiyin]
---

# specification-writing

> Write the full patent specification from claims and invention disclosure. Use when user says \"撰写说明书\", \"write specification\", \"写说明书\", \"patent description\", or wants to draft the complete patent specification.

| Field | Value |
|---|---|
| Owner | wanshuiyin |
| Curator | Thomas Cherickal |
| Source | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep/blob/HEAD/skills/skills-codex/specification-writing/SKILL.md) |
| Repo stars | 19,200 |
| License | MIT |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/design-and-content/technical-writer|technical-writer]]
- Source repo: [[04-public-skills-directory/sources/wanshuiyin-auto-claude-code-research-in-sleep|wanshuiyin/Auto-claude-code-research-in-sleep]]
- Same repo: [[04-public-skills-directory/skills/wanshuiyin/render-html|render-html]], [[04-public-skills-directory/skills/wanshuiyin/mermaid-diagram|mermaid-diagram]], [[04-public-skills-directory/skills/wanshuiyin/ablation-planner|ablation-planner]], [[04-public-skills-directory/skills/wanshuiyin/arxiv|arxiv]], [[04-public-skills-directory/skills/wanshuiyin/experiment-plan|experiment-plan]], [[04-public-skills-directory/skills/wanshuiyin/novelty-check|novelty-check]], [[04-public-skills-directory/skills/wanshuiyin/openalex|openalex]], [[04-public-skills-directory/skills/wanshuiyin/formula-derivation|formula-derivation]]
- Registry seed skills for this role: [[03-skills/design-and-content/technical-writer/README|technical-writer seed skills]]
