---
type: public-skill
name: novelty-check
owner: wanshuiyin
curator: Thomas Cherickal
source_repo: wanshuiyin/Auto-claude-code-research-in-sleep
source_url: https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep/blob/HEAD/skills/skills-codex/novelty-check/SKILL.md
repo_stars: 19200
license: MIT
repo_last_push: 2026-11-14
roles: [research-scientist]
categories: [research]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/research-scientist, owner/wanshuiyin]
---

# novelty-check

> Verify research idea novelty against recent literature. Use when user says \"\u67e5\u65b0\", \"novelty check\", \"\u6709\u6ca1\u6709\u4eba\u505a\u8fc7\", \"check novelty\", or wants to verify a research idea is novel before implementing.

| Field | Value |
|---|---|
| Owner | wanshuiyin |
| Curator | Thomas Cherickal |
| Source | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep/blob/HEAD/skills/skills-codex/novelty-check/SKILL.md) |
| Repo stars | 19,200 |
| License | MIT |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/research/research-scientist|research-scientist]]
- Source repo: [[04-public-skills-directory/sources/wanshuiyin-auto-claude-code-research-in-sleep|wanshuiyin/Auto-claude-code-research-in-sleep]]
- Same repo: [[04-public-skills-directory/skills/wanshuiyin/render-html|render-html]], [[04-public-skills-directory/skills/wanshuiyin/mermaid-diagram|mermaid-diagram]], [[04-public-skills-directory/skills/wanshuiyin/specification-writing|specification-writing]], [[04-public-skills-directory/skills/wanshuiyin/ablation-planner|ablation-planner]], [[04-public-skills-directory/skills/wanshuiyin/arxiv|arxiv]], [[04-public-skills-directory/skills/wanshuiyin/experiment-plan|experiment-plan]], [[04-public-skills-directory/skills/wanshuiyin/openalex|openalex]], [[04-public-skills-directory/skills/wanshuiyin/formula-derivation|formula-derivation]]
- Registry seed skills for this role: [[03-skills/research/research-scientist/README|research-scientist seed skills]]
