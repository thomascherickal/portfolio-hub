---
type: public-skill
name: render-html
owner: wanshuiyin
curator: Thomas Cherickal
source_repo: wanshuiyin/Auto-claude-code-research-in-sleep
source_url: https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep/blob/HEAD/skills/skills-codex/render-html/SKILL.md
repo_stars: 19200
license: MIT
repo_last_push: 2026-11-14
roles: [pwa-engineer]
categories: [software-engineering/application]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/pwa-engineer, owner/wanshuiyin]
---

# render-html

> Render an ARIS Markdown / JSON artifact (IDEA_REPORT, AUTO_REVIEW, KILL_ARGUMENT, PAPER_PLAN, research-wiki state, etc.) into a single-file HTML view designed for human reading. Use when the user says \"渲染 HTML\", \"出一份 HTML 报告\", \"render html\", \"make this readable\", \"export to html\", or wants a polished web-rendered view of a Markdown artifact.

| Field | Value |
|---|---|
| Owner | wanshuiyin |
| Curator | Thomas Cherickal |
| Source | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep/blob/HEAD/skills/skills-codex/render-html/SKILL.md) |
| Repo stars | 19,200 |
| License | MIT |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/application/pwa-engineer|pwa-engineer]]
- Source repo: [[04-public-skills-directory/sources/wanshuiyin-auto-claude-code-research-in-sleep|wanshuiyin/Auto-claude-code-research-in-sleep]]
- Same repo: [[04-public-skills-directory/skills/wanshuiyin/mermaid-diagram|mermaid-diagram]], [[04-public-skills-directory/skills/wanshuiyin/specification-writing|specification-writing]], [[04-public-skills-directory/skills/wanshuiyin/ablation-planner|ablation-planner]], [[04-public-skills-directory/skills/wanshuiyin/arxiv|arxiv]], [[04-public-skills-directory/skills/wanshuiyin/experiment-plan|experiment-plan]], [[04-public-skills-directory/skills/wanshuiyin/novelty-check|novelty-check]], [[04-public-skills-directory/skills/wanshuiyin/openalex|openalex]], [[04-public-skills-directory/skills/wanshuiyin/formula-derivation|formula-derivation]]
- Registry seed skills for this role: [[03-skills/software-engineering/application/pwa-engineer/README|pwa-engineer seed skills]]
