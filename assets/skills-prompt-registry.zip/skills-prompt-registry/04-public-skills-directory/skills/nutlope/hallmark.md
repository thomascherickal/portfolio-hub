---
type: public-skill
name: hallmark
owner: Nutlope
curator: Thomas Cherickal
source_repo: Nutlope/hallmark
source_url: https://github.com/Nutlope/hallmark/blob/HEAD/skills/hallmark/SKILL.md
repo_stars: 54976
license: MIT
repo_last_push: 2026-11-11
roles: [web-designer]
categories: [design-and-content]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/web-designer, owner/nutlope]
---

# hallmark

> Design skill for websites and new pages that look designed, not generated. Use when the user asks to build or design something new, or names Hallmark. Never use it on an existing design unless the user names Hallmark, as in `/hallmark redesign <path>`.

| Field | Value |
|---|---|
| Owner | Nutlope |
| Curator | Thomas Cherickal |
| Source | [Nutlope/hallmark](https://github.com/Nutlope/hallmark/blob/HEAD/skills/hallmark/SKILL.md) |
| Repo stars | 54,976 |
| License | MIT |
| Repo last push | 2026-11-11 |

## Links

- Roles: [[04-public-skills-directory/roles/design-and-content/web-designer|web-designer]]
- Source repo: [[04-public-skills-directory/sources/nutlope-hallmark|Nutlope/hallmark]]
- Registry seed skills for this role: [[03-skills/design-and-content/web-designer/README|web-designer seed skills]]
