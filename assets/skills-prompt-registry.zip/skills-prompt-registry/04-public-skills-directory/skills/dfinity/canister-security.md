---
type: public-skill
name: canister-security
owner: dfinity
curator: Thomas Cherickal
source_repo: dfinity/icskills
source_url: https://github.com/dfinity/icskills/blob/HEAD/skills/canister-security/SKILL.md
repo_stars: 40
license: Apache-2.0
repo_last_push: 2026-11-14
roles: [blockchain-defi-engineer]
categories: [web3]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/blockchain-defi-engineer, owner/dfinity]
---

# canister-security

> IC-specific security patterns for canister development in Motoko and Rust. Covers access control, anonymous principal rejection, reentrancy prevention (CallerGuard pattern), async safety (saga pattern), callback trap handling, cycle drain protection, and safe upgrade patterns. Use when writing or modifying any canister that modifies state, handles tokens, makes inter-canister calls, or implements...

| Field | Value |
|---|---|
| Owner | dfinity |
| Curator | Thomas Cherickal |
| Source | [dfinity/icskills](https://github.com/dfinity/icskills/blob/HEAD/skills/canister-security/SKILL.md) |
| Repo stars | 40 |
| License | Apache-2.0 |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/web3/blockchain-defi-engineer|blockchain-defi-engineer]]
- Source repo: [[04-public-skills-directory/sources/dfinity-icskills|dfinity/icskills]]
- Same repo: [[04-public-skills-directory/skills/dfinity/static-site|static-site]]
- Registry seed skills for this role: [[03-skills/web3/blockchain-defi-engineer/README|blockchain-defi-engineer seed skills]]
