---
type: public-skill
name: static-site
owner: dfinity
curator: Thomas Cherickal
source_repo: dfinity/icskills
source_url: https://github.com/dfinity/icskills/blob/HEAD/skills/static-site/SKILL.md
repo_stars: 40
license: Apache-2.0
repo_last_push: 2026-11-14
roles: [pwa-engineer]
categories: [software-engineering/application]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/pwa-engineer, owner/dfinity]
---

# static-site

> Deploy a frontend or any static site to the IC with the @dfinity/static-site recipe (the certified-assets canister). Covers icp.yaml recipe config, SPA routing with _redirects, custom headers/CSP with _headers, clean URLs, access protection for private apps, custom domains, and building against canister IDs. This is the recommended way to host frontends and static files on the IC. Also the entry...

| Field | Value |
|---|---|
| Owner | dfinity |
| Curator | Thomas Cherickal |
| Source | [dfinity/icskills](https://github.com/dfinity/icskills/blob/HEAD/skills/static-site/SKILL.md) |
| Repo stars | 40 |
| License | Apache-2.0 |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/application/pwa-engineer|pwa-engineer]]
- Source repo: [[04-public-skills-directory/sources/dfinity-icskills|dfinity/icskills]]
- Same repo: [[04-public-skills-directory/skills/dfinity/canister-security|canister-security]]
- Registry seed skills for this role: [[03-skills/software-engineering/application/pwa-engineer/README|pwa-engineer seed skills]]
