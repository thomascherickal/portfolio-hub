---
type: public-skill
name: a11y-audit
owner: alirezarezvani
curator: Thomas Cherickal
source_repo: alirezarezvani/claude-skills
source_url: https://github.com/alirezarezvani/claude-skills/blob/HEAD/engineering-team/a11y-audit/skills/a11y-audit/SKILL.md
repo_stars: 29806
license: MIT
repo_last_push: 2026-11-12
roles: [frontend-engineer]
categories: [software-engineering/application]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/frontend-engineer, owner/alirezarezvani]
---

# a11y-audit

> Use for any accessibility audit or a11y fix (WCAG 2.2 A/AA, color contrast, compliance report, CI check) in React, Next.js, Vue, Angular, Svelte or HTML. Scans with a11y_scanner.py and checks contrast with contrast_checker.py, then fixes and re-verifies.

| Field | Value |
|---|---|
| Owner | alirezarezvani |
| Curator | Thomas Cherickal |
| Source | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills/blob/HEAD/engineering-team/a11y-audit/skills/a11y-audit/SKILL.md) |
| Repo stars | 29,806 |
| License | MIT |
| Repo last push | 2026-11-12 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/application/frontend-engineer|frontend-engineer]]
- Source repo: [[04-public-skills-directory/sources/alirezarezvani-claude-skills|alirezarezvani/claude-skills]]
- Same repo: [[04-public-skills-directory/skills/alirezarezvani/tdd-guide|tdd-guide]], [[04-public-skills-directory/skills/alirezarezvani/api-design-reviewer|api-design-reviewer]], [[04-public-skills-directory/skills/alirezarezvani/cs-backend-engineer|cs-backend-engineer]], [[04-public-skills-directory/skills/alirezarezvani/cs-backend-review|cs-backend-review]], [[04-public-skills-directory/skills/alirezarezvani/cs-fullstack-engineer|cs-fullstack-engineer]], [[04-public-skills-directory/skills/alirezarezvani/cs-fullstack-review|cs-fullstack-review]], [[04-public-skills-directory/skills/alirezarezvani/saas-health|saas-health]], [[04-public-skills-directory/skills/alirezarezvani/saas-metrics-coach|saas-metrics-coach]]
- Registry seed skills for this role: [[03-skills/software-engineering/application/frontend-engineer/README|frontend-engineer seed skills]]
