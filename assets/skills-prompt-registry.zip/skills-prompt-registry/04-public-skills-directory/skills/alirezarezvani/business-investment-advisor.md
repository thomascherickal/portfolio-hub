---
type: public-skill
name: business-investment-advisor
owner: alirezarezvani
curator: Thomas Cherickal
source_repo: alirezarezvani/claude-skills
source_url: https://github.com/alirezarezvani/claude-skills/blob/HEAD/finance/business-investment-advisor/skills/business-investment-advisor/SKILL.md
repo_stars: 29806
license: MIT
repo_last_push: 2026-11-12
roles: [genai-consultant]
categories: [consulting]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/genai-consultant, owner/alirezarezvani]
---

# business-investment-advisor

> Use when deciding whether a capital expense is worth it (equipment, property, an acquisition, hiring, technology), or for ROI, IRR, NPV, payback, build vs buy or lease vs buy.

| Field | Value |
|---|---|
| Owner | alirezarezvani |
| Curator | Thomas Cherickal |
| Source | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills/blob/HEAD/finance/business-investment-advisor/skills/business-investment-advisor/SKILL.md) |
| Repo stars | 29,806 |
| License | MIT |
| Repo last push | 2026-11-12 |

## Links

- Roles: [[04-public-skills-directory/roles/consulting/genai-consultant|genai-consultant]]
- Source repo: [[04-public-skills-directory/sources/alirezarezvani-claude-skills|alirezarezvani/claude-skills]]
- Same repo: [[04-public-skills-directory/skills/alirezarezvani/tdd-guide|tdd-guide]], [[04-public-skills-directory/skills/alirezarezvani/api-design-reviewer|api-design-reviewer]], [[04-public-skills-directory/skills/alirezarezvani/cs-backend-engineer|cs-backend-engineer]], [[04-public-skills-directory/skills/alirezarezvani/cs-backend-review|cs-backend-review]], [[04-public-skills-directory/skills/alirezarezvani/a11y-audit|a11y-audit]], [[04-public-skills-directory/skills/alirezarezvani/cs-fullstack-engineer|cs-fullstack-engineer]], [[04-public-skills-directory/skills/alirezarezvani/cs-fullstack-review|cs-fullstack-review]], [[04-public-skills-directory/skills/alirezarezvani/saas-health|saas-health]]
- Registry seed skills for this role: [[03-skills/consulting/genai-consultant/README|genai-consultant seed skills]]
