---
type: public-skill
name: api-design-reviewer
owner: alirezarezvani
curator: Thomas Cherickal
source_repo: alirezarezvani/claude-skills
source_url: https://github.com/alirezarezvani/claude-skills/blob/HEAD/engineering/skills/api-design-reviewer/SKILL.md
repo_stars: 29806
license: MIT
repo_last_push: 2026-11-12
roles: [backend-engineer]
categories: [software-engineering/application]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/backend-engineer, owner/alirezarezvani]
---

# api-design-reviewer

> Use for any PR or spec that adds or changes REST endpoints, before approving it. Lints conventions with api_linter.py, detects breaking changes with breaking_change_detector.py and scores the design with api_scorecard.py.

| Field | Value |
|---|---|
| Owner | alirezarezvani |
| Curator | Thomas Cherickal |
| Source | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills/blob/HEAD/engineering/skills/api-design-reviewer/SKILL.md) |
| Repo stars | 29,806 |
| License | MIT |
| Repo last push | 2026-11-12 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/application/backend-engineer|backend-engineer]]
- Source repo: [[04-public-skills-directory/sources/alirezarezvani-claude-skills|alirezarezvani/claude-skills]]
- Same repo: [[04-public-skills-directory/skills/alirezarezvani/tdd-guide|tdd-guide]], [[04-public-skills-directory/skills/alirezarezvani/cs-backend-engineer|cs-backend-engineer]], [[04-public-skills-directory/skills/alirezarezvani/cs-backend-review|cs-backend-review]], [[04-public-skills-directory/skills/alirezarezvani/a11y-audit|a11y-audit]], [[04-public-skills-directory/skills/alirezarezvani/cs-fullstack-engineer|cs-fullstack-engineer]], [[04-public-skills-directory/skills/alirezarezvani/cs-fullstack-review|cs-fullstack-review]], [[04-public-skills-directory/skills/alirezarezvani/saas-health|saas-health]], [[04-public-skills-directory/skills/alirezarezvani/saas-metrics-coach|saas-metrics-coach]]
- Registry seed skills for this role: [[03-skills/software-engineering/application/backend-engineer/README|backend-engineer seed skills]]
