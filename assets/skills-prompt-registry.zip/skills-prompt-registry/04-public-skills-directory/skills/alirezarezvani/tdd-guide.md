---
type: public-skill
name: tdd-guide
owner: alirezarezvani
curator: Thomas Cherickal
source_repo: alirezarezvani/claude-skills
source_url: https://github.com/alirezarezvani/claude-skills/blob/HEAD/engineering-team/skills/tdd-guide/SKILL.md
repo_stars: 29806
license: MIT
repo_last_push: 2026-11-12
roles: [software-engineer]
categories: [software-engineering/general]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/software-engineer, owner/alirezarezvani]
---

# tdd-guide

> Test-first development and test generation for Jest, Pytest, JUnit, Vitest or Mocha: red-green-refactor, fixtures and mocks, coverage gaps. Use whenever the user asks to write tests (before or after the code), mock a dependency or raise coverage.

| Field | Value |
|---|---|
| Owner | alirezarezvani |
| Curator | Thomas Cherickal |
| Source | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills/blob/HEAD/engineering-team/skills/tdd-guide/SKILL.md) |
| Repo stars | 29,806 |
| License | MIT |
| Repo last push | 2026-11-12 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/general/software-engineer|software-engineer]]
- Source repo: [[04-public-skills-directory/sources/alirezarezvani-claude-skills|alirezarezvani/claude-skills]]
- Same repo: [[04-public-skills-directory/skills/alirezarezvani/api-design-reviewer|api-design-reviewer]], [[04-public-skills-directory/skills/alirezarezvani/cs-backend-engineer|cs-backend-engineer]], [[04-public-skills-directory/skills/alirezarezvani/cs-backend-review|cs-backend-review]], [[04-public-skills-directory/skills/alirezarezvani/a11y-audit|a11y-audit]], [[04-public-skills-directory/skills/alirezarezvani/cs-fullstack-engineer|cs-fullstack-engineer]], [[04-public-skills-directory/skills/alirezarezvani/cs-fullstack-review|cs-fullstack-review]], [[04-public-skills-directory/skills/alirezarezvani/saas-health|saas-health]], [[04-public-skills-directory/skills/alirezarezvani/saas-metrics-coach|saas-metrics-coach]]
- Registry seed skills for this role: [[03-skills/software-engineering/general/software-engineer/README|software-engineer seed skills]]
