---
type: public-skill
name: systems-paper-writing
owner: Orchestra-Research
curator: Thomas Cherickal
source_repo: Orchestra-Research/AI-Research-SKILLs
source_url: https://github.com/Orchestra-Research/AI-Research-SKILLs/blob/HEAD/20-ml-paper-writing/systems-paper-writing/SKILL.md
repo_stars: 14542
license: MIT
repo_last_push: 2026-10-11
roles: [research-scientist]
categories: [research]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/research-scientist, owner/orchestra-research]
---

# systems-paper-writing

> Comprehensive guide for writing systems papers targeting OSDI, SOSP, ASPLOS, NSDI, and EuroSys. Provides paragraph-level structural blueprints, writing patterns, venue-specific checklists, reviewer guidelines, LaTeX templates, and conference deadlines. Use this skill for all systems conference paper writing.

| Field | Value |
|---|---|
| Owner | Orchestra-Research |
| Curator | Thomas Cherickal |
| Source | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs/blob/HEAD/20-ml-paper-writing/systems-paper-writing/SKILL.md) |
| Repo stars | 14,542 |
| License | MIT |
| Repo last push | 2026-10-11 |

## Links

- Roles: [[04-public-skills-directory/roles/research/research-scientist|research-scientist]]
- Source repo: [[04-public-skills-directory/sources/orchestra-research-ai-research-skills|Orchestra-Research/AI-Research-SKILLs]]
- Same repo: [[04-public-skills-directory/skills/orchestra-research/axolotl|axolotl]], [[04-public-skills-directory/skills/orchestra-research/deepspeed|deepspeed]], [[04-public-skills-directory/skills/orchestra-research/distributed-llm-pretraining-torchtitan|distributed-llm-pretraining-torchtitan]], [[04-public-skills-directory/skills/orchestra-research/fine-tuning-openvla-oft|fine-tuning-openvla-oft]], [[04-public-skills-directory/skills/orchestra-research/fine-tuning-serving-openpi|fine-tuning-serving-openpi]], [[04-public-skills-directory/skills/orchestra-research/awq-quantization|awq-quantization]], [[04-public-skills-directory/skills/orchestra-research/gguf-quantization|gguf-quantization]], [[04-public-skills-directory/skills/orchestra-research/gptq|gptq]]
- Registry seed skills for this role: [[03-skills/research/research-scientist/README|research-scientist seed skills]]
