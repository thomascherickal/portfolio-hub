---
type: public-skill
name: mamba-architecture
owner: Orchestra-Research
curator: Thomas Cherickal
source_repo: Orchestra-Research/AI-Research-SKILLs
source_url: https://github.com/Orchestra-Research/AI-Research-SKILLs/blob/HEAD/01-model-architecture/mamba/SKILL.md
repo_stars: 14542
license: MIT
repo_last_push: 2026-10-11
roles: [quantum-ml-engineer]
categories: [quantum/engineering]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/quantum-ml-engineer, owner/orchestra-research]
---

# mamba-architecture

> State-space model with O(n) complexity vs Transformers' O(n²). 5× faster inference, million-token sequences, no KV cache. Selective SSM with hardware-aware design. Mamba-1 (d_state=16) and Mamba-2 (d_state=128, multi-head). Models 130M-2.8B on HuggingFace.

| Field | Value |
|---|---|
| Owner | Orchestra-Research |
| Curator | Thomas Cherickal |
| Source | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs/blob/HEAD/01-model-architecture/mamba/SKILL.md) |
| Repo stars | 14,542 |
| License | MIT |
| Repo last push | 2026-10-11 |

## Links

- Roles: [[04-public-skills-directory/roles/quantum/engineering/quantum-ml-engineer|quantum-ml-engineer]]
- Source repo: [[04-public-skills-directory/sources/orchestra-research-ai-research-skills|Orchestra-Research/AI-Research-SKILLs]]
- Same repo: [[04-public-skills-directory/skills/orchestra-research/axolotl|axolotl]], [[04-public-skills-directory/skills/orchestra-research/deepspeed|deepspeed]], [[04-public-skills-directory/skills/orchestra-research/distributed-llm-pretraining-torchtitan|distributed-llm-pretraining-torchtitan]], [[04-public-skills-directory/skills/orchestra-research/fine-tuning-openvla-oft|fine-tuning-openvla-oft]], [[04-public-skills-directory/skills/orchestra-research/fine-tuning-serving-openpi|fine-tuning-serving-openpi]], [[04-public-skills-directory/skills/orchestra-research/awq-quantization|awq-quantization]], [[04-public-skills-directory/skills/orchestra-research/gguf-quantization|gguf-quantization]], [[04-public-skills-directory/skills/orchestra-research/gptq|gptq]]
- Registry seed skills for this role: [[03-skills/quantum/engineering/quantum-ml-engineer/README|quantum-ml-engineer seed skills]]
