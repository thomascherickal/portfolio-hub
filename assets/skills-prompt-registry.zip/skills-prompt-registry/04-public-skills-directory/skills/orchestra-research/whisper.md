---
type: public-skill
name: whisper
owner: Orchestra-Research
curator: Thomas Cherickal
source_repo: Orchestra-Research/AI-Research-SKILLs
source_url: https://github.com/Orchestra-Research/AI-Research-SKILLs/blob/HEAD/18-multimodal/whisper/SKILL.md
repo_stars: 14542
license: MIT
repo_last_push: 2026-10-11
roles: [local-ai-engineer]
categories: [ai-ml/llm-systems]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/local-ai-engineer, owner/orchestra-research]
---

# whisper

> OpenAI's general-purpose speech recognition model. Supports 99 languages, transcription, translation to English, and language identification. Six model sizes from tiny (39M params) to large (1550M params). Use for speech-to-text, podcast transcription, or multilingual audio processing. Best for robust, multilingual ASR.

| Field | Value |
|---|---|
| Owner | Orchestra-Research |
| Curator | Thomas Cherickal |
| Source | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs/blob/HEAD/18-multimodal/whisper/SKILL.md) |
| Repo stars | 14,542 |
| License | MIT |
| Repo last push | 2026-10-11 |

## Links

- Roles: [[04-public-skills-directory/roles/ai-ml/llm-systems/local-ai-engineer|local-ai-engineer]]
- Source repo: [[04-public-skills-directory/sources/orchestra-research-ai-research-skills|Orchestra-Research/AI-Research-SKILLs]]
- Same repo: [[04-public-skills-directory/skills/orchestra-research/axolotl|axolotl]], [[04-public-skills-directory/skills/orchestra-research/deepspeed|deepspeed]], [[04-public-skills-directory/skills/orchestra-research/distributed-llm-pretraining-torchtitan|distributed-llm-pretraining-torchtitan]], [[04-public-skills-directory/skills/orchestra-research/fine-tuning-openvla-oft|fine-tuning-openvla-oft]], [[04-public-skills-directory/skills/orchestra-research/fine-tuning-serving-openpi|fine-tuning-serving-openpi]], [[04-public-skills-directory/skills/orchestra-research/awq-quantization|awq-quantization]], [[04-public-skills-directory/skills/orchestra-research/gguf-quantization|gguf-quantization]], [[04-public-skills-directory/skills/orchestra-research/gptq|gptq]]
- Registry seed skills for this role: [[03-skills/ai-ml/llm-systems/local-ai-engineer/README|local-ai-engineer seed skills]]
