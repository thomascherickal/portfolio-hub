---
type: public-skill
name: agent-evaluation
owner: sickn33
curator: Thomas Cherickal
source_repo: sickn33/agentic-awesome-skills
source_url: https://github.com/sickn33/agentic-awesome-skills/blob/HEAD/skills/agent-evaluation/SKILL.md
repo_stars: 49710
license: MIT
repo_last_push: 2026-11-14
roles: [ai-engineer, genai-engineer]
categories: [ai-ml/applied-ai]
mirrors: [davila7/claude-code-templates]
status: listed
collected: 2026-11-15
tags: [public-skill, role/ai-engineer, role/genai-engineer, owner/sickn33]
---

# agent-evaluation

> Evaluate agent behavior with versioned cases and explicit verifiers. Use when comparing agent or prompt changes, reproducing failures, or running agent regression tests.

| Field | Value |
|---|---|
| Owner | sickn33 |
| Curator | Thomas Cherickal |
| Source | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills/blob/HEAD/skills/agent-evaluation/SKILL.md) |
| Repo stars | 49,710 |
| License | MIT |
| Repo last push | 2026-11-14 |
| Also published in | davila7/claude-code-templates |

## Links

- Roles: [[04-public-skills-directory/roles/ai-ml/applied-ai/ai-engineer|ai-engineer]], [[04-public-skills-directory/roles/ai-ml/applied-ai/genai-engineer|genai-engineer]]
- Source repo: [[04-public-skills-directory/sources/sickn33-agentic-awesome-skills|sickn33/agentic-awesome-skills]]
- Same repo: [[04-public-skills-directory/skills/sickn33/advanced-evaluation|advanced-evaluation]], [[04-public-skills-directory/skills/sickn33/agent-evals|agent-evals]], [[04-public-skills-directory/skills/sickn33/agent-evaluation-reporting|agent-evaluation-reporting]], [[04-public-skills-directory/skills/sickn33/agent-observability|agent-observability]], [[04-public-skills-directory/skills/sickn33/huggingface-lora-space-builder|huggingface-lora-space-builder]], [[04-public-skills-directory/skills/sickn33/llm-fine-tuning|llm-fine-tuning]], [[04-public-skills-directory/skills/sickn33/trl-training|trl-training]], [[04-public-skills-directory/skills/sickn33/unsloth-finetuning|unsloth-finetuning]]
- Registry seed skills for this role: [[03-skills/ai-ml/applied-ai/ai-engineer/README|ai-engineer seed skills]]
