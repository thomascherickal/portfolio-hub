---
type: public-skill
name: api-documenter
owner: sickn33
curator: Thomas Cherickal
source_repo: sickn33/agentic-awesome-skills
source_url: https://github.com/sickn33/agentic-awesome-skills/blob/HEAD/skills/api-documenter/SKILL.md
repo_stars: 49710
license: MIT
repo_last_push: 2026-11-14
roles: [technical-writer]
categories: [design-and-content]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/technical-writer, owner/sickn33]
---

# api-documenter

> Master API documentation with OpenAPI 3.1, AI-powered tools, and modern developer experience practices. Create interactive docs, generate SDKs, and build comprehensive developer portals.

| Field | Value |
|---|---|
| Owner | sickn33 |
| Curator | Thomas Cherickal |
| Source | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills/blob/HEAD/skills/api-documenter/SKILL.md) |
| Repo stars | 49,710 |
| License | MIT |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/design-and-content/technical-writer|technical-writer]]
- Source repo: [[04-public-skills-directory/sources/sickn33-agentic-awesome-skills|sickn33/agentic-awesome-skills]]
- Same repo: [[04-public-skills-directory/skills/sickn33/advanced-evaluation|advanced-evaluation]], [[04-public-skills-directory/skills/sickn33/agent-evals|agent-evals]], [[04-public-skills-directory/skills/sickn33/agent-evaluation|agent-evaluation]], [[04-public-skills-directory/skills/sickn33/agent-evaluation-reporting|agent-evaluation-reporting]], [[04-public-skills-directory/skills/sickn33/agent-observability|agent-observability]], [[04-public-skills-directory/skills/sickn33/huggingface-lora-space-builder|huggingface-lora-space-builder]], [[04-public-skills-directory/skills/sickn33/llm-fine-tuning|llm-fine-tuning]], [[04-public-skills-directory/skills/sickn33/trl-training|trl-training]]
- Registry seed skills for this role: [[03-skills/design-and-content/technical-writer/README|technical-writer seed skills]]
