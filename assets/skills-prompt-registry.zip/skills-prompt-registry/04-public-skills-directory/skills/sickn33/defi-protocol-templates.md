---
type: public-skill
name: defi-protocol-templates
owner: sickn33
curator: Thomas Cherickal
source_repo: sickn33/agentic-awesome-skills
source_url: https://github.com/sickn33/agentic-awesome-skills/blob/HEAD/skills/defi-protocol-templates/SKILL.md
repo_stars: 49710
license: MIT
repo_last_push: 2026-11-14
roles: [blockchain-defi-engineer]
categories: [web3]
mirrors: [wshobson/agents]
status: listed
collected: 2026-11-15
tags: [public-skill, role/blockchain-defi-engineer, owner/sickn33]
---

# defi-protocol-templates

> Implement DeFi protocols with educational templates for staking, AMMs, governance, and lending systems. Use when building decentralized finance applications or smart contract protocols.

| Field | Value |
|---|---|
| Owner | sickn33 |
| Curator | Thomas Cherickal |
| Source | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills/blob/HEAD/skills/defi-protocol-templates/SKILL.md) |
| Repo stars | 49,710 |
| License | MIT |
| Repo last push | 2026-11-14 |
| Also published in | wshobson/agents |

## Links

- Roles: [[04-public-skills-directory/roles/web3/blockchain-defi-engineer|blockchain-defi-engineer]]
- Source repo: [[04-public-skills-directory/sources/sickn33-agentic-awesome-skills|sickn33/agentic-awesome-skills]]
- Same repo: [[04-public-skills-directory/skills/sickn33/advanced-evaluation|advanced-evaluation]], [[04-public-skills-directory/skills/sickn33/agent-evals|agent-evals]], [[04-public-skills-directory/skills/sickn33/agent-evaluation|agent-evaluation]], [[04-public-skills-directory/skills/sickn33/agent-evaluation-reporting|agent-evaluation-reporting]], [[04-public-skills-directory/skills/sickn33/agent-observability|agent-observability]], [[04-public-skills-directory/skills/sickn33/huggingface-lora-space-builder|huggingface-lora-space-builder]], [[04-public-skills-directory/skills/sickn33/llm-fine-tuning|llm-fine-tuning]], [[04-public-skills-directory/skills/sickn33/trl-training|trl-training]]
- Registry seed skills for this role: [[03-skills/web3/blockchain-defi-engineer/README|blockchain-defi-engineer seed skills]]
