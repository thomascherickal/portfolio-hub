---
type: public-skill
name: go-rust-reverse
owner: sickn33
curator: Thomas Cherickal
source_repo: sickn33/agentic-awesome-skills
source_url: https://github.com/sickn33/agentic-awesome-skills/blob/HEAD/skills/go-rust-reverse/SKILL.md
repo_stars: 49710
license: MIT
repo_last_push: 2026-11-14
roles: [rust-engineer, go-engineer]
categories: [software-engineering/languages]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/rust-engineer, role/go-engineer, owner/sickn33]
---

# go-rust-reverse

> Reverse engineer stripped Go and Rust binaries: runtime recognition, pclntab/module metadata recovery, panic-string analysis, and idiomatic decompilation strategies.

| Field | Value |
|---|---|
| Owner | sickn33 |
| Curator | Thomas Cherickal |
| Source | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills/blob/HEAD/skills/go-rust-reverse/SKILL.md) |
| Repo stars | 49,710 |
| License | MIT |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/languages/rust-engineer|rust-engineer]], [[04-public-skills-directory/roles/software-engineering/languages/go-engineer|go-engineer]]
- Source repo: [[04-public-skills-directory/sources/sickn33-agentic-awesome-skills|sickn33/agentic-awesome-skills]]
- Same repo: [[04-public-skills-directory/skills/sickn33/advanced-evaluation|advanced-evaluation]], [[04-public-skills-directory/skills/sickn33/agent-evals|agent-evals]], [[04-public-skills-directory/skills/sickn33/agent-evaluation|agent-evaluation]], [[04-public-skills-directory/skills/sickn33/agent-evaluation-reporting|agent-evaluation-reporting]], [[04-public-skills-directory/skills/sickn33/agent-observability|agent-observability]], [[04-public-skills-directory/skills/sickn33/huggingface-lora-space-builder|huggingface-lora-space-builder]], [[04-public-skills-directory/skills/sickn33/llm-fine-tuning|llm-fine-tuning]], [[04-public-skills-directory/skills/sickn33/trl-training|trl-training]]
- Registry seed skills for this role: [[03-skills/software-engineering/languages/rust-engineer/README|rust-engineer seed skills]]
