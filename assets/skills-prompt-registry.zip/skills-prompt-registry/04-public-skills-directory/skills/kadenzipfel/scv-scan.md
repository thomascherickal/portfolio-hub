---
type: public-skill
name: scv-scan
owner: kadenzipfel
curator: Thomas Cherickal
source_repo: kadenzipfel/scv-scan
source_url: https://github.com/kadenzipfel/scv-scan/blob/HEAD/SKILL.md
repo_stars: 110
license: null
repo_last_push: 2026-03-11
roles: [blockchain-defi-engineer]
categories: [web3]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/blockchain-defi-engineer, owner/kadenzipfel]
---

# scv-scan

> Systematically audit Solidity smart contract codebases for security vulnerabilities using a 4-phase approach - load a vulnerability cheatsheet, sweep code with grep and semantic analysis, deep-validate candidates against reference files, and output a severity-ranked findings

| Field | Value |
|---|---|
| Owner | kadenzipfel |
| Curator | Thomas Cherickal |
| Source | [kadenzipfel/scv-scan](https://github.com/kadenzipfel/scv-scan/blob/HEAD/SKILL.md) |
| Repo stars | 110 |
| License | null |
| Repo last push | 2026-03-11 |

## Links

- Roles: [[04-public-skills-directory/roles/web3/blockchain-defi-engineer|blockchain-defi-engineer]]
- Source repo: [[04-public-skills-directory/sources/kadenzipfel-scv-scan|kadenzipfel/scv-scan]]
- Registry seed skills for this role: [[03-skills/web3/blockchain-defi-engineer/README|blockchain-defi-engineer seed skills]]
