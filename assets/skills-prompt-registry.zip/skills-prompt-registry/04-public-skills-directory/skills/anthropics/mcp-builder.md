---
type: public-skill
name: mcp-builder
owner: anthropics
curator: Thomas Cherickal
source_repo: anthropics/skills
source_url: https://github.com/anthropics/skills/blob/HEAD/skills/mcp-builder/SKILL.md
repo_stars: 194585
license: null
repo_last_push: 2026-11-14
roles: [genai-engineer]
categories: [ai-ml/applied-ai]
mirrors: [davila7/claude-code-templates, sickn33/agentic-awesome-skills]
status: listed
collected: 2026-11-15
tags: [public-skill, role/genai-engineer, owner/anthropics]
---

# mcp-builder

> Guide for creating high-quality MCP (Model Context Protocol) servers that enable LLMs to interact with external services through well-designed tools. Use when building MCP servers to integrate external APIs or services, whether in Python (FastMCP) or Node/TypeScript (MCP SDK).

| Field | Value |
|---|---|
| Owner | anthropics |
| Curator | Thomas Cherickal |
| Source | [anthropics/skills](https://github.com/anthropics/skills/blob/HEAD/skills/mcp-builder/SKILL.md) |
| Repo stars | 194,585 |
| License | null |
| Repo last push | 2026-11-14 |
| Also published in | davila7/claude-code-templates, sickn33/agentic-awesome-skills |

## Links

- Roles: [[04-public-skills-directory/roles/ai-ml/applied-ai/genai-engineer|genai-engineer]]
- Source repo: [[04-public-skills-directory/sources/anthropics-skills|anthropics/skills]]
- Same repo: [[04-public-skills-directory/skills/anthropics/claude-api|claude-api]], [[04-public-skills-directory/skills/anthropics/skill-creator|skill-creator]], [[04-public-skills-directory/skills/anthropics/frontend-design|frontend-design]], [[04-public-skills-directory/skills/anthropics/webapp-testing|webapp-testing]], [[04-public-skills-directory/skills/anthropics/web-artifacts-builder|web-artifacts-builder]], [[04-public-skills-directory/skills/anthropics/doc-coauthoring|doc-coauthoring]], [[04-public-skills-directory/skills/anthropics/brand-guidelines|brand-guidelines]], [[04-public-skills-directory/skills/anthropics/canvas-design|canvas-design]]
- Registry seed skills for this role: [[03-skills/ai-ml/applied-ai/genai-engineer/README|genai-engineer seed skills]]
