---
type: public-skill
name: skill-creator
owner: anthropics
curator: Thomas Cherickal
source_repo: anthropics/skills
source_url: https://github.com/anthropics/skills/blob/HEAD/skills/skill-creator/SKILL.md
repo_stars: 194585
license: null
repo_last_push: 2026-11-14
roles: [ai-engineer]
categories: [ai-ml/applied-ai]
mirrors: [davila7/claude-code-templates, dfinity/icskills, sickn33/agentic-awesome-skills]
status: listed
collected: 2026-11-15
tags: [public-skill, role/ai-engineer, owner/anthropics]
---

# skill-creator

> Create new skills, modify and improve existing skills, and measure skill performance. Use when users want to create a skill from scratch, edit, or optimize an existing skill, run evals to test a skill, benchmark skill performance with variance analysis, or optimize a skill's description for better triggering accuracy.

| Field | Value |
|---|---|
| Owner | anthropics |
| Curator | Thomas Cherickal |
| Source | [anthropics/skills](https://github.com/anthropics/skills/blob/HEAD/skills/skill-creator/SKILL.md) |
| Repo stars | 194,585 |
| License | null |
| Repo last push | 2026-11-14 |
| Also published in | davila7/claude-code-templates, dfinity/icskills, sickn33/agentic-awesome-skills |

## Links

- Roles: [[04-public-skills-directory/roles/ai-ml/applied-ai/ai-engineer|ai-engineer]]
- Source repo: [[04-public-skills-directory/sources/anthropics-skills|anthropics/skills]]
- Same repo: [[04-public-skills-directory/skills/anthropics/claude-api|claude-api]], [[04-public-skills-directory/skills/anthropics/frontend-design|frontend-design]], [[04-public-skills-directory/skills/anthropics/webapp-testing|webapp-testing]], [[04-public-skills-directory/skills/anthropics/web-artifacts-builder|web-artifacts-builder]], [[04-public-skills-directory/skills/anthropics/mcp-builder|mcp-builder]], [[04-public-skills-directory/skills/anthropics/doc-coauthoring|doc-coauthoring]], [[04-public-skills-directory/skills/anthropics/brand-guidelines|brand-guidelines]], [[04-public-skills-directory/skills/anthropics/canvas-design|canvas-design]]
- Registry seed skills for this role: [[03-skills/ai-ml/applied-ai/ai-engineer/README|ai-engineer seed skills]]
