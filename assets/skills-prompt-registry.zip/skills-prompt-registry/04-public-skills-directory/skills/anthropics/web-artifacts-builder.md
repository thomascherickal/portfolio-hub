---
type: public-skill
name: web-artifacts-builder
owner: anthropics
curator: Thomas Cherickal
source_repo: anthropics/skills
source_url: https://github.com/anthropics/skills/blob/HEAD/skills/web-artifacts-builder/SKILL.md
repo_stars: 194585
license: null
repo_last_push: 2026-11-14
roles: [fullstack-engineer]
categories: [software-engineering/application]
mirrors: [davila7/claude-code-templates, sickn33/agentic-awesome-skills]
status: listed
collected: 2026-11-15
tags: [public-skill, role/fullstack-engineer, owner/anthropics]
---

# web-artifacts-builder

> Suite of tools for creating elaborate, multi-component claude.ai HTML artifacts using modern frontend web technologies (React, Tailwind CSS, shadcn/ui). Use for complex artifacts requiring state management, routing, or shadcn/ui components - not for simple single-file HTML/JSX artifacts.

| Field | Value |
|---|---|
| Owner | anthropics |
| Curator | Thomas Cherickal |
| Source | [anthropics/skills](https://github.com/anthropics/skills/blob/HEAD/skills/web-artifacts-builder/SKILL.md) |
| Repo stars | 194,585 |
| License | null |
| Repo last push | 2026-11-14 |
| Also published in | davila7/claude-code-templates, sickn33/agentic-awesome-skills |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/application/fullstack-engineer|fullstack-engineer]]
- Source repo: [[04-public-skills-directory/sources/anthropics-skills|anthropics/skills]]
- Same repo: [[04-public-skills-directory/skills/anthropics/claude-api|claude-api]], [[04-public-skills-directory/skills/anthropics/skill-creator|skill-creator]], [[04-public-skills-directory/skills/anthropics/frontend-design|frontend-design]], [[04-public-skills-directory/skills/anthropics/webapp-testing|webapp-testing]], [[04-public-skills-directory/skills/anthropics/mcp-builder|mcp-builder]], [[04-public-skills-directory/skills/anthropics/doc-coauthoring|doc-coauthoring]], [[04-public-skills-directory/skills/anthropics/brand-guidelines|brand-guidelines]], [[04-public-skills-directory/skills/anthropics/canvas-design|canvas-design]]
- Registry seed skills for this role: [[03-skills/software-engineering/application/fullstack-engineer/README|fullstack-engineer seed skills]]
