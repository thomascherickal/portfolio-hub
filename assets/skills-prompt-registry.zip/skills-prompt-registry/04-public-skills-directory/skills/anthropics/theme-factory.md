---
type: public-skill
name: theme-factory
owner: anthropics
curator: Thomas Cherickal
source_repo: anthropics/skills
source_url: https://github.com/anthropics/skills/blob/HEAD/skills/theme-factory/SKILL.md
repo_stars: 194585
license: null
repo_last_push: 2026-11-14
roles: [web-designer]
categories: [design-and-content]
mirrors: [davila7/claude-code-templates, sickn33/agentic-awesome-skills]
status: listed
collected: 2026-11-15
tags: [public-skill, role/web-designer, owner/anthropics]
---

# theme-factory

> Toolkit for styling artifacts with a theme. These artifacts can be slides, docs, reportings, HTML landing pages, etc. There are 10 pre-set themes with colors/fonts that you can apply to any artifact that has been creating, or can generate a new theme on-the-fly.

| Field | Value |
|---|---|
| Owner | anthropics |
| Curator | Thomas Cherickal |
| Source | [anthropics/skills](https://github.com/anthropics/skills/blob/HEAD/skills/theme-factory/SKILL.md) |
| Repo stars | 194,585 |
| License | null |
| Repo last push | 2026-11-14 |
| Also published in | davila7/claude-code-templates, sickn33/agentic-awesome-skills |

## Links

- Roles: [[04-public-skills-directory/roles/design-and-content/web-designer|web-designer]]
- Source repo: [[04-public-skills-directory/sources/anthropics-skills|anthropics/skills]]
- Same repo: [[04-public-skills-directory/skills/anthropics/claude-api|claude-api]], [[04-public-skills-directory/skills/anthropics/skill-creator|skill-creator]], [[04-public-skills-directory/skills/anthropics/frontend-design|frontend-design]], [[04-public-skills-directory/skills/anthropics/webapp-testing|webapp-testing]], [[04-public-skills-directory/skills/anthropics/web-artifacts-builder|web-artifacts-builder]], [[04-public-skills-directory/skills/anthropics/mcp-builder|mcp-builder]], [[04-public-skills-directory/skills/anthropics/doc-coauthoring|doc-coauthoring]], [[04-public-skills-directory/skills/anthropics/brand-guidelines|brand-guidelines]]
- Registry seed skills for this role: [[03-skills/design-and-content/web-designer/README|web-designer seed skills]]
