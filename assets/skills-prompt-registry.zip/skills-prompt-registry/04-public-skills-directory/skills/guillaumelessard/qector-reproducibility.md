---
type: public-skill
name: qector-reproducibility
owner: GuillaumeLessard
curator: Thomas Cherickal
source_repo: GuillaumeLessard/qector-claude-plugin
source_url: https://github.com/GuillaumeLessard/qector-claude-plugin/blob/HEAD/skills/qector-reproducibility/SKILL.md
repo_stars: 1
license: NOASSERTION
repo_last_push: 2026-11-12
roles: [quantum-computing-researcher]
categories: [quantum/research]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/quantum-computing-researcher, owner/guillaumelessard]
---

# qector-reproducibility

> - Reproducibility and claim boundaries for QECTOR (manual 19, 22, 27, Appendix D). Covers the chapter 22.3 required-artifact metadata, the safe / unsafe wording rule (manual 22.5), the reproduction commands in Appendix D, the competitive-harness pipeline (same Stim circuit, same samples, same DEM, same observable scoring), the withdrawn benchmark policy, and the hot/cold path label. Load for any...

| Field | Value |
|---|---|
| Owner | GuillaumeLessard |
| Curator | Thomas Cherickal |
| Source | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin/blob/HEAD/skills/qector-reproducibility/SKILL.md) |
| Repo stars | 1 |
| License | NOASSERTION |
| Repo last push | 2026-11-12 |

## Links

- Roles: [[04-public-skills-directory/roles/quantum/research/quantum-computing-researcher|quantum-computing-researcher]]
- Source repo: [[04-public-skills-directory/sources/guillaumelessard-qector-claude-plugin|GuillaumeLessard/qector-claude-plugin]]
- Same repo: [[04-public-skills-directory/skills/guillaumelessard/qector-architecture|qector-architecture]], [[04-public-skills-directory/skills/guillaumelessard/qector-batch-decoding|qector-batch-decoding]], [[04-public-skills-directory/skills/guillaumelessard/qector-bp-osd|qector-bp-osd]], [[04-public-skills-directory/skills/guillaumelessard/qector-codes-builder|qector-codes-builder]], [[04-public-skills-directory/skills/guillaumelessard/qector-core|qector-core]], [[04-public-skills-directory/skills/guillaumelessard/qector-decoders-deep-dive|qector-decoders-deep-dive]], [[04-public-skills-directory/skills/guillaumelessard/qector-dem-pipeline|qector-dem-pipeline]], [[04-public-skills-directory/skills/guillaumelessard/qector-deployment|qector-deployment]]
- Registry seed skills for this role: [[03-skills/quantum/research/quantum-computing-researcher/README|quantum-computing-researcher seed skills]]
