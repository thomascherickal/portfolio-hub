---
type: public-skill
name: qector-decoders-deep-dive
owner: GuillaumeLessard
curator: Thomas Cherickal
source_repo: GuillaumeLessard/qector-claude-plugin
source_url: https://github.com/GuillaumeLessard/qector-claude-plugin/blob/HEAD/skills/qector-decoders-deep-dive/SKILL.md
repo_stars: 1
license: NOASSERTION
repo_last_push: 2026-11-12
roles: [quantum-computing-engineer]
categories: [quantum/engineering]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/quantum-computing-engineer, owner/guillaumelessard]
---

# qector-decoders-deep-dive

> - Per-decoder internals from the v1.0.0 reference manual. For each of the the Provisional backends, gives the algorithm, the theorem(s) it inherits, its claim boundary, and a one-line code snippet. Load when a question asks "how does X work", "which decoder is right for Y", or "what is the difference between A and B" at the algorithmic level (manual chapters 4-13).

| Field | Value |
|---|---|
| Owner | GuillaumeLessard |
| Curator | Thomas Cherickal |
| Source | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin/blob/HEAD/skills/qector-decoders-deep-dive/SKILL.md) |
| Repo stars | 1 |
| License | NOASSERTION |
| Repo last push | 2026-11-12 |

## Links

- Roles: [[04-public-skills-directory/roles/quantum/engineering/quantum-computing-engineer|quantum-computing-engineer]]
- Source repo: [[04-public-skills-directory/sources/guillaumelessard-qector-claude-plugin|GuillaumeLessard/qector-claude-plugin]]
- Same repo: [[04-public-skills-directory/skills/guillaumelessard/qector-architecture|qector-architecture]], [[04-public-skills-directory/skills/guillaumelessard/qector-batch-decoding|qector-batch-decoding]], [[04-public-skills-directory/skills/guillaumelessard/qector-bp-osd|qector-bp-osd]], [[04-public-skills-directory/skills/guillaumelessard/qector-codes-builder|qector-codes-builder]], [[04-public-skills-directory/skills/guillaumelessard/qector-core|qector-core]], [[04-public-skills-directory/skills/guillaumelessard/qector-dem-pipeline|qector-dem-pipeline]], [[04-public-skills-directory/skills/guillaumelessard/qector-deployment|qector-deployment]], [[04-public-skills-directory/skills/guillaumelessard/qector-developer|qector-developer]]
- Registry seed skills for this role: [[03-skills/quantum/engineering/quantum-computing-engineer/README|quantum-computing-engineer seed skills]]
