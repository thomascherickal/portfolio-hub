---
type: public-skill
name: rust-port
owner: morganlinton
curator: Thomas Cherickal
source_repo: morganlinton/BeautifulRust
source_url: https://github.com/morganlinton/BeautifulRust/blob/HEAD/skills/rust-port/SKILL.md
repo_stars: 1813
license: MIT
repo_last_push: 2026-11-08
roles: [rust-engineer]
categories: [software-engineering/languages]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/rust-engineer, owner/morganlinton]
---

# rust-port

> - Port code from C, C++, Python, Go, JavaScript, or TypeScript into idiomatic Rust that keeps the original behavior: ownership instead of manual memory, Result instead of error codes and exceptions, enums instead of flag ints and magic strings, and tests that prove the port matches. Use this whenever the user asks to port, translate, convert, migrate, or rewrite code in Rust ("rewrite this in...

| Field | Value |
|---|---|
| Owner | morganlinton |
| Curator | Thomas Cherickal |
| Source | [morganlinton/BeautifulRust](https://github.com/morganlinton/BeautifulRust/blob/HEAD/skills/rust-port/SKILL.md) |
| Repo stars | 1,813 |
| License | MIT |
| Repo last push | 2026-11-08 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/languages/rust-engineer|rust-engineer]]
- Source repo: [[04-public-skills-directory/sources/morganlinton-beautifulrust|morganlinton/BeautifulRust]]
- Same repo: [[04-public-skills-directory/skills/morganlinton/rust-best-practices|rust-best-practices]]
- Registry seed skills for this role: [[03-skills/software-engineering/languages/rust-engineer/README|rust-engineer seed skills]]
