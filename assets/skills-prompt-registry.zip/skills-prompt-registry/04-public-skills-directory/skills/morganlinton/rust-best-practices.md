---
type: public-skill
name: rust-best-practices
owner: morganlinton
curator: Thomas Cherickal
source_repo: morganlinton/BeautifulRust
source_url: https://github.com/morganlinton/BeautifulRust/blob/HEAD/skills/rust-best-practices/SKILL.md
repo_stars: 1813
license: MIT
repo_last_push: 2026-11-08
roles: [rust-engineer]
categories: [software-engineering/languages]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/rust-engineer, owner/morganlinton]
---

# rust-best-practices

> - Write idiomatic, robust, maintainable Rust. Use this skill whenever you write, review, refactor, debug, or explain Rust code: new crates, modules, functions, structs, traits, error types, async code, unsafe or FFI code, Cargo.toml, tests, or rustdoc. Trigger on any mention of Rust, cargo, crates, .rs files, the borrow checker, lifetimes, traits, clippy, or rustfmt, even when the user does not...

| Field | Value |
|---|---|
| Owner | morganlinton |
| Curator | Thomas Cherickal |
| Source | [morganlinton/BeautifulRust](https://github.com/morganlinton/BeautifulRust/blob/HEAD/skills/rust-best-practices/SKILL.md) |
| Repo stars | 1,813 |
| License | MIT |
| Repo last push | 2026-11-08 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/languages/rust-engineer|rust-engineer]]
- Source repo: [[04-public-skills-directory/sources/morganlinton-beautifulrust|morganlinton/BeautifulRust]]
- Same repo: [[04-public-skills-directory/skills/morganlinton/rust-port|rust-port]]
- Registry seed skills for this role: [[03-skills/software-engineering/languages/rust-engineer/README|rust-engineer seed skills]]
