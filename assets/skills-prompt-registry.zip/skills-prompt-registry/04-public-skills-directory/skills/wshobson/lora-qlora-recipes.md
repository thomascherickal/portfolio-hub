---
type: public-skill
name: lora-qlora-recipes
owner: wshobson
curator: Thomas Cherickal
source_repo: wshobson/agents
source_url: https://github.com/wshobson/agents/blob/HEAD/plugins/llm-finetuning/skills/lora-qlora-recipes/SKILL.md
repo_stars: 42512
license: MIT
repo_last_push: 2026-11-09
roles: [llm-engineer]
categories: [ai-ml/llm-systems]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/llm-engineer, owner/wshobson]
---

# lora-qlora-recipes

> Configure LoRA and QLoRA supervised fine-tuning with current best-practice hyperparameters. Use when writing or reviewing a LoRA/QLoRA training configuration, choosing rank/alpha/target modules, or deciding between LoRA, QLoRA, and full fine-tuning.

| Field | Value |
|---|---|
| Owner | wshobson |
| Curator | Thomas Cherickal |
| Source | [wshobson/agents](https://github.com/wshobson/agents/blob/HEAD/plugins/llm-finetuning/skills/lora-qlora-recipes/SKILL.md) |
| Repo stars | 42,512 |
| License | MIT |
| Repo last push | 2026-11-09 |

## Links

- Roles: [[04-public-skills-directory/roles/ai-ml/llm-systems/llm-engineer|llm-engineer]]
- Source repo: [[04-public-skills-directory/sources/wshobson-agents|wshobson/agents]]
- Same repo: [[04-public-skills-directory/skills/wshobson/eval-harness-first|eval-harness-first]], [[04-public-skills-directory/skills/wshobson/evaluation-methodology|evaluation-methodology]], [[04-public-skills-directory/skills/wshobson/dataset-curation|dataset-curation]], [[04-public-skills-directory/skills/wshobson/finetuning-method-selection|finetuning-method-selection]], [[04-public-skills-directory/skills/wshobson/grpo-rlvr-training|grpo-rlvr-training]], [[04-public-skills-directory/skills/wshobson/python-anti-patterns|python-anti-patterns]], [[04-public-skills-directory/skills/wshobson/python-background-jobs|python-background-jobs]], [[04-public-skills-directory/skills/wshobson/python-code-style|python-code-style]]
- Registry seed skills for this role: [[03-skills/ai-ml/llm-systems/llm-engineer/README|llm-engineer seed skills]]
