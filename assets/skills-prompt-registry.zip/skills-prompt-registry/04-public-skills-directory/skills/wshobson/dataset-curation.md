---
type: public-skill
name: dataset-curation
owner: wshobson
curator: Thomas Cherickal
source_repo: wshobson/agents
source_url: https://github.com/wshobson/agents/blob/HEAD/plugins/llm-finetuning/skills/dataset-curation/SKILL.md
repo_stars: 42512
license: MIT
repo_last_push: 2026-11-09
roles: [llm-engineer]
categories: [ai-ml/llm-systems]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/llm-engineer, owner/wshobson]
---

# dataset-curation

> Prepare, format, and validate datasets for supervised fine-tuning and preference training. Use when converting raw data into training format, applying chat templates, configuring sequence packing, generating synthetic training data, or writing a dataset card before a run.

| Field | Value |
|---|---|
| Owner | wshobson |
| Curator | Thomas Cherickal |
| Source | [wshobson/agents](https://github.com/wshobson/agents/blob/HEAD/plugins/llm-finetuning/skills/dataset-curation/SKILL.md) |
| Repo stars | 42,512 |
| License | MIT |
| Repo last push | 2026-11-09 |

## Links

- Roles: [[04-public-skills-directory/roles/ai-ml/llm-systems/llm-engineer|llm-engineer]]
- Source repo: [[04-public-skills-directory/sources/wshobson-agents|wshobson/agents]]
- Same repo: [[04-public-skills-directory/skills/wshobson/eval-harness-first|eval-harness-first]], [[04-public-skills-directory/skills/wshobson/evaluation-methodology|evaluation-methodology]], [[04-public-skills-directory/skills/wshobson/finetuning-method-selection|finetuning-method-selection]], [[04-public-skills-directory/skills/wshobson/grpo-rlvr-training|grpo-rlvr-training]], [[04-public-skills-directory/skills/wshobson/lora-qlora-recipes|lora-qlora-recipes]], [[04-public-skills-directory/skills/wshobson/python-anti-patterns|python-anti-patterns]], [[04-public-skills-directory/skills/wshobson/python-background-jobs|python-background-jobs]], [[04-public-skills-directory/skills/wshobson/python-code-style|python-code-style]]
- Registry seed skills for this role: [[03-skills/ai-ml/llm-systems/llm-engineer/README|llm-engineer seed skills]]
