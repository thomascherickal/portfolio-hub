---
type: public-skill
name: review-agent-setup
owner: wshobson
curator: Thomas Cherickal
source_repo: wshobson/agents
source_url: https://github.com/wshobson/agents/blob/HEAD/plugins/review-agent-governance/skills/review-agent-setup/SKILL.md
repo_stars: 42512
license: MIT
repo_last_push: 2026-11-09
roles: [genai-engineer]
categories: [ai-ml/applied-ai]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/genai-engineer, owner/wshobson]
---

# review-agent-setup

> Configure human-in-the-loop gating for AI agent review actions in Claude Code. Use when setting up a project where an agent may post PR reviews, comments, merges, or edit CI configuration, and you want a cryptographically auditable approval trail with Cedar-enforced gates.

| Field | Value |
|---|---|
| Owner | wshobson |
| Curator | Thomas Cherickal |
| Source | [wshobson/agents](https://github.com/wshobson/agents/blob/HEAD/plugins/review-agent-governance/skills/review-agent-setup/SKILL.md) |
| Repo stars | 42,512 |
| License | MIT |
| Repo last push | 2026-11-09 |

## Links

- Roles: [[04-public-skills-directory/roles/ai-ml/applied-ai/genai-engineer|genai-engineer]]
- Source repo: [[04-public-skills-directory/sources/wshobson-agents|wshobson/agents]]
- Same repo: [[04-public-skills-directory/skills/wshobson/eval-harness-first|eval-harness-first]], [[04-public-skills-directory/skills/wshobson/evaluation-methodology|evaluation-methodology]], [[04-public-skills-directory/skills/wshobson/dataset-curation|dataset-curation]], [[04-public-skills-directory/skills/wshobson/finetuning-method-selection|finetuning-method-selection]], [[04-public-skills-directory/skills/wshobson/grpo-rlvr-training|grpo-rlvr-training]], [[04-public-skills-directory/skills/wshobson/lora-qlora-recipes|lora-qlora-recipes]], [[04-public-skills-directory/skills/wshobson/python-anti-patterns|python-anti-patterns]], [[04-public-skills-directory/skills/wshobson/python-background-jobs|python-background-jobs]]
- Registry seed skills for this role: [[03-skills/ai-ml/applied-ai/genai-engineer/README|genai-engineer seed skills]]
