---
type: public-skill
name: python-anti-patterns
owner: wshobson
curator: Thomas Cherickal
source_repo: wshobson/agents
source_url: https://github.com/wshobson/agents/blob/HEAD/plugins/python-development/skills/python-anti-patterns/SKILL.md
repo_stars: 42512
license: MIT
repo_last_push: 2026-11-09
roles: [python-engineer]
categories: [software-engineering/languages]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/python-engineer, owner/wshobson]
---

# python-anti-patterns

> Use this skill when reviewing Python code for common anti-patterns to avoid. Use as a checklist when reviewing code, before finalizing implementations, or when debugging issues that might stem from known bad practices.

| Field | Value |
|---|---|
| Owner | wshobson |
| Curator | Thomas Cherickal |
| Source | [wshobson/agents](https://github.com/wshobson/agents/blob/HEAD/plugins/python-development/skills/python-anti-patterns/SKILL.md) |
| Repo stars | 42,512 |
| License | MIT |
| Repo last push | 2026-11-09 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/languages/python-engineer|python-engineer]]
- Source repo: [[04-public-skills-directory/sources/wshobson-agents|wshobson/agents]]
- Same repo: [[04-public-skills-directory/skills/wshobson/eval-harness-first|eval-harness-first]], [[04-public-skills-directory/skills/wshobson/evaluation-methodology|evaluation-methodology]], [[04-public-skills-directory/skills/wshobson/dataset-curation|dataset-curation]], [[04-public-skills-directory/skills/wshobson/finetuning-method-selection|finetuning-method-selection]], [[04-public-skills-directory/skills/wshobson/grpo-rlvr-training|grpo-rlvr-training]], [[04-public-skills-directory/skills/wshobson/lora-qlora-recipes|lora-qlora-recipes]], [[04-public-skills-directory/skills/wshobson/python-background-jobs|python-background-jobs]], [[04-public-skills-directory/skills/wshobson/python-code-style|python-code-style]]
- Registry seed skills for this role: [[03-skills/software-engineering/languages/python-engineer/README|python-engineer seed skills]]
