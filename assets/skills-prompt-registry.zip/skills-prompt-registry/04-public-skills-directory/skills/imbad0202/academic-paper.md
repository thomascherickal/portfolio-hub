---
type: public-skill
name: academic-paper
owner: Imbad0202
curator: Thomas Cherickal
source_repo: Imbad0202/academic-research-skills
source_url: https://github.com/Imbad0202/academic-research-skills/blob/HEAD/academic-paper/SKILL.md
repo_stars: 56891
license: NOASSERTION
repo_last_push: 2026-11-14
roles: [research-scientist]
categories: [research]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/research-scientist, owner/imbad0202]
---

# academic-paper

> 12-agent academic paper writing pipeline. 11 modes (full/plan/outline/revision/revision-coach/abstract/lit-review/format-convert/citation-check/disclosure/rebuttal-audit). 6 paper types, 5 citation formats, bilingual abstracts, LaTeX/DOCX-via-Pandoc/PDF output. Style Calibration + Writing Quality Check + Anti-Patterns with IRON RULE markers. Triggers: write paper, academic paper, guide my paper,...

| Field | Value |
|---|---|
| Owner | Imbad0202 |
| Curator | Thomas Cherickal |
| Source | [Imbad0202/academic-research-skills](https://github.com/Imbad0202/academic-research-skills/blob/HEAD/academic-paper/SKILL.md) |
| Repo stars | 56,891 |
| License | NOASSERTION |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/research/research-scientist|research-scientist]]
- Source repo: [[04-public-skills-directory/sources/imbad0202-academic-research-skills|Imbad0202/academic-research-skills]]
- Same repo: [[04-public-skills-directory/skills/imbad0202/academic-paper-reviewer|academic-paper-reviewer]], [[04-public-skills-directory/skills/imbad0202/academic-pipeline|academic-pipeline]]
- Registry seed skills for this role: [[03-skills/research/research-scientist/README|research-scientist seed skills]]
