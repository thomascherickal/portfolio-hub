---
type: public-skill
name: academic-pipeline
owner: Imbad0202
curator: Thomas Cherickal
source_repo: Imbad0202/academic-research-skills
source_url: https://github.com/Imbad0202/academic-research-skills/blob/HEAD/academic-pipeline/SKILL.md
repo_stars: 56891
license: NOASSERTION
repo_last_push: 2026-11-14
roles: [research-scientist]
categories: [research]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/research-scientist, owner/imbad0202]
---

# academic-pipeline

> Orchestrator for the full academic research pipeline: research -> write -> integrity check -> review -> revise -> re-review -> re-revise -> final integrity check -> finalize. Coordinates deep-research, academic-paper, and academic-paper-reviewer into a seamless 10-stage workflow with mandatory, coverage-bounded integrity checks, two-stage peer review, and auditable quality-assurance artifacts....

| Field | Value |
|---|---|
| Owner | Imbad0202 |
| Curator | Thomas Cherickal |
| Source | [Imbad0202/academic-research-skills](https://github.com/Imbad0202/academic-research-skills/blob/HEAD/academic-pipeline/SKILL.md) |
| Repo stars | 56,891 |
| License | NOASSERTION |
| Repo last push | 2026-11-14 |

## Links

- Roles: [[04-public-skills-directory/roles/research/research-scientist|research-scientist]]
- Source repo: [[04-public-skills-directory/sources/imbad0202-academic-research-skills|Imbad0202/academic-research-skills]]
- Same repo: [[04-public-skills-directory/skills/imbad0202/academic-paper|academic-paper]], [[04-public-skills-directory/skills/imbad0202/academic-paper-reviewer|academic-paper-reviewer]]
- Registry seed skills for this role: [[03-skills/research/research-scientist/README|research-scientist seed skills]]
