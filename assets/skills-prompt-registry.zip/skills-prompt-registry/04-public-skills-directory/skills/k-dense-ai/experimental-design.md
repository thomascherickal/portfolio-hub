---
type: public-skill
name: experimental-design
owner: K-Dense-AI
curator: Thomas Cherickal
source_repo: K-Dense-AI/scientific-agent-skills
source_url: https://github.com/K-Dense-AI/scientific-agent-skills/blob/HEAD/skills/experimental-design/SKILL.md
repo_stars: 57202
license: MIT
repo_last_push: 2026-11-09
roles: [research-scientist]
categories: [research]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/research-scientist, owner/k-dense-ai]
---

# experimental-design

> Designs experiments and studies BEFORE data is collected — choosing a design, randomizing, blocking, and laying out treatment combinations so results are interpretable. Use whenever someone is planning a study, asks how to assign subjects/samples to groups, mentions randomization, blocking, stratification, controls, factorial or fractional-factorial designs, design of experiments (DOE), screening...

| Field | Value |
|---|---|
| Owner | K-Dense-AI |
| Curator | Thomas Cherickal |
| Source | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills/blob/HEAD/skills/experimental-design/SKILL.md) |
| Repo stars | 57,202 |
| License | MIT |
| Repo last push | 2026-11-09 |

## Links

- Roles: [[04-public-skills-directory/roles/research/research-scientist|research-scientist]]
- Source repo: [[04-public-skills-directory/sources/k-dense-ai-scientific-agent-skills|K-Dense-AI/scientific-agent-skills]]
- Same repo: [[04-public-skills-directory/skills/k-dense-ai/scholar-evaluation|scholar-evaluation]], [[04-public-skills-directory/skills/k-dense-ai/zarr-python|zarr-python]], [[04-public-skills-directory/skills/k-dense-ai/scientific-brainstorming|scientific-brainstorming]], [[04-public-skills-directory/skills/k-dense-ai/pi-agent|pi-agent]], [[04-public-skills-directory/skills/k-dense-ai/iso-standards-readiness|iso-standards-readiness]], [[04-public-skills-directory/skills/k-dense-ai/cirq|cirq]], [[04-public-skills-directory/skills/k-dense-ai/pennylane|pennylane]], [[04-public-skills-directory/skills/k-dense-ai/qiskit|qiskit]]
- Registry seed skills for this role: [[03-skills/research/research-scientist/README|research-scientist seed skills]]
