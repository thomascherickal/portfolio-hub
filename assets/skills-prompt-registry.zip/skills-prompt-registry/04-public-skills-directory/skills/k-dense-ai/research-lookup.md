---
type: public-skill
name: research-lookup
owner: K-Dense-AI
curator: Thomas Cherickal
source_repo: K-Dense-AI/scientific-agent-skills
source_url: https://github.com/K-Dense-AI/scientific-agent-skills/blob/HEAD/skills/research-lookup/SKILL.md
repo_stars: 57202
license: MIT
repo_last_push: 2026-11-09
roles: [industry-researcher]
categories: [research]
mirrors: [davila7/claude-code-templates]
status: listed
collected: 2026-11-15
tags: [public-skill, role/industry-researcher, owner/k-dense-ai]
---

# research-lookup

> Compiles current scholarly evidence for a scientific manuscript or research brief when the user explicitly asks to gather literature, references, background evidence, competing findings, or a manuscript research packet. Uses Parallel Search by default, Parallel Extract for source retrieval, Parallel Research for explicitly deep/exhaustive work, optional explicit Parallel Chat, and optional...

| Field | Value |
|---|---|
| Owner | K-Dense-AI |
| Curator | Thomas Cherickal |
| Source | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills/blob/HEAD/skills/research-lookup/SKILL.md) |
| Repo stars | 57,202 |
| License | MIT |
| Repo last push | 2026-11-09 |
| Also published in | davila7/claude-code-templates |

## Links

- Roles: [[04-public-skills-directory/roles/research/industry-researcher|industry-researcher]]
- Source repo: [[04-public-skills-directory/sources/k-dense-ai-scientific-agent-skills|K-Dense-AI/scientific-agent-skills]]
- Same repo: [[04-public-skills-directory/skills/k-dense-ai/scholar-evaluation|scholar-evaluation]], [[04-public-skills-directory/skills/k-dense-ai/zarr-python|zarr-python]], [[04-public-skills-directory/skills/k-dense-ai/scientific-brainstorming|scientific-brainstorming]], [[04-public-skills-directory/skills/k-dense-ai/pi-agent|pi-agent]], [[04-public-skills-directory/skills/k-dense-ai/iso-standards-readiness|iso-standards-readiness]], [[04-public-skills-directory/skills/k-dense-ai/cirq|cirq]], [[04-public-skills-directory/skills/k-dense-ai/pennylane|pennylane]], [[04-public-skills-directory/skills/k-dense-ai/qiskit|qiskit]]
- Registry seed skills for this role: [[03-skills/research/industry-researcher/README|industry-researcher seed skills]]
