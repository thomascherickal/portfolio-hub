---
type: public-skill
name: latex-posters
owner: K-Dense-AI
curator: Thomas Cherickal
source_repo: K-Dense-AI/scientific-agent-skills
source_url: https://github.com/K-Dense-AI/scientific-agent-skills/blob/HEAD/skills/latex-posters/SKILL.md
repo_stars: 57202
license: MIT
repo_last_push: 2026-11-09
roles: [research-scientist]
categories: [research]
mirrors: [davila7/claude-code-templates]
status: listed
collected: 2026-11-15
tags: [public-skill, role/research-scientist, owner/k-dense-ai]
---

# latex-posters

> Creates research posters in LaTeX using beamerposter, tikzposter, or baposter. Use for conference posters, academic presentations, multi-column scientific layouts, figure integration, typography, compilation, and PDF preflight.

| Field | Value |
|---|---|
| Owner | K-Dense-AI |
| Curator | Thomas Cherickal |
| Source | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills/blob/HEAD/skills/latex-posters/SKILL.md) |
| Repo stars | 57,202 |
| License | MIT |
| Repo last push | 2026-11-09 |
| Also published in | davila7/claude-code-templates |

## Links

- Roles: [[04-public-skills-directory/roles/research/research-scientist|research-scientist]]
- Source repo: [[04-public-skills-directory/sources/k-dense-ai-scientific-agent-skills|K-Dense-AI/scientific-agent-skills]]
- Same repo: [[04-public-skills-directory/skills/k-dense-ai/scholar-evaluation|scholar-evaluation]], [[04-public-skills-directory/skills/k-dense-ai/zarr-python|zarr-python]], [[04-public-skills-directory/skills/k-dense-ai/scientific-brainstorming|scientific-brainstorming]], [[04-public-skills-directory/skills/k-dense-ai/pi-agent|pi-agent]], [[04-public-skills-directory/skills/k-dense-ai/iso-standards-readiness|iso-standards-readiness]], [[04-public-skills-directory/skills/k-dense-ai/cirq|cirq]], [[04-public-skills-directory/skills/k-dense-ai/pennylane|pennylane]], [[04-public-skills-directory/skills/k-dense-ai/qiskit|qiskit]]
- Registry seed skills for this role: [[03-skills/research/research-scientist/README|research-scientist seed skills]]
