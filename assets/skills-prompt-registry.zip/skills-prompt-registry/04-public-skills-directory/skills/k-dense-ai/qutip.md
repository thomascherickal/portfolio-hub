---
type: public-skill
name: qutip
owner: K-Dense-AI
curator: Thomas Cherickal
source_repo: K-Dense-AI/scientific-agent-skills
source_url: https://github.com/K-Dense-AI/scientific-agent-skills/blob/HEAD/skills/qutip/SKILL.md
repo_stars: 57202
license: MIT
repo_last_push: 2026-11-09
roles: [quantum-computing-engineer, quantum-ml-engineer, quantum-computing-researcher]
categories: [quantum/engineering, quantum/research]
mirrors: [davila7/claude-code-templates]
status: listed
collected: 2026-11-15
tags: [public-skill, role/quantum-computing-engineer, role/quantum-ml-engineer, role/quantum-computing-researcher, owner/k-dense-ai]
---

# qutip

> Simulate and audit closed and open quantum-system models with QuTiP 5, including deterministic, trajectory, steady-state, spectral, and phase-space workflows. Use for local quantum-dynamics work where physical assumptions, dimensions, and numerical convergence must be explicit.

| Field | Value |
|---|---|
| Owner | K-Dense-AI |
| Curator | Thomas Cherickal |
| Source | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills/blob/HEAD/skills/qutip/SKILL.md) |
| Repo stars | 57,202 |
| License | MIT |
| Repo last push | 2026-11-09 |
| Also published in | davila7/claude-code-templates |

## Links

- Roles: [[04-public-skills-directory/roles/quantum/engineering/quantum-computing-engineer|quantum-computing-engineer]], [[04-public-skills-directory/roles/quantum/engineering/quantum-ml-engineer|quantum-ml-engineer]], [[04-public-skills-directory/roles/quantum/research/quantum-computing-researcher|quantum-computing-researcher]]
- Source repo: [[04-public-skills-directory/sources/k-dense-ai-scientific-agent-skills|K-Dense-AI/scientific-agent-skills]]
- Same repo: [[04-public-skills-directory/skills/k-dense-ai/scholar-evaluation|scholar-evaluation]], [[04-public-skills-directory/skills/k-dense-ai/zarr-python|zarr-python]], [[04-public-skills-directory/skills/k-dense-ai/scientific-brainstorming|scientific-brainstorming]], [[04-public-skills-directory/skills/k-dense-ai/pi-agent|pi-agent]], [[04-public-skills-directory/skills/k-dense-ai/iso-standards-readiness|iso-standards-readiness]], [[04-public-skills-directory/skills/k-dense-ai/cirq|cirq]], [[04-public-skills-directory/skills/k-dense-ai/pennylane|pennylane]], [[04-public-skills-directory/skills/k-dense-ai/qiskit|qiskit]]
- Registry seed skills for this role: [[03-skills/quantum/engineering/quantum-computing-engineer/README|quantum-computing-engineer seed skills]]
