---
type: public-skill
name: web3-ai-tools
owner: awarexone
curator: Thomas Cherickal
source_repo: awarexone/web3-bug-bounty-hunting-ai-skills
source_url: https://github.com/awarexone/web3-bug-bounty-hunting-ai-skills/blob/HEAD/web3-ai-tools/SKILL.md
repo_stars: 186
license: MIT
repo_last_push: 2026-09-21
roles: [blockchain-defi-engineer]
categories: [web3]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/blockchain-defi-engineer, owner/awarexone]
---

# web3-ai-tools

> AI-powered tools for Web3 bug bounty automation. Use when you want to automate recon, run autonomous audits, or use AI agents for vulnerability discovery.

| Field | Value |
|---|---|
| Owner | awarexone |
| Curator | Thomas Cherickal |
| Source | [awarexone/web3-bug-bounty-hunting-ai-skills](https://github.com/awarexone/web3-bug-bounty-hunting-ai-skills/blob/HEAD/web3-ai-tools/SKILL.md) |
| Repo stars | 186 |
| License | MIT |
| Repo last push | 2026-09-21 |

## Links

- Roles: [[04-public-skills-directory/roles/web3/blockchain-defi-engineer|blockchain-defi-engineer]]
- Source repo: [[04-public-skills-directory/sources/awarexone-web3-bug-bounty-hunting-ai-skills|awarexone/web3-bug-bounty-hunting-ai-skills]]
- Same repo: [[04-public-skills-directory/skills/awarexone/web3-bug-classes|web3-bug-classes]], [[04-public-skills-directory/skills/awarexone/web3-case-study-role-misconfig|web3-case-study-role-misconfig]], [[04-public-skills-directory/skills/awarexone/web3-grep-arsenal|web3-grep-arsenal]], [[04-public-skills-directory/skills/awarexone/web3-hunt-foundation|web3-hunt-foundation]]
- Registry seed skills for this role: [[03-skills/web3/blockchain-defi-engineer/README|blockchain-defi-engineer seed skills]]
