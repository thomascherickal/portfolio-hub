---
type: public-skill
name: stitch::extract-static-html
owner: google-labs-code
curator: Thomas Cherickal
source_repo: google-labs-code/stitch-skills
source_url: https://github.com/google-labs-code/stitch-skills/blob/HEAD/plugins/stitch-design/skills/extract-static-html/SKILL.md
repo_stars: 8871
license: Apache-2.0
repo_last_push: 2026-08-17
roles: [pwa-engineer]
categories: [software-engineering/application]
mirrors: []
status: listed
collected: 2026-11-15
tags: [public-skill, role/pwa-engineer, owner/google-labs-code]
---

# stitch::extract-static-html

> - Extract self-contained static HTML from a built web application or React components by inlining CSS and images. Use this skill whenever you need to capture a specific UI state, share a static version of a page, or prepare assets for Stitch upload, even if the user just asks to 'save the HTML' or 'mock the view'.

| Field | Value |
|---|---|
| Owner | google-labs-code |
| Curator | Thomas Cherickal |
| Source | [google-labs-code/stitch-skills](https://github.com/google-labs-code/stitch-skills/blob/HEAD/plugins/stitch-design/skills/extract-static-html/SKILL.md) |
| Repo stars | 8,871 |
| License | Apache-2.0 |
| Repo last push | 2026-08-17 |

## Links

- Roles: [[04-public-skills-directory/roles/software-engineering/application/pwa-engineer|pwa-engineer]]
- Source repo: [[04-public-skills-directory/sources/google-labs-code-stitch-skills|google-labs-code/stitch-skills]]
- Registry seed skills for this role: [[03-skills/software-engineering/application/pwa-engineer/README|pwa-engineer seed skills]]
