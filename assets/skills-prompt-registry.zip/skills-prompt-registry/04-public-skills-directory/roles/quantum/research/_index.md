---
type: category-index
category: quantum/research
curator: Thomas Cherickal
tags: [moc, category/quantum/research]
updated: 2026-11-15
---

# quantum/research

- Up: [[04-public-skills-directory/roles/quantum/_index|quantum]]
- Mirror in seed registry: [[03-skills/quantum/research/_index|quantum/research]]

## Roles

- [[04-public-skills-directory/roles/quantum/research/quantum-computing-researcher|quantum-computing-researcher]] (16 skills)
