---
type: public-role-directory
role: quantum-computing-researcher
category: quantum/research
curator: Thomas Cherickal
count: 16
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/quantum-computing-researcher, category/quantum/research]
---

# quantum-computing-researcher: Public Skills (16)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/k-dense-ai/cirq|cirq]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Google quantum computing framework. Use when targeting Google Quantum AI hardware, designing noise-aware circuits, or running quantum... |
| 2 | [[04-public-skills-directory/skills/k-dense-ai/pennylane|pennylane]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Builds and differentiates PennyLane quantum circuits, hybrid PyTorch or JAX models, molecular VQE and QAOA workflows. Use for variational... |
| 3 | [[04-public-skills-directory/skills/k-dense-ai/qiskit|qiskit]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Builds, simulates, transpiles, and executes quantum circuits with Qiskit and IBM Quantum Runtime. Use for Qiskit 2.x circuits and... |
| 4 | [[04-public-skills-directory/skills/k-dense-ai/qutip|qutip]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Simulate and audit closed and open quantum-system models with QuTiP 5, including deterministic, trajectory, steady-state, spectral, and... |
| 5 | [[04-public-skills-directory/skills/wanshuiyin/formula-derivation|formula-derivation]] | wanshuiyin | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) | 19,200 | MIT | Structures and derives research formulas when the user wants to 推导公式, build a theory line, organize assumptions, turn scattered equations... |
| 6 | [[04-public-skills-directory/skills/wanshuiyin/lean-formalize|lean-formalize]] | wanshuiyin | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) | 19,200 | MIT | Develop and verify a mathematical proof in Lean, continue an incomplete Lean project, or audit whether it proves the original statement.... |
| 7 | [[04-public-skills-directory/skills/wanshuiyin/proof-checker|proof-checker]] | wanshuiyin | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) | 19,200 | MIT | Rigorous mathematical proof verification and fixing workflow. Reads a LaTeX proof, identifies gaps via fresh-agent Codex GPT-6-Astra ultra... |
| 8 | [[04-public-skills-directory/skills/trailofbits/writing-lean-proofs|writing-lean-proofs]] | trailofbits | [trailofbits/skills](https://github.com/trailofbits/skills) | 8,189 | CC-BY-SA-4.0 | Writes and reviews structured Lean 4 proofs and designs Lean libraries following Mathlib conventions. Use when proving theorems in Lean,... |
| 9 | [[04-public-skills-directory/skills/guillaumelessard/qector-educator|qector-educator]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Teaching and documentation content for quantum error correction with QECTOR: beginner-to-advanced tutorials, ELI5 explanations of... |
| 10 | [[04-public-skills-directory/skills/guillaumelessard/qector-glossary|qector-glossary]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - QECTOR terminology, notation, and symbols from the v1.0.0 reference manual (Appendix A and B). Load for any question about what a term... |
| 11 | [[04-public-skills-directory/skills/guillaumelessard/qector-ler-methodology|qector-ler-methodology]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Logical error rate (LER) methodology for QECTOR. Covers the Wilson 95% score interval, the chapter 22.3 required-artifact metadata block,... |
| 12 | [[04-public-skills-directory/skills/guillaumelessard/qector-math-foundations|qector-math-foundations]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - The strict mathematical ground rules for every QECTOR claim. Encodes the F2 notation, the 16 correctness theorems, the Wilson 95% score... |
| 13 | [[04-public-skills-directory/skills/guillaumelessard/qector-reproducibility|qector-reproducibility]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Reproducibility and claim boundaries for QECTOR (manual 19, 22, 27, Appendix D). Covers the chapter 22.3 required-artifact metadata, the... |
| 14 | [[04-public-skills-directory/skills/guillaumelessard/qector-researcher|qector-researcher]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Quantum error correction research workflows on the QECTOR platform: threshold discovery, finite-size scaling, LER benchmarking with... |
| 15 | [[04-public-skills-directory/skills/guillaumelessard/qector-roadmap|qector-roadmap]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - QECTOR roadmap and promotion path (manual 27). Covers the four-step Provisional-to-stable promotion bar, the artifact roadmap, the... |
| 16 | [[04-public-skills-directory/skills/guillaumelessard/qector-space-time|qector-space-time]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Space-time and streaming decoding for QECTOR. Covers the (2+1)D detector lattice, the detector-difference formulation d_{c,t} = s_{c,t}... |

## Links

- Up: [[04-public-skills-directory/roles/quantum/research/_index|quantum/research]]
- Seed skills: [[03-skills/quantum/research/quantum-computing-researcher/README|quantum-computing-researcher seed skills]]
