---
type: category-index
category: quantum/engineering
curator: Thomas Cherickal
tags: [moc, category/quantum/engineering]
updated: 2026-11-15
---

# quantum/engineering

- Up: [[04-public-skills-directory/roles/quantum/_index|quantum]]
- Mirror in seed registry: [[03-skills/quantum/engineering/_index|quantum/engineering]]

## Roles

- [[04-public-skills-directory/roles/quantum/engineering/quantum-computing-engineer|quantum-computing-engineer]] (18 skills)
- [[04-public-skills-directory/roles/quantum/engineering/quantum-ml-engineer|quantum-ml-engineer]] (11 skills)
