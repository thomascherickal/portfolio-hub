---
type: public-role-directory
role: quantum-ml-engineer
category: quantum/engineering
curator: Thomas Cherickal
count: 11
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/quantum-ml-engineer, category/quantum/engineering]
---

# quantum-ml-engineer: Public Skills (11)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/k-dense-ai/cirq|cirq]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Google quantum computing framework. Use when targeting Google Quantum AI hardware, designing noise-aware circuits, or running quantum... |
| 2 | [[04-public-skills-directory/skills/k-dense-ai/pennylane|pennylane]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Builds and differentiates PennyLane quantum circuits, hybrid PyTorch or JAX models, molecular VQE and QAOA workflows. Use for variational... |
| 3 | [[04-public-skills-directory/skills/k-dense-ai/pytorch-lightning|pytorch-lightning]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Deep learning framework (PyTorch Lightning / lightning package). Organize PyTorch code into LightningModules, configure Trainers for... |
| 4 | [[04-public-skills-directory/skills/k-dense-ai/qiskit|qiskit]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Builds, simulates, transpiles, and executes quantum circuits with Qiskit and IBM Quantum Runtime. Use for Qiskit 2.x circuits and... |
| 5 | [[04-public-skills-directory/skills/k-dense-ai/qutip|qutip]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Simulate and audit closed and open quantum-system models with QuTiP 5, including deterministic, trajectory, steady-state, spectral, and... |
| 6 | [[04-public-skills-directory/skills/k-dense-ai/scikit-learn|scikit-learn]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Supports machine learning in Python with scikit-learn. Applies when working with supervised learning (classification, regression),... |
| 7 | [[04-public-skills-directory/skills/davila7/distributed-training-pytorch-lightning|distributed-training-pytorch-lightning]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | High-level PyTorch framework with Trainer class, automatic distributed training (DDP/FSDP/DeepSpeed), callbacks system, and minimal... |
| 8 | [[04-public-skills-directory/skills/orchestra-research/mamba-architecture|mamba-architecture]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | State-space model with O(n) complexity vs Transformers' O(n²). 5× faster inference, million-token sequences, no KV cache. Selective SSM... |
| 9 | [[04-public-skills-directory/skills/orchestra-research/sparse-autoencoder-training|sparse-autoencoder-training]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Provides guidance for training and analyzing Sparse Autoencoders (SAEs) using SAELens to decompose neural network activations into... |
| 10 | [[04-public-skills-directory/skills/orchestra-research/transformer-lens-interpretability|transformer-lens-interpretability]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Provides guidance for mechanistic interpretability research using TransformerLens to inspect and manipulate transformer internals via... |
| 11 | [[04-public-skills-directory/skills/guillaumelessard/qector-math-foundations|qector-math-foundations]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - The strict mathematical ground rules for every QECTOR claim. Encodes the F2 notation, the 16 correctness theorems, the Wilson 95% score... |

## Links

- Up: [[04-public-skills-directory/roles/quantum/engineering/_index|quantum/engineering]]
- Seed skills: [[03-skills/quantum/engineering/quantum-ml-engineer/README|quantum-ml-engineer seed skills]]
