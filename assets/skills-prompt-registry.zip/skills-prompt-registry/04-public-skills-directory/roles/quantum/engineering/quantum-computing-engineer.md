---
type: public-role-directory
role: quantum-computing-engineer
category: quantum/engineering
curator: Thomas Cherickal
count: 18
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/quantum-computing-engineer, category/quantum/engineering]
---

# quantum-computing-engineer: Public Skills (18)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/k-dense-ai/cirq|cirq]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Google quantum computing framework. Use when targeting Google Quantum AI hardware, designing noise-aware circuits, or running quantum... |
| 2 | [[04-public-skills-directory/skills/k-dense-ai/pennylane|pennylane]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Builds and differentiates PennyLane quantum circuits, hybrid PyTorch or JAX models, molecular VQE and QAOA workflows. Use for variational... |
| 3 | [[04-public-skills-directory/skills/k-dense-ai/qiskit|qiskit]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Builds, simulates, transpiles, and executes quantum circuits with Qiskit and IBM Quantum Runtime. Use for Qiskit 2.x circuits and... |
| 4 | [[04-public-skills-directory/skills/k-dense-ai/qutip|qutip]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Simulate and audit closed and open quantum-system models with QuTiP 5, including deterministic, trajectory, steady-state, spectral, and... |
| 5 | [[04-public-skills-directory/skills/guillaumelessard/qector-architecture|qector-architecture]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - QECTOR architecture overview: the Rust core / Python layer FFI boundary, the module map, the threading and memory models, the layering of... |
| 6 | [[04-public-skills-directory/skills/guillaumelessard/qector-batch-decoding|qector-batch-decoding]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Batch, streaming, and GPU-accelerated decoding paths for QECTOR. Covers the manual 13 CUDA / OpenCL bit-identity contract, the per-thread... |
| 7 | [[04-public-skills-directory/skills/guillaumelessard/qector-bp-osd|qector-bp-osd]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Belief propagation with ordered-statistics post-processing (BP-OSD) for QECTOR. Covers the box-plus kernel phi(x) = -ln(tanh(x/2)), the... |
| 8 | [[04-public-skills-directory/skills/guillaumelessard/qector-codes-builder|qector-codes-builder]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Building and inspecting QEC codes for QECTOR. Covers the v1.0.0 library code families (repetition, ring, rotated_surface,... |
| 9 | [[04-public-skills-directory/skills/guillaumelessard/qector-core|qector-core]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Core domain knowledge and verified facts for the QECTOR quantum error correction platform (plugin v2.0.1, decoder wheel 1.0.1). Covers... |
| 10 | [[04-public-skills-directory/skills/guillaumelessard/qector-decoders-deep-dive|qector-decoders-deep-dive]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Per-decoder internals from the v1.0.0 reference manual. For each of the the Provisional backends, gives the algorithm, the theorem(s) it... |
| 11 | [[04-public-skills-directory/skills/guillaumelessard/qector-dem-pipeline|qector-dem-pipeline]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Detector error model (DEM) parsing, collapse, priors, and routing for QECTOR. Covers the manual 14 collapse rule (independent-XOR... |
| 12 | [[04-public-skills-directory/skills/guillaumelessard/qector-deployment|qector-deployment]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - QECTOR deployment modes, security posture, and the production checklist. Covers the six deployment modes (manual 24, Table 24.1), the... |
| 13 | [[04-public-skills-directory/skills/guillaumelessard/qector-developer|qector-developer]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Software engineering integration content for QECTOR: wiring the MCP servers into applications, driving the stdio JSON-RPC 2.0 protocol,... |
| 14 | [[04-public-skills-directory/skills/guillaumelessard/qector-hardware-engineer|qector-hardware-engineer]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Physical-layer quantum circuits, detector-error-model preparation, qLDPC reasoning, and honest target-device hardware reporting for... |
| 15 | [[04-public-skills-directory/skills/guillaumelessard/qector-pymatching-compat|qector-pymatching-compat]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - The PyMatching-compatible shim in qector-decoder-v3 (manual 17.1). Covers `qector_decoder_v3.pymatching_compat.Matching` as a drop-in for... |
| 16 | [[04-public-skills-directory/skills/guillaumelessard/qector-sinter|qector-sinter]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - Sinter decoder entry points for QECTOR (manual 17.2). Covers `qector_decoder_v3.sinter_compat.qector_sinter_decoders()` (qector_blossom,... |
| 17 | [[04-public-skills-directory/skills/guillaumelessard/qector-testing-strategy|qector-testing-strategy]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - The QECTOR testing and validation strategy (manual 23). Covers the ten validation layers (syndrome faithfulness, property- based,... |
| 18 | [[04-public-skills-directory/skills/guillaumelessard/qector-workbench|qector-workbench]] | GuillaumeLessard | [GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) | 1 | NOASSERTION | - The optional QECTOR Workbench desktop application (manual 17.5, 20). Covers the device-local stdio MCP integration, the historical... |

## Links

- Up: [[04-public-skills-directory/roles/quantum/engineering/_index|quantum/engineering]]
- Seed skills: [[03-skills/quantum/engineering/quantum-computing-engineer/README|quantum-computing-engineer seed skills]]
