---
type: category-index
category: quantum
curator: Thomas Cherickal
tags: [moc, category/quantum]
updated: 2026-11-15
---

# quantum

- Up: [[04-public-skills-directory/README|Public directory]]
- Mirror in seed registry: [[03-skills/quantum/_index|quantum]]

## Subcategories

- [[04-public-skills-directory/roles/quantum/engineering/_index|quantum/engineering]]
- [[04-public-skills-directory/roles/quantum/research/_index|quantum/research]]
