---
type: category-index
category: design-and-content
curator: Thomas Cherickal
tags: [moc, category/design-and-content]
updated: 2026-11-15
---

# design-and-content

- Up: [[04-public-skills-directory/README|Public directory]]
- Mirror in seed registry: [[03-skills/design-and-content/_index|design-and-content]]

## Roles

- [[04-public-skills-directory/roles/design-and-content/technical-writer|technical-writer]] (20 skills)
- [[04-public-skills-directory/roles/design-and-content/web-designer|web-designer]] (14 skills)
