---
type: public-role-directory
role: web-designer
category: design-and-content
curator: Thomas Cherickal
count: 14
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/web-designer, category/design-and-content]
---

# web-designer: Public Skills (14)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/brand-discovery|brand-discovery]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Run a structured, resumable multi-session brand identity interview across 8 modules (purpose, positioning, audience, personality, voice,... |
| 2 | [[04-public-skills-directory/skills/affaan-m/design-system|design-system]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Generate a design system from an existing codebase or audit one for visual consistency: extract tokens (colors, typography, spacing,... |
| 3 | [[04-public-skills-directory/skills/affaan-m/frontend-design-direction|frontend-design-direction]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Set an ECC-specific frontend design direction for production UI work. Use when building or improving websites, dashboards, applications,... |
| 4 | [[04-public-skills-directory/skills/affaan-m/liquid-glass-design|liquid-glass-design]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | iOS 26 Liquid Glass design system — dynamic glass material with blur, reflection, and interactive morphing for SwiftUI, UIKit, and... |
| 5 | [[04-public-skills-directory/skills/anthropics/brand-guidelines|brand-guidelines]] | anthropics | [anthropics/skills](https://github.com/anthropics/skills) | 194,585 | null | Applies Anthropic's official brand colors and typography to any sort of artifact that may benefit from having Anthropic's look-and-feel.... |
| 6 | [[04-public-skills-directory/skills/anthropics/canvas-design|canvas-design]] | anthropics | [anthropics/skills](https://github.com/anthropics/skills) | 194,585 | null | Create beautiful visual art in .png and .pdf documents using design philosophy. You should use this skill when the user asks to create a... |
| 7 | [[04-public-skills-directory/skills/anthropics/frontend-design|frontend-design]] | anthropics | [anthropics/skills](https://github.com/anthropics/skills) | 194,585 | null | Guidance for distinctive, intentional visual design when building new UI or reshaping an existing one. Helps with aesthetic direction,... |
| 8 | [[04-public-skills-directory/skills/anthropics/theme-factory|theme-factory]] | anthropics | [anthropics/skills](https://github.com/anthropics/skills) | 194,585 | null | Toolkit for styling artifacts with a theme. These artifacts can be slides, docs, reportings, HTML landing pages, etc. There are 10 pre-set... |
| 9 | [[04-public-skills-directory/skills/k-dense-ai/infographics|infographics]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Creates and reviews infographics with Nano Banana 2 via OpenRouter. Use for statistical summaries, timelines, comparisons, processes, and... |
| 10 | [[04-public-skills-directory/skills/nutlope/hallmark|hallmark]] | Nutlope | [Nutlope/hallmark](https://github.com/Nutlope/hallmark) | 54,976 | MIT | Design skill for websites and new pages that look designed, not generated. Use when the user asks to build or design something new, or... |
| 11 | [[04-public-skills-directory/skills/sickn33/3d-ui|3d-ui]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Web and App implementation guide for 3D UI. Trigger when user wants actual 3D objects, perspective effects, and spatial depth. |
| 12 | [[04-public-skills-directory/skills/sickn33/ai-native-ui|ai-native-ui]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Web and App implementation guide for AI Native UI. Trigger when user wants conversational interfaces, adaptive layouts, and generative AI... |
| 13 | [[04-public-skills-directory/skills/wshobson/design-system-patterns|design-system-patterns]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Build scalable design systems with design tokens, theming infrastructure, and component architecture patterns. Use when creating design... |
| 14 | [[04-public-skills-directory/skills/wshobson/interaction-design|interaction-design]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Design and implement microinteractions, motion design, transitions, and user feedback patterns. Use when adding polish to UI interactions,... |

## Links

- Up: [[04-public-skills-directory/roles/design-and-content/_index|design-and-content]]
- Seed skills: [[03-skills/design-and-content/web-designer/README|web-designer seed skills]]
