---
type: public-role-directory
role: technical-writer
category: design-and-content
curator: Thomas Cherickal
count: 20
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/technical-writer, category/design-and-content]
---

# technical-writer: Public Skills (20)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/obra/writing-skills|writing-skills]] | obra | [obra/superpowers](https://github.com/obra/superpowers) | 317,619 | MIT | Use when creating new skills, editing existing skills, or verifying skills work before deployment |
| 2 | [[04-public-skills-directory/skills/affaan-m/article-writing|article-writing]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Write articles, guides, blog posts, tutorials, newsletter issues, and other long-form content in a distinctive voice derived from supplied... |
| 3 | [[04-public-skills-directory/skills/affaan-m/docs-governance|docs-governance]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Route broad documentation-governance requests to existing ECC skills and run an opt-in, read-only audit of mapped documentation roles,... |
| 4 | [[04-public-skills-directory/skills/affaan-m/documentation-lookup|documentation-lookup]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Use up-to-date library and framework docs via Context7 MCP instead of training data. Activates for setup questions, API references, code... |
| 5 | [[04-public-skills-directory/skills/affaan-m/living-docs-governance|living-docs-governance]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Keep a long-lived project's documentation from rotting by assigning existing project docs clear constitution, map, status, and history... |
| 6 | [[04-public-skills-directory/skills/anthropics/doc-coauthoring|doc-coauthoring]] | anthropics | [anthropics/skills](https://github.com/anthropics/skills) | 194,585 | null | Guide users through a structured workflow for co-authoring documentation. Use when user wants to write documentation, proposals, technical... |
| 7 | [[04-public-skills-directory/skills/k-dense-ai/markdown-mermaid-writing|markdown-mermaid-writing]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Writes scientific Markdown documentation and Mermaid diagrams for workflows, relationships, timelines, and schemas. Provides syntax... |
| 8 | [[04-public-skills-directory/skills/sickn33/api-documentation|api-documentation]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | API documentation workflow for generating OpenAPI specs, creating developer guides, and maintaining comprehensive API documentation. |
| 9 | [[04-public-skills-directory/skills/sickn33/api-documentation-generator|api-documentation-generator]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Generate comprehensive, developer-friendly API documentation from code, including endpoints, parameters, examples, and best practices |
| 10 | [[04-public-skills-directory/skills/sickn33/api-documenter|api-documenter]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Master API documentation with OpenAPI 3.1, AI-powered tools, and modern developer experience practices. Create interactive docs, generate... |
| 11 | [[04-public-skills-directory/skills/sickn33/app-store-changelog|app-store-changelog]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Generate user-facing App Store release notes from git history since the last tag. |
| 12 | [[04-public-skills-directory/skills/sickn33/avoid-ai-writing|avoid-ai-writing]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Audit and rewrite prose for repetitive, vague, or formulaic wording while preserving meaning, evidence, and the writer's voice. |
| 13 | [[04-public-skills-directory/skills/davila7/backend-to-frontend-handoff-docs|backend-to-frontend-handoff-docs]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Create API handoff documentation for frontend developers. Use when backend work is complete and needs to be documented for frontend... |
| 14 | [[04-public-skills-directory/skills/davila7/changelog-generator|changelog-generator]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Automatically creates user-facing changelogs from git commits by analyzing commit history, categorizing changes, and transforming technical... |
| 15 | [[04-public-skills-directory/skills/davila7/docs-search|docs-search]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Search auto-generated codebase documentation for function signatures, API docs, class definitions, and code comments. Use when the user... |
| 16 | [[04-public-skills-directory/skills/davila7/mermaid-diagram-specialist|mermaid-diagram-specialist]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Mermaid diagram specialist for creating flowcharts, sequence diagrams, ERDs, and architecture visualizations |
| 17 | [[04-public-skills-directory/skills/davila7/notion-research-documentation|notion-research-documentation]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Research across Notion and synthesize into structured documentation; use when gathering info from multiple Notion sources to produce... |
| 18 | [[04-public-skills-directory/skills/alirezarezvani/changelog|changelog]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Generate changelogs from git history and validate conventional commits. Usage: /changelog <generate/lint> [options] |
| 19 | [[04-public-skills-directory/skills/wanshuiyin/mermaid-diagram|mermaid-diagram]] | wanshuiyin | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) | 19,200 | MIT | Generate Mermaid diagrams from user requirements. Save .mmd and .md files to figures/ with syntax verification. Supports flowcharts,... |
| 20 | [[04-public-skills-directory/skills/wanshuiyin/specification-writing|specification-writing]] | wanshuiyin | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) | 19,200 | MIT | Write the full patent specification from claims and invention disclosure. Use when user says \"撰写说明书\", \"write specification\", \"写说明书\",... |

## Links

- Up: [[04-public-skills-directory/roles/design-and-content/_index|design-and-content]]
- Seed skills: [[03-skills/design-and-content/technical-writer/README|technical-writer seed skills]]
