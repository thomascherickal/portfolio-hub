---
type: public-role-directory
role: backend-engineer
category: software-engineering/application
curator: Thomas Cherickal
count: 20
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/backend-engineer, category/software-engineering/application]
---

# backend-engineer: Public Skills (20)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/api-design|api-design]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | REST API design patterns including resource naming, status codes, pagination, filtering, error responses, versioning, and rate limiting for... |
| 2 | [[04-public-skills-directory/skills/affaan-m/backend-patterns|backend-patterns]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Backend architecture patterns, API design, database optimization, and server-side best practices for Node.js, Express, and Next.js API... |
| 3 | [[04-public-skills-directory/skills/affaan-m/database-migrations|database-migrations]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Safe, reversible database migration patterns: forward-only production changes, expand-contract zero-downtime renames, concurrent indexes,... |
| 4 | [[04-public-skills-directory/skills/affaan-m/mysql-patterns|mysql-patterns]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | MySQL and MariaDB schema, query, indexing, transaction, replication, and connection-pool patterns for production backends. Use when... |
| 5 | [[04-public-skills-directory/skills/affaan-m/postgres-patterns|postgres-patterns]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | PostgreSQL database patterns for query optimization, schema design, indexing, and security. Based on Supabase best practices. Use when... |
| 6 | [[04-public-skills-directory/skills/sickn33/api-design-principles|api-design-principles]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Master REST and GraphQL API design principles to build intuitive, scalable, and maintainable APIs that delight developers and stand the... |
| 7 | [[04-public-skills-directory/skills/sickn33/backend-architect|backend-architect]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Expert backend architect specializing in scalable API design, microservices architecture, and distributed systems. |
| 8 | [[04-public-skills-directory/skills/sickn33/backend-dev-guidelines|backend-dev-guidelines]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | You are a senior backend engineer operating production-grade services under strict architectural and reliability constraints. Use when... |
| 9 | [[04-public-skills-directory/skills/sickn33/backend-development-feature-development|backend-development-feature-development]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Orchestrate end-to-end backend feature development from requirements to deployment. Use when coordinating multi-phase feature delivery... |
| 10 | [[04-public-skills-directory/skills/sickn33/backend-security-coder|backend-security-coder]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Expert in secure backend coding practices specializing in input validation, authentication, and API security. Use PROACTIVELY for backend... |
| 11 | [[04-public-skills-directory/skills/wshobson/postgresql-table-design|postgresql-table-design]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Use this skill when designing or reviewing a PostgreSQL-specific schema. Covers best-practices, data types, indexing, constraints,... |
| 12 | [[04-public-skills-directory/skills/davila7/backend-to-frontend-handoff-docs|backend-to-frontend-handoff-docs]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Create API handoff documentation for frontend developers. Use when backend work is complete and needs to be documented for frontend... |
| 13 | [[04-public-skills-directory/skills/davila7/frontend-to-backend-requirements|frontend-to-backend-requirements]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Document frontend data needs for backend developers. Use when frontend needs to communicate API requirements to backend, or user says... |
| 14 | [[04-public-skills-directory/skills/davila7/postgres-schema-design|postgres-schema-design]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Comprehensive PostgreSQL-specific table design reference covering data types, indexing, constraints, performance patterns, and advanced... |
| 15 | [[04-public-skills-directory/skills/davila7/senior-backend|senior-backend]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Comprehensive backend development skill for building scalable backend systems using NodeJS, Express, Go, Python, Postgres, GraphQL, REST... |
| 16 | [[04-public-skills-directory/skills/alirezarezvani/api-design-reviewer|api-design-reviewer]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Use for any PR or spec that adds or changes REST endpoints, before approving it. Lints conventions with api_linter.py, detects breaking... |
| 17 | [[04-public-skills-directory/skills/alirezarezvani/cs-backend-engineer|cs-backend-engineer]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Backend-engineering orchestrator. Walks the 7 Matt Pocock forcing questions (read/write ratio + QPS, tenancy, sync vs async, data... |
| 18 | [[04-public-skills-directory/skills/alirezarezvani/cs-backend-review|cs-backend-review]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Backend engineering review — walks the 7 Matt Pocock forcing questions (read/write ratio + QPS, tenancy, sync vs async, data sensitivity,... |
| 19 | [[04-public-skills-directory/skills/jeffallan/microservices-architect|microservices-architect]] | Jeffallan | [jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills) | 12,361 | MIT | Designs distributed system architectures, decomposes monoliths into bounded-context services, recommends communication patterns, and... |
| 20 | [[04-public-skills-directory/skills/jeffallan/postgres-pro|postgres-pro]] | Jeffallan | [jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills) | 12,361 | MIT | Use when optimizing PostgreSQL queries, configuring replication, or implementing advanced database features. Invoke for EXPLAIN analysis,... |

## Links

- Up: [[04-public-skills-directory/roles/software-engineering/application/_index|software-engineering/application]]
- Seed skills: [[03-skills/software-engineering/application/backend-engineer/README|backend-engineer seed skills]]
