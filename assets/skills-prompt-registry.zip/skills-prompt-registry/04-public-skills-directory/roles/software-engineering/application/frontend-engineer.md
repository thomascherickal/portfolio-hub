---
type: public-role-directory
role: frontend-engineer
category: software-engineering/application
curator: Thomas Cherickal
count: 20
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/frontend-engineer, category/software-engineering/application]
---

# frontend-engineer: Public Skills (20)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/accessibility|accessibility]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Design, implement, and audit accessible UI to WCAG 2.2 Level AA across Web, iOS, and Android — semantic ARIA roles and labels,... |
| 2 | [[04-public-skills-directory/skills/affaan-m/angular-developer|angular-developer]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Generates Angular code and provides architectural guidance. Trigger when creating projects, components, or services, or for best practices... |
| 3 | [[04-public-skills-directory/skills/affaan-m/browser-qa|browser-qa]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Run automated post-deploy UI verification with a browser automation MCP (claude-in-chrome, Playwright, or Puppeteer): console-error and... |
| 4 | [[04-public-skills-directory/skills/affaan-m/frontend-a11y|frontend-a11y]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Accessibility patterns for React and Next.js — semantic HTML, ARIA attributes, form labeling, keyboard navigation, focus management, and... |
| 5 | [[04-public-skills-directory/skills/affaan-m/frontend-design-direction|frontend-design-direction]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Set an ECC-specific frontend design direction for production UI work. Use when building or improving websites, dashboards, applications,... |
| 6 | [[04-public-skills-directory/skills/anthropics/frontend-design|frontend-design]] | anthropics | [anthropics/skills](https://github.com/anthropics/skills) | 194,585 | null | Guidance for distinctive, intentional visual design when building new UI or reshaping an existing one. Helps with aesthetic direction,... |
| 7 | [[04-public-skills-directory/skills/anthropics/webapp-testing|webapp-testing]] | anthropics | [anthropics/skills](https://github.com/anthropics/skills) | 194,585 | null | Toolkit for interacting with and testing local web applications using Playwright. Supports verifying frontend functionality, debugging UI... |
| 8 | [[04-public-skills-directory/skills/sickn33/accessibility-compliance-accessibility-audit|accessibility-compliance-accessibility-audit]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Audit pages and user journeys against a declared WCAG scope. Use when identifying keyboard, screen-reader, focus or contrast barriers and... |
| 9 | [[04-public-skills-directory/skills/sickn33/angular|angular]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Modern Angular (v20+) expert with deep knowledge of Signals, Standalone Components, Zoneless applications, SSR/Hydration, and reactive... |
| 10 | [[04-public-skills-directory/skills/sickn33/angular-best-practices|angular-best-practices]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Angular performance optimization and best practices guide. Use when writing, reviewing, or refactoring Angular code for optimal... |
| 11 | [[04-public-skills-directory/skills/sickn33/angular-migration|angular-migration]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Master AngularJS to Angular migration, including hybrid apps, component conversion, dependency injection changes, and routing migration. |
| 12 | [[04-public-skills-directory/skills/sickn33/angular-state-management|angular-state-management]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Master modern Angular state management with Signals, NgRx, and RxJS. Use when setting up global state, managing component stores, choosing... |
| 13 | [[04-public-skills-directory/skills/wshobson/accessibility-compliance|accessibility-compliance]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Implement WCAG 2.2 compliant interfaces with mobile accessibility, inclusive design patterns, and assistive technology support. Use when... |
| 14 | [[04-public-skills-directory/skills/wshobson/react-native-design|react-native-design]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Master React Native styling, navigation, and Reanimated animations for cross-platform mobile development. Use when building React Native... |
| 15 | [[04-public-skills-directory/skills/davila7/accessibility-auditor|accessibility-auditor]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Web accessibility specialist for WCAG compliance, ARIA implementation, and inclusive design. Use when auditing websites for accessibility... |
| 16 | [[04-public-skills-directory/skills/davila7/backend-to-frontend-handoff-docs|backend-to-frontend-handoff-docs]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Create API handoff documentation for frontend developers. Use when backend work is complete and needs to be documented for frontend... |
| 17 | [[04-public-skills-directory/skills/davila7/frontend-to-backend-requirements|frontend-to-backend-requirements]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Document frontend data needs for backend developers. Use when frontend needs to communicate API requirements to backend, or user says... |
| 18 | [[04-public-skills-directory/skills/davila7/react-dev|react-dev]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | This skill should be used when building React components with TypeScript, typing hooks, handling events, or when React TypeScript, React... |
| 19 | [[04-public-skills-directory/skills/davila7/react-useeffect|react-useeffect]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | React useEffect best practices from official docs. Use when writing/reviewing useEffect, useState for derived values, data fetching, or... |
| 20 | [[04-public-skills-directory/skills/alirezarezvani/a11y-audit|a11y-audit]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Use for any accessibility audit or a11y fix (WCAG 2.2 A/AA, color contrast, compliance report, CI check) in React, Next.js, Vue, Angular,... |

## Links

- Up: [[04-public-skills-directory/roles/software-engineering/application/_index|software-engineering/application]]
- Seed skills: [[03-skills/software-engineering/application/frontend-engineer/README|frontend-engineer seed skills]]
