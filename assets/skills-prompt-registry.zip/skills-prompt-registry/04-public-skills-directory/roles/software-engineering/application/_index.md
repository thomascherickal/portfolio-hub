---
type: category-index
category: software-engineering/application
curator: Thomas Cherickal
tags: [moc, category/software-engineering/application]
updated: 2026-11-15
---

# software-engineering/application

- Up: [[04-public-skills-directory/roles/software-engineering/_index|software-engineering]]
- Mirror in seed registry: [[03-skills/software-engineering/application/_index|software-engineering/application]]

## Roles

- [[04-public-skills-directory/roles/software-engineering/application/backend-engineer|backend-engineer]] (20 skills)
- [[04-public-skills-directory/roles/software-engineering/application/frontend-engineer|frontend-engineer]] (20 skills)
- [[04-public-skills-directory/roles/software-engineering/application/fullstack-engineer|fullstack-engineer]] (18 skills)
- [[04-public-skills-directory/roles/software-engineering/application/pwa-engineer|pwa-engineer]] (15 skills)
