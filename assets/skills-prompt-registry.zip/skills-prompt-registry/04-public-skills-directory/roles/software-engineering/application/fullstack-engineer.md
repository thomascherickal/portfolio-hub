---
type: public-role-directory
role: fullstack-engineer
category: software-engineering/application
curator: Thomas Cherickal
count: 18
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/fullstack-engineer, category/software-engineering/application]
---

# fullstack-engineer: Public Skills (18)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/nextjs-turbopack|nextjs-turbopack]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Next.js 16+ and Turbopack guidance — incremental Rust bundling, file-system caching, faster dev startup and HMR, Turbopack vs webpack... |
| 2 | [[04-public-skills-directory/skills/anthropics/web-artifacts-builder|web-artifacts-builder]] | anthropics | [anthropics/skills](https://github.com/anthropics/skills) | 194,585 | null | Suite of tools for creating elaborate, multi-component claude.ai HTML artifacts using modern frontend web technologies (React, Tailwind... |
| 3 | [[04-public-skills-directory/skills/sickn33/app-builder|app-builder]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Main application building orchestrator. Creates full-stack applications from natural language requests. Determines project type, selects... |
| 4 | [[04-public-skills-directory/skills/sickn33/auth-implementation-patterns|auth-implementation-patterns]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Implement or review authentication and authorization with explicit token, session and resource-access boundaries. |
| 5 | [[04-public-skills-directory/skills/sickn33/clerk-auth|clerk-auth]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Expert patterns for Clerk auth implementation, middleware, organizations, webhooks, and user sync |
| 6 | [[04-public-skills-directory/skills/sickn33/full-stack-orchestration-full-stack-feature|full-stack-orchestration-full-stack-feature]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Use when working with full stack orchestration full stack feature |
| 7 | [[04-public-skills-directory/skills/sickn33/hunt-nextjs|hunt-nextjs]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Hunt Next.js specific vulnerabilities |
| 8 | [[04-public-skills-directory/skills/sickn33/markstream-nuxt|markstream-nuxt]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Integrate markstream-vue into Nuxt 3 or 4 with SSR-safe client boundaries, renderer modes, explicit CSS, and browser-only optional peers. |
| 9 | [[04-public-skills-directory/skills/sickn33/micro-saas-launcher|micro-saas-launcher]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Expert in launching small, focused SaaS products fast - the indie hacker approach to building profitable software. Covers idea validation,... |
| 10 | [[04-public-skills-directory/skills/sickn33/nextjs-app-router-patterns|nextjs-app-router-patterns]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Comprehensive patterns for Next.js 14+ App Router architecture, Server Components, and modern full-stack React development. |
| 11 | [[04-public-skills-directory/skills/alirezarezvani/cs-fullstack-engineer|cs-fullstack-engineer]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Fullstack-engineering orchestrator. Walks the Matt Pocock 7-question forcing-question grill, runs the deterministic profile picker, then... |
| 12 | [[04-public-skills-directory/skills/alirezarezvani/cs-fullstack-review|cs-fullstack-review]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Fullstack engineering review — walks the 7 Matt Pocock forcing questions, picks the profile, forks into POWERFUL specialists... |
| 13 | [[04-public-skills-directory/skills/alirezarezvani/saas-health|saas-health]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Calculate SaaS health metrics (ARR, MRR, churn, CAC, LTV, NRR) and benchmark against industry standards. Usage: /saas-health... |
| 14 | [[04-public-skills-directory/skills/alirezarezvani/saas-metrics-coach|saas-metrics-coach]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Use when someone shares SaaS revenue or customer numbers, or asks about ARR, MRR, churn, LTV, CAC, NRR or how their SaaS is doing. Computes... |
| 15 | [[04-public-skills-directory/skills/alirezarezvani/saas-scaffolder|saas-scaffolder]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Use when starting a new SaaS app with auth, database, Stripe billing and a dashboard (Next.js App Router, TypeScript, Tailwind, shadcn/ui,... |
| 16 | [[04-public-skills-directory/skills/alirezarezvani/stripe-integration-expert|stripe-integration-expert]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Use for any Stripe integration: subscriptions, trials, proration, checkout, usage billing, webhooks, customer portal or invoicing in... |
| 17 | [[04-public-skills-directory/skills/jeffallan/fullstack-guardian|fullstack-guardian]] | Jeffallan | [jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills) | 12,361 | MIT | Builds security-focused full-stack web applications by implementing integrated frontend and backend components with layered security at... |
| 18 | [[04-public-skills-directory/skills/jeffallan/nextjs-developer|nextjs-developer]] | Jeffallan | [jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills) | 12,361 | MIT | Use when building Next.js 14+ applications with App Router, server components, or server actions. Invoke to configure route handlers,... |

## Links

- Up: [[04-public-skills-directory/roles/software-engineering/application/_index|software-engineering/application]]
- Seed skills: [[03-skills/software-engineering/application/fullstack-engineer/README|fullstack-engineer seed skills]]
