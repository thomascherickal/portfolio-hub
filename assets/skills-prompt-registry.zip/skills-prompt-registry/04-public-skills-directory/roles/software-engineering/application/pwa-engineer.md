---
type: public-role-directory
role: pwa-engineer
category: software-engineering/application
curator: Thomas Cherickal
count: 15
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/pwa-engineer, category/software-engineering/application]
---

# pwa-engineer: Public Skills (15)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/vite-patterns|vite-patterns]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Vite build tool patterns including config, plugins, HMR, env variables, proxy setup, SSR, library mode, dependency pre-bundling, and build... |
| 2 | [[04-public-skills-directory/skills/anthropics/webapp-testing|webapp-testing]] | anthropics | [anthropics/skills](https://github.com/anthropics/skills) | 194,585 | null | Toolkit for interacting with and testing local web applications using Playwright. Supports verifying frontend functionality, debugging UI... |
| 3 | [[04-public-skills-directory/skills/sickn33/chrome-extension-developer|chrome-extension-developer]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Expert in building Chrome Extensions using Manifest V3. Covers background scripts, service workers, content scripts, and cross-context... |
| 4 | [[04-public-skills-directory/skills/sickn33/frontend-lighthouse|frontend-lighthouse]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Add a portable Lighthouse CI gate for production frontend builds with Core Web Vitals budgets, category floors, median runs, and CI... |
| 5 | [[04-public-skills-directory/skills/sickn33/javascript-pro|javascript-pro]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Master modern JavaScript with ES6+, async patterns, and Node.js APIs. Handles promises, event loops, and browser/Node compatibility. |
| 6 | [[04-public-skills-directory/skills/sickn33/modern-javascript-patterns|modern-javascript-patterns]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Comprehensive guide for mastering modern JavaScript (ES6+) features, functional programming patterns, and best practices for writing clean,... |
| 7 | [[04-public-skills-directory/skills/sickn33/progressive-web-app|progressive-web-app]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Build Progressive Web Apps (PWAs) with offline support, installability, and caching strategies. Trigger whenever the user mentions PWA,... |
| 8 | [[04-public-skills-directory/skills/sickn33/text-to-html-converter|text-to-html-converter]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Text to HTML Converter. Use when working with plain text and optional structure preferences. |
| 9 | [[04-public-skills-directory/skills/sickn33/web-performance-optimization|web-performance-optimization]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Optimize website and web application performance including loading speed, Core Web Vitals, bundle size, caching strategies, and runtime... |
| 10 | [[04-public-skills-directory/skills/wshobson/web-component-design|web-component-design]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Master React, Vue, and Svelte component patterns including CSS-in-JS, composition strategies, and reusable component architecture. Use when... |
| 11 | [[04-public-skills-directory/skills/davila7/core-web-vitals|core-web-vitals]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Optimize Core Web Vitals (LCP, INP, CLS) for better page experience and search ranking. Use when asked to "improve Core Web Vitals", "fix... |
| 12 | [[04-public-skills-directory/skills/alirezarezvani/markdown-html-orchestrator|markdown-html-orchestrator]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Use when the user wants a markdown file turned into a single-file interactive HTML page (document, code review or slide deck). Classifies... |
| 13 | [[04-public-skills-directory/skills/wanshuiyin/render-html|render-html]] | wanshuiyin | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) | 19,200 | MIT | Render an ARIS Markdown / JSON artifact (IDEA_REPORT, AUTO_REVIEW, KILL_ARGUMENT, PAPER_PLAN, research-wiki state, etc.) into a single-file... |
| 14 | [[04-public-skills-directory/skills/google-labs-code/stitch-extract-static-html|stitch::extract-static-html]] | google-labs-code | [google-labs-code/stitch-skills](https://github.com/google-labs-code/stitch-skills) | 8,871 | Apache-2.0 | - Extract self-contained static HTML from a built web application or React components by inlining CSS and images. Use this skill whenever... |
| 15 | [[04-public-skills-directory/skills/dfinity/static-site|static-site]] | dfinity | [dfinity/icskills](https://github.com/dfinity/icskills) | 40 | Apache-2.0 | Deploy a frontend or any static site to the IC with the @dfinity/static-site recipe (the certified-assets canister). Covers icp.yaml recipe... |

## Links

- Up: [[04-public-skills-directory/roles/software-engineering/application/_index|software-engineering/application]]
- Seed skills: [[03-skills/software-engineering/application/pwa-engineer/README|pwa-engineer seed skills]]
