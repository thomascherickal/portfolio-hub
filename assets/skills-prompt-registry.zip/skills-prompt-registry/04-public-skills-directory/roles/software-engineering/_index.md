---
type: category-index
category: software-engineering
curator: Thomas Cherickal
tags: [moc, category/software-engineering]
updated: 2026-11-15
---

# software-engineering

- Up: [[04-public-skills-directory/README|Public directory]]
- Mirror in seed registry: [[03-skills/software-engineering/_index|software-engineering]]

## Subcategories

- [[04-public-skills-directory/roles/software-engineering/application/_index|software-engineering/application]]
- [[04-public-skills-directory/roles/software-engineering/general/_index|software-engineering/general]]
- [[04-public-skills-directory/roles/software-engineering/languages/_index|software-engineering/languages]]
