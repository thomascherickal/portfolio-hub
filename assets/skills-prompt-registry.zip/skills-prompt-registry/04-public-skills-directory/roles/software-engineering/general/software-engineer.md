---
type: public-role-directory
role: software-engineer
category: software-engineering/general
curator: Thomas Cherickal
count: 20
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/software-engineer, category/software-engineering/general]
---

# software-engineer: Public Skills (20)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/obra/brainstorming|brainstorming]] | obra | [obra/superpowers](https://github.com/obra/superpowers) | 317,619 | MIT | You MUST use this before any creative work - creating features, building components, adding functionality, modifying behavior, or planning... |
| 2 | [[04-public-skills-directory/skills/obra/executing-plans|executing-plans]] | obra | [obra/superpowers](https://github.com/obra/superpowers) | 317,619 | MIT | Use when executing an implementation plan in the current session as the implementer yourself — your human partner chose inline execution,... |
| 3 | [[04-public-skills-directory/skills/obra/finishing-a-development-branch|finishing-a-development-branch]] | obra | [obra/superpowers](https://github.com/obra/superpowers) | 317,619 | MIT | Use when implementation is complete, all tests pass, and you need to decide how to integrate the work |
| 4 | [[04-public-skills-directory/skills/obra/receiving-code-review|receiving-code-review]] | obra | [obra/superpowers](https://github.com/obra/superpowers) | 317,619 | MIT | Use when receiving code review feedback, before implementing suggestions, especially if feedback seems unclear or technically questionable... |
| 5 | [[04-public-skills-directory/skills/obra/requesting-code-review|requesting-code-review]] | obra | [obra/superpowers](https://github.com/obra/superpowers) | 317,619 | MIT | Use when completing tasks, implementing major features, or before merging to verify work meets requirements |
| 6 | [[04-public-skills-directory/skills/affaan-m/architecture-decision-records|architecture-decision-records]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Capture architectural decisions as numbered ADR markdown files in docs/adr/ with context, alternatives considered, consequences, and an... |
| 7 | [[04-public-skills-directory/skills/affaan-m/django-tdd|django-tdd]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Django testing strategies with pytest-django, TDD methodology, factory_boy, mocking, coverage, and testing Django REST Framework APIs. Use... |
| 8 | [[04-public-skills-directory/skills/affaan-m/flutter-dart-code-review|flutter-dart-code-review]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Library-agnostic Flutter/Dart code review checklist covering widget best practices, state management patterns (BLoC, Riverpod, Provider,... |
| 9 | [[04-public-skills-directory/skills/affaan-m/laravel-tdd|laravel-tdd]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Laravel testing strategies with PHPUnit, Pest, model factories, HTTP tests, Sanctum authentication testing, mocking, and coverage. Use when... |
| 10 | [[04-public-skills-directory/skills/affaan-m/quarkus-tdd|quarkus-tdd]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Test-driven development for Quarkus 3.x LTS using JUnit 5, Mockito, REST Assured, Camel testing, and JaCoCo. Use when adding features,... |
| 11 | [[04-public-skills-directory/skills/k-dense-ai/scientific-brainstorming|scientific-brainstorming]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Facilitates evidence-aware scientific ideation with independent generation, structured discussion, explicit assumptions, transparent... |
| 12 | [[04-public-skills-directory/skills/sickn33/clean-code|clean-code]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | This skill embodies the principles of \"Clean Code\" by Robert C. Martin (Uncle Bob). Use it to transform \"code that works\" into \"code... |
| 13 | [[04-public-skills-directory/skills/sickn33/clean-code-guard|clean-code-guard]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Review generated or changed production code with Clean Code, SOLID, DRY, KISS, YAGNI, and LLM-specific failure-mode checks. |
| 14 | [[04-public-skills-directory/skills/sickn33/code-refactoring-context-restore|code-refactoring-context-restore]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Resume interrupted project work from a handoff and current checkout evidence; reconcile completed work, pending changes and existing user... |
| 15 | [[04-public-skills-directory/skills/sickn33/code-refactoring-refactor-clean|code-refactoring-refactor-clean]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | You are a code refactoring expert specializing in clean code principles, SOLID design patterns, and modern software engineering best... |
| 16 | [[04-public-skills-directory/skills/sickn33/code-refactoring-tech-debt|code-refactoring-tech-debt]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Identify technical debt from actual code and change history, estimate its impact, and prioritize bounded improvements with explicit... |
| 17 | [[04-public-skills-directory/skills/davila7/agent-md-refactor|agent-md-refactor]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Refactor bloated AGENTS.md, CLAUDE.md, or similar agent instruction files to follow progressive disclosure principles. Splits monolithic... |
| 18 | [[04-public-skills-directory/skills/davila7/code-review|code-review]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Perform code reviews following Sentry engineering practices. Use when reviewing pull requests, examining code changes, or providing... |
| 19 | [[04-public-skills-directory/skills/alirezarezvani/tdd-guide|tdd-guide]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Test-first development and test generation for Jest, Pytest, JUnit, Vitest or Mocha: red-green-refactor, fixtures and mocks, coverage gaps.... |
| 20 | [[04-public-skills-directory/skills/orchestra-research/brainstorming-research-ideas|brainstorming-research-ideas]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Guides researchers through structured ideation frameworks to discover high-impact research directions. Use when exploring new problem... |

## Links

- Up: [[04-public-skills-directory/roles/software-engineering/general/_index|software-engineering/general]]
- Seed skills: [[03-skills/software-engineering/general/software-engineer/README|software-engineer seed skills]]
