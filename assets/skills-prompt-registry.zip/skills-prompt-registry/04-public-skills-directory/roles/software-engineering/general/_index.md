---
type: category-index
category: software-engineering/general
curator: Thomas Cherickal
tags: [moc, category/software-engineering/general]
updated: 2026-11-15
---

# software-engineering/general

- Up: [[04-public-skills-directory/roles/software-engineering/_index|software-engineering]]
- Mirror in seed registry: [[03-skills/software-engineering/general/_index|software-engineering/general]]

## Roles

- [[04-public-skills-directory/roles/software-engineering/general/software-engineer|software-engineer]] (20 skills)
