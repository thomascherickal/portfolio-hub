---
type: public-role-directory
role: go-engineer
category: software-engineering/languages
curator: Thomas Cherickal
count: 13
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/go-engineer, category/software-engineering/languages]
---

# go-engineer: Public Skills (13)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/golang-patterns|golang-patterns]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Idiomatic Go patterns, best practices, and conventions for building robust, efficient, and maintainable Go applications. Use when writing... |
| 2 | [[04-public-skills-directory/skills/affaan-m/golang-testing|golang-testing]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Go testing patterns including table-driven tests, subtests, benchmarks, fuzzing, and test coverage. Follows TDD methodology with idiomatic... |
| 3 | [[04-public-skills-directory/skills/sickn33/dbos-golang|dbos-golang]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Guide for building reliable, fault-tolerant Go applications with DBOS durable workflows. Use when adding DBOS to existing Go code, creating... |
| 4 | [[04-public-skills-directory/skills/sickn33/faf-go|faf-go]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Guided interview to Gold Code (100% AI-Readiness). Use when helping users improve their .faf file through questions. Leverages Claude... |
| 5 | [[04-public-skills-directory/skills/sickn33/go|go]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Language-specific super-code guidelines for go. |
| 6 | [[04-public-skills-directory/skills/sickn33/go-concurrency-patterns|go-concurrency-patterns]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Master Go concurrency with goroutines, channels, sync primitives, and context. Use when building concurrent Go applications, implementing... |
| 7 | [[04-public-skills-directory/skills/sickn33/go-in-depth|go-in-depth]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Go in depth harness — fan-out web searches, fetch sources, adversarially verify claims, synthesize a cited report. |
| 8 | [[04-public-skills-directory/skills/sickn33/go-playwright|go-playwright]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Expert capability for robust, stealthy, and efficient browser automation using Playwright Go. |
| 9 | [[04-public-skills-directory/skills/sickn33/go-rod-master|go-rod-master]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Comprehensive guide for browser automation and web scraping with go-rod (Chrome DevTools Protocol) including stealth anti-bot-detection... |
| 10 | [[04-public-skills-directory/skills/sickn33/go-rust-reverse|go-rust-reverse]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Reverse engineer stripped Go and Rust binaries: runtime recognition, pclntab/module metadata recovery, panic-string analysis, and idiomatic... |
| 11 | [[04-public-skills-directory/skills/sickn33/golang-pro|golang-pro]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Master Go 1.21+ with modern patterns, advanced concurrency, performance optimization, and production-ready microservices. |
| 12 | [[04-public-skills-directory/skills/sickn33/grpc-golang|grpc-golang]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Build production-ready gRPC services in Go with mTLS, streaming, and observability. Use when designing Protobuf contracts with Buf or... |
| 13 | [[04-public-skills-directory/skills/sickn33/temporal-golang-pro|temporal-golang-pro]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Use when building durable distributed systems with Temporal Go SDK. Covers deterministic workflow rules, mTLS worker configs, and advanced... |

## Links

- Up: [[04-public-skills-directory/roles/software-engineering/languages/_index|software-engineering/languages]]
- Seed skills: [[03-skills/software-engineering/languages/go-engineer/README|go-engineer seed skills]]
