---
type: public-role-directory
role: python-engineer
category: software-engineering/languages
curator: Thomas Cherickal
count: 20
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/python-engineer, category/software-engineering/languages]
---

# python-engineer: Public Skills (20)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/django-celery|django-celery]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Django + Celery async task patterns — configuration, task design, beat scheduling, retries, canvas workflows, monitoring, and testing. Use... |
| 2 | [[04-public-skills-directory/skills/affaan-m/django-patterns|django-patterns]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Django architecture patterns, REST API design with DRF, ORM best practices, caching, signals, middleware, and production-grade Django apps.... |
| 3 | [[04-public-skills-directory/skills/affaan-m/django-security|django-security]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Django security best practices, authentication, authorization, CSRF protection, SQL injection prevention, XSS prevention, and secure... |
| 4 | [[04-public-skills-directory/skills/affaan-m/django-tdd|django-tdd]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Django testing strategies with pytest-django, TDD methodology, factory_boy, mocking, coverage, and testing Django REST Framework APIs. Use... |
| 5 | [[04-public-skills-directory/skills/affaan-m/django-verification|django-verification]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Run the full Django verification loop — environment check, mypy/ruff/black linting, migration safety, pytest with coverage targets,... |
| 6 | [[04-public-skills-directory/skills/k-dense-ai/zarr-python|zarr-python]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Stores and queries chunked N-D scientific arrays with Zarr-Python 3, including codecs, sharding, S3/GCS storage, and NumPy/Dask/Xarray... |
| 7 | [[04-public-skills-directory/skills/sickn33/async-python-patterns|async-python-patterns]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Comprehensive guidance for implementing asynchronous Python applications using asyncio, concurrent programming patterns, and async/await... |
| 8 | [[04-public-skills-directory/skills/sickn33/dbos-python|dbos-python]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Guide for building reliable, fault-tolerant Python applications with DBOS durable workflows. Use when adding DBOS to existing Python code,... |
| 9 | [[04-public-skills-directory/skills/sickn33/django-access-review|django-access-review]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Use when reviewing Django or DRF access control: trace authorization flows, IDOR risks, object permissions, query scoping and tenant... |
| 10 | [[04-public-skills-directory/skills/sickn33/django-perf-review|django-perf-review]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Django performance code review. Use when asked to "review Django performance", "find N+1 queries", "optimize Django", "check queryset... |
| 11 | [[04-public-skills-directory/skills/sickn33/django-pro|django-pro]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Master Django 5.x with async views, DRF, Celery, and Django Channels. Build scalable web applications with proper architecture, testing,... |
| 12 | [[04-public-skills-directory/skills/wshobson/python-anti-patterns|python-anti-patterns]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Use this skill when reviewing Python code for common anti-patterns to avoid. Use as a checklist when reviewing code, before finalizing... |
| 13 | [[04-public-skills-directory/skills/wshobson/python-background-jobs|python-background-jobs]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Python background job patterns including task queues, workers, and event-driven architecture. Use when implementing async task processing,... |
| 14 | [[04-public-skills-directory/skills/wshobson/python-code-style|python-code-style]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Python code style, linting, formatting, naming conventions, and documentation standards. Use when writing new code, reviewing style,... |
| 15 | [[04-public-skills-directory/skills/wshobson/python-configuration|python-configuration]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Python configuration management via environment variables and typed settings. Use when externalizing config, setting up pydantic-settings,... |
| 16 | [[04-public-skills-directory/skills/wshobson/python-design-patterns|python-design-patterns]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Python design patterns including KISS, Separation of Concerns, Single Responsibility, and composition over inheritance. Use this skill when... |
| 17 | [[04-public-skills-directory/skills/davila7/fastapi-endpoint|fastapi-endpoint]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Plan and build production-ready FastAPI endpoints with async SQLAlchemy, Pydantic v2 models, dependency injection for auth, and pytest... |
| 18 | [[04-public-skills-directory/skills/jeffallan/django-expert|django-expert]] | Jeffallan | [jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills) | 12,361 | MIT | Use when building Django web applications or REST APIs with Django REST Framework. Invoke when working with settings.py, models.py,... |
| 19 | [[04-public-skills-directory/skills/jeffallan/django-storages-s3|django-storages-s3]] | Jeffallan | [jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills) | 12,361 | MIT | Use when configuring Django to store static and media files on AWS S3 with django-storages. Invoke when working with the STORAGES setting,... |
| 20 | [[04-public-skills-directory/skills/jeffallan/fastapi-expert|fastapi-expert]] | Jeffallan | [jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills) | 12,361 | MIT | Use when building high-performance async Python APIs with FastAPI and Pydantic V2. Invoke to create REST endpoints, define Pydantic models,... |

## Links

- Up: [[04-public-skills-directory/roles/software-engineering/languages/_index|software-engineering/languages]]
- Seed skills: [[03-skills/software-engineering/languages/python-engineer/README|python-engineer seed skills]]
