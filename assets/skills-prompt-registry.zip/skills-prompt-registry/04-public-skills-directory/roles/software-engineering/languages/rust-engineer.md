---
type: public-role-directory
role: rust-engineer
category: software-engineering/languages
curator: Thomas Cherickal
count: 16
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/rust-engineer, category/software-engineering/languages]
---

# rust-engineer: Public Skills (16)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/rust-patterns|rust-patterns]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Idiomatic Rust patterns, ownership, error handling, traits, concurrency, and best practices for building safe, performant applications. Use... |
| 2 | [[04-public-skills-directory/skills/affaan-m/rust-testing|rust-testing]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Rust testing patterns including unit tests, integration tests, async testing, property-based testing, mocking, and coverage. Follows TDD... |
| 3 | [[04-public-skills-directory/skills/sickn33/azure-cosmos-rust|azure-cosmos-rust]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Azure Cosmos DB SDK for Rust (NoSQL API). Use for document CRUD, queries, containers, and globally distributed data. |
| 4 | [[04-public-skills-directory/skills/sickn33/azure-eventhub-rust|azure-eventhub-rust]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Azure Event Hubs SDK for Rust. Use for sending and receiving events, streaming data ingestion. |
| 5 | [[04-public-skills-directory/skills/sickn33/go-rust-reverse|go-rust-reverse]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Reverse engineer stripped Go and Rust binaries: runtime recognition, pclntab/module metadata recovery, panic-string analysis, and idiomatic... |
| 6 | [[04-public-skills-directory/skills/sickn33/rust|rust]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Language-specific super-code guidelines for rust. |
| 7 | [[04-public-skills-directory/skills/sickn33/rust-async-patterns|rust-async-patterns]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Master Rust async programming with Tokio, async traits, error handling, and concurrent patterns. Use when building async Rust applications,... |
| 8 | [[04-public-skills-directory/skills/sickn33/rust-pro|rust-pro]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Master Rust 1.75+ with modern async patterns, advanced type system features, and production-ready systems programming. |
| 9 | [[04-public-skills-directory/skills/sickn33/systems-programming-rust-project|systems-programming-rust-project]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | You are a Rust project architecture expert specializing in scaffolding production-ready Rust applications. Generate complete project... |
| 10 | [[04-public-skills-directory/skills/davila7/rust-cli-builder|rust-cli-builder]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Plan and build production-ready Rust CLI tools using clap for argument parsing, with subcommands, config file support, colored output, and... |
| 11 | [[04-public-skills-directory/skills/jeffallan/rust-engineer|rust-engineer]] | Jeffallan | [jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills) | 12,361 | MIT | Writes, reviews, and debugs idiomatic Rust code with memory safety and zero-cost abstractions. Implements ownership patterns, manages... |
| 12 | [[04-public-skills-directory/skills/trailofbits/cargo-fuzz|cargo-fuzz]] | trailofbits | [trailofbits/skills](https://github.com/trailofbits/skills) | 8,189 | CC-BY-SA-4.0 | Sets up and runs cargo-fuzz, the standard fuzzing tool for Cargo-based Rust projects. Covers cargo fuzz init, the nightly toolchain... |
| 13 | [[04-public-skills-directory/skills/trailofbits/rust-review|rust-review]] | trailofbits | [trailofbits/skills](https://github.com/trailofbits/skills) | 8,189 | CC-BY-SA-4.0 | Performs comprehensive Rust security review for safe/unsafe boundary issues, memory safety in unsafe blocks, concurrency hazards,... |
| 14 | [[04-public-skills-directory/skills/trailofbits/ruzzy|ruzzy]] | trailofbits | [trailofbits/skills](https://github.com/trailofbits/skills) | 8,189 | CC-BY-SA-4.0 | Sets up and runs Ruzzy, Trail of Bits' coverage-guided Ruby fuzzer and the only production-ready one for the language. Covers harness... |
| 15 | [[04-public-skills-directory/skills/morganlinton/rust-best-practices|rust-best-practices]] | morganlinton | [morganlinton/BeautifulRust](https://github.com/morganlinton/BeautifulRust) | 1,813 | MIT | - Write idiomatic, robust, maintainable Rust. Use this skill whenever you write, review, refactor, debug, or explain Rust code: new crates,... |
| 16 | [[04-public-skills-directory/skills/morganlinton/rust-port|rust-port]] | morganlinton | [morganlinton/BeautifulRust](https://github.com/morganlinton/BeautifulRust) | 1,813 | MIT | - Port code from C, C++, Python, Go, JavaScript, or TypeScript into idiomatic Rust that keeps the original behavior: ownership instead of... |

## Links

- Up: [[04-public-skills-directory/roles/software-engineering/languages/_index|software-engineering/languages]]
- Seed skills: [[03-skills/software-engineering/languages/rust-engineer/README|rust-engineer seed skills]]
