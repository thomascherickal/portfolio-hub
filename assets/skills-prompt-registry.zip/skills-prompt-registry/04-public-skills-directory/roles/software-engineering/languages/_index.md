---
type: category-index
category: software-engineering/languages
curator: Thomas Cherickal
tags: [moc, category/software-engineering/languages]
updated: 2026-11-15
---

# software-engineering/languages

- Up: [[04-public-skills-directory/roles/software-engineering/_index|software-engineering]]
- Mirror in seed registry: [[03-skills/software-engineering/languages/_index|software-engineering/languages]]

## Roles

- [[04-public-skills-directory/roles/software-engineering/languages/go-engineer|go-engineer]] (13 skills)
- [[04-public-skills-directory/roles/software-engineering/languages/python-engineer|python-engineer]] (20 skills)
- [[04-public-skills-directory/roles/software-engineering/languages/rust-engineer|rust-engineer]] (16 skills)
