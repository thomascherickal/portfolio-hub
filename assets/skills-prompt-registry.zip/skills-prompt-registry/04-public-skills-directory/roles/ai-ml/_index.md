---
type: category-index
category: ai-ml
curator: Thomas Cherickal
tags: [moc, category/ai-ml]
updated: 2026-11-15
---

# ai-ml

- Up: [[04-public-skills-directory/README|Public directory]]
- Mirror in seed registry: [[03-skills/ai-ml/_index|ai-ml]]

## Subcategories

- [[04-public-skills-directory/roles/ai-ml/applied-ai/_index|ai-ml/applied-ai]]
- [[04-public-skills-directory/roles/ai-ml/llm-systems/_index|ai-ml/llm-systems]]
