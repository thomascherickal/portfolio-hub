---
type: public-role-directory
role: rag-engineer
category: ai-ml/llm-systems
curator: Thomas Cherickal
count: 19
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/rag-engineer, category/ai-ml/llm-systems]
---

# rag-engineer: Public Skills (19)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/iterative-retrieval|iterative-retrieval]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Pattern for progressively refining context retrieval to solve the subagent context problem. Use when a subagent lacks the context it needs... |
| 2 | [[04-public-skills-directory/skills/affaan-m/knowledge-ops|knowledge-ops]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Knowledge base management, ingestion, sync, and retrieval across multiple storage layers (local files, MCP memory, vector stores, Git... |
| 3 | [[04-public-skills-directory/skills/sickn33/embedding-strategies|embedding-strategies]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Guide to selecting and optimizing embedding models for vector search applications. |
| 4 | [[04-public-skills-directory/skills/sickn33/hunt-rag-vector|hunt-rag-vector]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Hunt vector-store / embedding-layer weaknesses in RAG pipelines (OWASP LLM08 Vector and Embedding Weaknesses) |
| 5 | [[04-public-skills-directory/skills/sickn33/hybrid-search-implementation|hybrid-search-implementation]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Combine vector and keyword search for improved retrieval. Use when implementing RAG systems, building search engines, or when neither... |
| 6 | [[04-public-skills-directory/skills/sickn33/rag-engineer|rag-engineer]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Expert in building Retrieval-Augmented Generation systems. Masters embedding models, vector databases, chunking strategies, and retrieval... |
| 7 | [[04-public-skills-directory/skills/sickn33/rag-implementation|rag-implementation]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | RAG (Retrieval-Augmented Generation) implementation workflow covering embedding selection, vector database setup, chunking strategies, and... |
| 8 | [[04-public-skills-directory/skills/davila7/agents-llamaindex|agents-llamaindex]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Data framework for building LLM applications with RAG. Specializes in document ingestion (300+ connectors), indexing, and querying.... |
| 9 | [[04-public-skills-directory/skills/davila7/rag-chroma|rag-chroma]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Open-source embedding database for AI applications. Store embeddings and metadata, perform vector and full-text search, filter by metadata.... |
| 10 | [[04-public-skills-directory/skills/davila7/rag-faiss|rag-faiss]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Facebook's library for efficient similarity search and clustering of dense vectors. Supports billions of vectors, GPU acceleration, and... |
| 11 | [[04-public-skills-directory/skills/davila7/rag-pinecone|rag-pinecone]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Managed vector database for production AI applications. Fully managed, auto-scaling, with hybrid search (dense + sparse), metadata... |
| 12 | [[04-public-skills-directory/skills/davila7/rag-qdrant|rag-qdrant]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | High-performance vector similarity search engine for RAG and semantic search. Use when building production RAG systems requiring fast... |
| 13 | [[04-public-skills-directory/skills/alirezarezvani/rag-architect|rag-architect]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Design a RAG pipeline: chunk size, embedding model, vector database and retrieval quality metrics. Use whenever the user builds search over... |
| 14 | [[04-public-skills-directory/skills/orchestra-research/chroma|chroma]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Open-source embedding database for AI applications. Store embeddings and metadata, perform vector and full-text search, filter by metadata.... |
| 15 | [[04-public-skills-directory/skills/orchestra-research/faiss|faiss]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Facebook's library for efficient similarity search and clustering of dense vectors. Supports billions of vectors, GPU acceleration, and... |
| 16 | [[04-public-skills-directory/skills/orchestra-research/llamaindex|llamaindex]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Data framework for building LLM applications with RAG. Specializes in document ingestion (300+ connectors), indexing, and querying.... |
| 17 | [[04-public-skills-directory/skills/orchestra-research/pinecone|pinecone]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Managed vector database for production AI applications. Fully managed, auto-scaling, with hybrid search (dense + sparse), metadata... |
| 18 | [[04-public-skills-directory/skills/orchestra-research/qdrant-vector-search|qdrant-vector-search]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | High-performance vector similarity search engine for RAG and semantic search. Use when building production RAG systems requiring fast... |
| 19 | [[04-public-skills-directory/skills/trailofbits/vector-forge|vector-forge]] | trailofbits | [trailofbits/skills](https://github.com/trailofbits/skills) | 8,189 | CC-BY-SA-4.0 | Mutation-driven test vector generation. Finds implementations of a cryptographic algorithm or protocol, runs mutation testing to identify... |

## Links

- Up: [[04-public-skills-directory/roles/ai-ml/llm-systems/_index|ai-ml/llm-systems]]
- Seed skills: [[03-skills/ai-ml/llm-systems/rag-engineer/README|rag-engineer seed skills]]
