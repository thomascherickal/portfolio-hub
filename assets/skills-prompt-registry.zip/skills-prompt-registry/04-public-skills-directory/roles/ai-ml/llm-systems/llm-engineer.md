---
type: public-role-directory
role: llm-engineer
category: ai-ml/llm-systems
curator: Thomas Cherickal
count: 20
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/llm-engineer, category/ai-ml/llm-systems]
---

# llm-engineer: Public Skills (20)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/sickn33/huggingface-lora-space-builder|huggingface-lora-space-builder]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Build and publish a Gradio demo on Hugging Face Spaces for a user-provided LoRA. |
| 2 | [[04-public-skills-directory/skills/sickn33/llm-fine-tuning|llm-fine-tuning]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Set up infrastructure for fine-tuning LLMs with QLoRA, LoRA, and full fine-tuning using Hugging Face TRL, Axolotl, and distributed training... |
| 3 | [[04-public-skills-directory/skills/sickn33/trl-training|trl-training]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Train and fine-tune transformer language models using TRL (Transformers Reinforcement Learning). Supports SFT, DPO, GRPO, KTO, RLOO and... |
| 4 | [[04-public-skills-directory/skills/sickn33/unsloth-finetuning|unsloth-finetuning]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Fine-tune and post-train LLMs with Unsloth Core on a single consumer GPU: VRAM sizing, LoRA/QLoRA, GRPO/DPO, chat-template correctness, and... |
| 5 | [[04-public-skills-directory/skills/sickn33/vllm-server|vllm-server]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Deploy and manage vLLM for high-throughput LLM inference. Configure continuous batching, tensor parallelism, quantization, and... |
| 6 | [[04-public-skills-directory/skills/wshobson/dataset-curation|dataset-curation]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Prepare, format, and validate datasets for supervised fine-tuning and preference training. Use when converting raw data into training... |
| 7 | [[04-public-skills-directory/skills/wshobson/finetuning-method-selection|finetuning-method-selection]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Decide whether to fine-tune at all, and route to the right method (SFT, DPO/ORPO/KTO, GRPO/RLVR, continued pretraining) and base model. Use... |
| 8 | [[04-public-skills-directory/skills/wshobson/grpo-rlvr-training|grpo-rlvr-training]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Train reasoning and verifiable-task behavior with GRPO and reinforcement learning from verifiable rewards (RLVR). Use when task success is... |
| 9 | [[04-public-skills-directory/skills/wshobson/lora-qlora-recipes|lora-qlora-recipes]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Configure LoRA and QLoRA supervised fine-tuning with current best-practice hyperparameters. Use when writing or reviewing a LoRA/QLoRA... |
| 10 | [[04-public-skills-directory/skills/davila7/distributed-training-deepspeed|distributed-training-deepspeed]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Expert guidance for distributed training with DeepSpeed - ZeRO optimization stages, pipeline parallelism, FP16/BF16/FP8, 1-bit Adam, sparse... |
| 11 | [[04-public-skills-directory/skills/davila7/distributed-training-megatron-core|distributed-training-megatron-core]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Trains large language models (2B-462B parameters) using NVIDIA Megatron-Core with advanced parallelism strategies. Use when training models... |
| 12 | [[04-public-skills-directory/skills/davila7/distributed-training-pytorch-fsdp|distributed-training-pytorch-fsdp]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Expert guidance for Fully Sharded Data Parallel training with PyTorch FSDP - parameter sharding, mixed precision, CPU offloading, FSDP2 |
| 13 | [[04-public-skills-directory/skills/davila7/emerging-techniques-knowledge-distillation|emerging-techniques-knowledge-distillation]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Compress large language models using knowledge distillation from teacher to student models. Use when deploying smaller models with retained... |
| 14 | [[04-public-skills-directory/skills/davila7/emerging-techniques-long-context|emerging-techniques-long-context]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Extend context windows of transformer models using RoPE, YaRN, ALiBi, and position interpolation techniques. Use when processing long... |
| 15 | [[04-public-skills-directory/skills/orchestra-research/axolotl|axolotl]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Expert guidance for fine-tuning LLMs with Axolotl - YAML configs, 100+ models, LoRA/QLoRA, DPO/KTO/ORPO/GRPO, multimodal support |
| 16 | [[04-public-skills-directory/skills/orchestra-research/deepspeed|deepspeed]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Expert guidance for distributed training with DeepSpeed - ZeRO optimization stages, pipeline parallelism, FP16/BF16/FP8, 1-bit Adam, sparse... |
| 17 | [[04-public-skills-directory/skills/orchestra-research/distributed-llm-pretraining-torchtitan|distributed-llm-pretraining-torchtitan]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Provides PyTorch-native distributed LLM pretraining using torchtitan with 4D parallelism (FSDP2, TP, PP, CP). Use when pretraining Llama... |
| 18 | [[04-public-skills-directory/skills/orchestra-research/fine-tuning-openvla-oft|fine-tuning-openvla-oft]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Fine-tunes and evaluates OpenVLA-OFT and OpenVLA-OFT+ policies for robot action generation with continuous action heads, LoRA adaptation,... |
| 19 | [[04-public-skills-directory/skills/orchestra-research/fine-tuning-serving-openpi|fine-tuning-serving-openpi]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Fine-tune and serve Physical Intelligence OpenPI models (pi0, pi0-fast, pi0.5) using JAX or PyTorch backends for robot policy inference... |
| 20 | [[04-public-skills-directory/skills/jeffallan/fine-tuning-expert|fine-tuning-expert]] | Jeffallan | [jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills) | 12,361 | MIT | Use when fine-tuning LLMs, training custom models, or adapting foundation models for specific tasks. Invoke for configuring LoRA/QLoRA... |

## Links

- Up: [[04-public-skills-directory/roles/ai-ml/llm-systems/_index|ai-ml/llm-systems]]
- Seed skills: [[03-skills/ai-ml/llm-systems/llm-engineer/README|llm-engineer seed skills]]
