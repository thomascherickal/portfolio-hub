---
type: category-index
category: ai-ml/llm-systems
curator: Thomas Cherickal
tags: [moc, category/ai-ml/llm-systems]
updated: 2026-11-15
---

# ai-ml/llm-systems

- Up: [[04-public-skills-directory/roles/ai-ml/_index|ai-ml]]
- Mirror in seed registry: [[03-skills/ai-ml/llm-systems/_index|ai-ml/llm-systems]]

## Roles

- [[04-public-skills-directory/roles/ai-ml/llm-systems/llm-engineer|llm-engineer]] (20 skills)
- [[04-public-skills-directory/roles/ai-ml/llm-systems/local-ai-engineer|local-ai-engineer]] (20 skills)
- [[04-public-skills-directory/roles/ai-ml/llm-systems/rag-engineer|rag-engineer]] (19 skills)
