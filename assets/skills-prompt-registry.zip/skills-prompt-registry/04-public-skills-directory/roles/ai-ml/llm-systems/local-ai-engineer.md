---
type: public-role-directory
role: local-ai-engineer
category: ai-ml/llm-systems
curator: Thomas Cherickal
count: 20
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/local-ai-engineer, category/ai-ml/llm-systems]
---

# local-ai-engineer: Public Skills (20)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/foundation-models-on-device|foundation-models-on-device]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Apple FoundationModels framework for on-device LLM — text generation, guided generation with @Generable, tool calling, and snapshot... |
| 2 | [[04-public-skills-directory/skills/sickn33/local-llm-expert|local-llm-expert]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Master local LLM inference, model selection, VRAM optimization, and local deployment using Ollama, llama.cpp, vLLM, and LM Studio. Expert... |
| 3 | [[04-public-skills-directory/skills/sickn33/ollama-stack|ollama-stack]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Run local LLM workloads with Ollama, Open WebUI, and GPU-aware tuning for private development environments. |
| 4 | [[04-public-skills-directory/skills/wshobson/quantized-export|quantized-export]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Export a promoted fine-tuned model in the right deployment format — merged safetensors, LoRA-only, GGUF with imatrix, or FP8. Use after a... |
| 5 | [[04-public-skills-directory/skills/davila7/inference-serving-llama-cpp|inference-serving-llama-cpp]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Runs LLM inference on CPU, Apple Silicon, and consumer GPUs without NVIDIA hardware. Use for edge deployment, M1/M2/M3 Macs, AMD/Intel... |
| 6 | [[04-public-skills-directory/skills/davila7/multimodal-whisper|multimodal-whisper]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | OpenAI's general-purpose speech recognition model. Supports 99 languages, transcription, translation to English, and language... |
| 7 | [[04-public-skills-directory/skills/davila7/optimization-awq|optimization-awq]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Activation-aware weight quantization for 4-bit LLM compression with 3x speedup and minimal accuracy loss. Use when deploying large models... |
| 8 | [[04-public-skills-directory/skills/davila7/optimization-bitsandbytes|optimization-bitsandbytes]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Quantizes LLMs to 8-bit or 4-bit for 50-75% memory reduction with minimal accuracy loss. Use when GPU memory is limited, need to fit larger... |
| 9 | [[04-public-skills-directory/skills/davila7/optimization-gguf|optimization-gguf]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | GGUF format and llama.cpp quantization for efficient CPU/GPU inference. Use when deploying models on consumer hardware, Apple Silicon, or... |
| 10 | [[04-public-skills-directory/skills/davila7/optimization-gptq|optimization-gptq]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Post-training 4-bit quantization for LLMs with minimal accuracy loss. Use for deploying large models (70B, 405B) on consumer GPUs, when you... |
| 11 | [[04-public-skills-directory/skills/davila7/optimization-hqq|optimization-hqq]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Half-Quadratic Quantization for LLMs without calibration data. Use when quantizing models to 4/3/2-bit precision without needing... |
| 12 | [[04-public-skills-directory/skills/davila7/prompt-engineering-outlines|prompt-engineering-outlines]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Guarantee valid JSON/XML/code structure during generation, use Pydantic models for type-safe outputs, support local models (Transformers,... |
| 13 | [[04-public-skills-directory/skills/orchestra-research/awq-quantization|awq-quantization]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Activation-aware weight quantization for 4-bit LLM compression with 3x speedup and minimal accuracy loss. Use when deploying large models... |
| 14 | [[04-public-skills-directory/skills/orchestra-research/gguf-quantization|gguf-quantization]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | GGUF format and llama.cpp quantization for efficient CPU/GPU inference. Use when deploying models on consumer hardware, Apple Silicon, or... |
| 15 | [[04-public-skills-directory/skills/orchestra-research/gptq|gptq]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Post-training 4-bit quantization for LLMs with minimal accuracy loss. Use for deploying large models (70B, 405B) on consumer GPUs, when you... |
| 16 | [[04-public-skills-directory/skills/orchestra-research/hqq-quantization|hqq-quantization]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Half-Quadratic Quantization for LLMs without calibration data. Use when quantizing models to 4/3/2-bit precision without needing... |
| 17 | [[04-public-skills-directory/skills/orchestra-research/llama-cpp|llama-cpp]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Runs LLM inference on CPU, Apple Silicon, and consumer GPUs without NVIDIA hardware. Use for edge deployment, M1/M2/M3 Macs, AMD/Intel... |
| 18 | [[04-public-skills-directory/skills/orchestra-research/outlines|outlines]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Guarantee valid JSON/XML/code structure during generation, use Pydantic models for type-safe outputs, support local models (Transformers,... |
| 19 | [[04-public-skills-directory/skills/orchestra-research/quantizing-models-bitsandbytes|quantizing-models-bitsandbytes]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Quantizes LLMs to 8-bit or 4-bit for 50-75% memory reduction with minimal accuracy loss. Use when GPU memory is limited, need to fit larger... |
| 20 | [[04-public-skills-directory/skills/orchestra-research/whisper|whisper]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | OpenAI's general-purpose speech recognition model. Supports 99 languages, transcription, translation to English, and language... |

## Links

- Up: [[04-public-skills-directory/roles/ai-ml/llm-systems/_index|ai-ml/llm-systems]]
- Seed skills: [[03-skills/ai-ml/llm-systems/local-ai-engineer/README|local-ai-engineer seed skills]]
