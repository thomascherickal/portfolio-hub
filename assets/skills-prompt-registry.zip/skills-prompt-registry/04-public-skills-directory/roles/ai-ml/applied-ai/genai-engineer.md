---
type: public-role-directory
role: genai-engineer
category: ai-ml/applied-ai
curator: Thomas Cherickal
count: 20
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/genai-engineer, category/ai-ml/applied-ai]
---

# genai-engineer: Public Skills (20)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/obra/dispatching-parallel-agents|dispatching-parallel-agents]] | obra | [obra/superpowers](https://github.com/obra/superpowers) | 317,619 | MIT | Use when facing 2+ independent tasks that can be worked on without shared state or sequential dependencies |
| 2 | [[04-public-skills-directory/skills/obra/subagent-driven-development|subagent-driven-development]] | obra | [obra/superpowers](https://github.com/obra/superpowers) | 317,619 | MIT | Use when executing implementation plans with independent tasks in the current session |
| 3 | [[04-public-skills-directory/skills/affaan-m/agent-architecture-audit|agent-architecture-audit]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Full-stack diagnostic for agent and LLM applications. Audits the 12-layer agent stack for wrapper regression, memory pollution, tool... |
| 4 | [[04-public-skills-directory/skills/affaan-m/agent-eval|agent-eval]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Head-to-head comparison of coding agents (Claude Code, Aider, Codex, etc.) on custom tasks with pass rate, cost, time, and consistency... |
| 5 | [[04-public-skills-directory/skills/affaan-m/agent-harness-construction|agent-harness-construction]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Design and optimize AI agent action spaces, tool definitions, and observation formatting for higher completion rates. Use when defining or... |
| 6 | [[04-public-skills-directory/skills/affaan-m/agent-introspection-debugging|agent-introspection-debugging]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Structured self-debugging workflow for AI agent failures using capture, diagnosis, contained recovery, and introspection reports. Use when... |
| 7 | [[04-public-skills-directory/skills/affaan-m/agent-payment-x402|agent-payment-x402]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Add x402 payment execution to AI agents with per-task budgets, spending controls, and non-custodial wallets. Supports Base through... |
| 8 | [[04-public-skills-directory/skills/anthropics/mcp-builder|mcp-builder]] | anthropics | [anthropics/skills](https://github.com/anthropics/skills) | 194,585 | null | Guide for creating high-quality MCP (Model Context Protocol) servers that enable LLMs to interact with external services through... |
| 9 | [[04-public-skills-directory/skills/k-dense-ai/pi-agent|pi-agent]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Builds with and operates Pi, the minimal terminal coding harness. Use for installing Pi, configuring providers/models/settings/environment... |
| 10 | [[04-public-skills-directory/skills/sickn33/agent-creator|agent-creator]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Create custom AI subagents with proper plugin structure, persona generation, and companion routing skills. |
| 11 | [[04-public-skills-directory/skills/sickn33/agent-evals|agent-evals]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Build automated evaluation suites for AI agents using golden datasets, rubrics, and regression gates. Use when shipping agent features,... |
| 12 | [[04-public-skills-directory/skills/sickn33/agent-evaluation|agent-evaluation]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Evaluate agent behavior with versioned cases and explicit verifiers. Use when comparing agent or prompt changes, reproducing failures, or... |
| 13 | [[04-public-skills-directory/skills/sickn33/agent-evaluation-reporting|agent-evaluation-reporting]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Use when summarizing agent evaluations where autonomous, assisted, failed, timed-out, or invalid outcomes must remain distinct and... |
| 14 | [[04-public-skills-directory/skills/sickn33/agent-framework-azure-ai-py|agent-framework-azure-ai-py]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Build persistent agents on Azure AI Foundry using the Microsoft Agent Framework Python SDK. |
| 15 | [[04-public-skills-directory/skills/wshobson/protect-mcp-setup|protect-mcp-setup]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Configure Cedar policy enforcement and Ed25519 signed receipts for Claude Code tool calls. Use when setting up projects that need... |
| 16 | [[04-public-skills-directory/skills/wshobson/review-agent-setup|review-agent-setup]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Configure human-in-the-loop gating for AI agent review actions in Claude Code. Use when setting up a project where an agent may post PR... |
| 17 | [[04-public-skills-directory/skills/davila7/mcp-integration|MCP Integration]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | This skill should be used when the user asks to "add MCP server", "integrate MCP", "configure MCP in plugin", "use .mcp.json", "set up... |
| 18 | [[04-public-skills-directory/skills/davila7/agent-development|agent-development]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | This skill should be used when the user asks to "create an agent", "add an agent", "write a subagent", "agent frontmatter", "when to use... |
| 19 | [[04-public-skills-directory/skills/davila7/agent-management|agent-management]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Create, manage, and orchestrate AI agents using the AI Maestro CLI. Use when the user asks to "create agent", "list agents", "delete... |
| 20 | [[04-public-skills-directory/skills/davila7/agent-md-refactor|agent-md-refactor]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Refactor bloated AGENTS.md, CLAUDE.md, or similar agent instruction files to follow progressive disclosure principles. Splits monolithic... |

## Links

- Up: [[04-public-skills-directory/roles/ai-ml/applied-ai/_index|ai-ml/applied-ai]]
- Seed skills: [[03-skills/ai-ml/applied-ai/genai-engineer/README|genai-engineer seed skills]]
