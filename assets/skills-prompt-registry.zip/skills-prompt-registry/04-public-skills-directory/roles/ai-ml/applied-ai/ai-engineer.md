---
type: public-role-directory
role: ai-engineer
category: ai-ml/applied-ai
curator: Thomas Cherickal
count: 20
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/ai-engineer, category/ai-ml/applied-ai]
---

# ai-engineer: Public Skills (20)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/agent-eval|agent-eval]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Head-to-head comparison of coding agents (Claude Code, Aider, Codex, etc.) on custom tasks with pass rate, cost, time, and consistency... |
| 2 | [[04-public-skills-directory/skills/affaan-m/agent-self-evaluation|agent-self-evaluation]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Use after completing any non-trivial task. The agent self-rates its output on 5 axes — accuracy, completeness, clarity, actionability,... |
| 3 | [[04-public-skills-directory/skills/affaan-m/eval-harness|eval-harness]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Eval-driven development (EDD) framework for AI coding sessions — define capability and regression evals before coding, grade with... |
| 4 | [[04-public-skills-directory/skills/affaan-m/healthcare-eval-harness|healthcare-eval-harness]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Patient safety evaluation harness for healthcare application deployments. Automated test suites for CDSS accuracy, PHI exposure, clinical... |
| 5 | [[04-public-skills-directory/skills/affaan-m/scientific-thinking-scholar-evaluation|scientific-thinking-scholar-evaluation]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Structured scholarly-work evaluation for papers, proposals, literature reviews, methods sections, evidence quality, citation support, and... |
| 6 | [[04-public-skills-directory/skills/anthropics/claude-api|claude-api]] | anthropics | [anthropics/skills](https://github.com/anthropics/skills) | 194,585 | null | - Reference for the Claude API / Anthropic SDK — model ids, pricing, params, streaming, tool use, MCP, agents, caching, token counting,... |
| 7 | [[04-public-skills-directory/skills/anthropics/skill-creator|skill-creator]] | anthropics | [anthropics/skills](https://github.com/anthropics/skills) | 194,585 | null | Create new skills, modify and improve existing skills, and measure skill performance. Use when users want to create a skill from scratch,... |
| 8 | [[04-public-skills-directory/skills/k-dense-ai/scholar-evaluation|scholar-evaluation]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Provides qualitative-first, evidence-traceable developmental review of scholarly works and audit low-stakes research-assessment rubrics... |
| 9 | [[04-public-skills-directory/skills/sickn33/advanced-evaluation|advanced-evaluation]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Design LLM-as-judge rubrics, direct scores and pairwise comparisons. Use for judge models, evals, position bias and calibration against... |
| 10 | [[04-public-skills-directory/skills/sickn33/agent-evals|agent-evals]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Build automated evaluation suites for AI agents using golden datasets, rubrics, and regression gates. Use when shipping agent features,... |
| 11 | [[04-public-skills-directory/skills/sickn33/agent-evaluation|agent-evaluation]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Evaluate agent behavior with versioned cases and explicit verifiers. Use when comparing agent or prompt changes, reproducing failures, or... |
| 12 | [[04-public-skills-directory/skills/sickn33/agent-evaluation-reporting|agent-evaluation-reporting]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Use when summarizing agent evaluations where autonomous, assisted, failed, timed-out, or invalid outcomes must remain distinct and... |
| 13 | [[04-public-skills-directory/skills/sickn33/agent-observability|agent-observability]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Instrument AI agents with tracing, token metrics, latency, and cost visibility. Use for reliability and debugging. |
| 14 | [[04-public-skills-directory/skills/wshobson/eval-harness-first|eval-harness-first]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Build the evaluation harness that gates every fine-tuning run — golden sets, per-failure-mode graders, judge calibration, and base-model... |
| 15 | [[04-public-skills-directory/skills/wshobson/evaluation-methodology|evaluation-methodology]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | PluginEval quality methodology, covering dimensions, rubrics, and scoring formulas. Use this skill when understanding how plugin quality is... |
| 16 | [[04-public-skills-directory/skills/davila7/eval-genius|eval-genius]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | - Decide whether an AI/LLM/agent/retrieval system needs an eval, where it fits in the dev process, which one to run, and how to read the... |
| 17 | [[04-public-skills-directory/skills/davila7/evaluation-bigcode-evaluation-harness|evaluation-bigcode-evaluation-harness]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Evaluates code generation models across HumanEval, MBPP, MultiPL-E, and 15+ benchmarks with pass@k metrics. Use when benchmarking code... |
| 18 | [[04-public-skills-directory/skills/davila7/evaluation-lm-evaluation-harness|evaluation-lm-evaluation-harness]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Evaluates LLMs across 60+ academic benchmarks (MMLU, HumanEval, GSM8K, TruthfulQA, HellaSwag). Use when benchmarking model quality,... |
| 19 | [[04-public-skills-directory/skills/davila7/evaluation-nemo-evaluator|evaluation-nemo-evaluator]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Evaluates LLMs across 100+ benchmarks from 18+ harnesses (MMLU, HumanEval, GSM8K, safety, VLM) with multi-backend execution. Use when... |
| 20 | [[04-public-skills-directory/skills/davila7/prompt-engineering-dspy|prompt-engineering-dspy]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Build complex AI systems with declarative programming, optimize prompts automatically, create modular RAG systems and agents with DSPy -... |

## Links

- Up: [[04-public-skills-directory/roles/ai-ml/applied-ai/_index|ai-ml/applied-ai]]
- Seed skills: [[03-skills/ai-ml/applied-ai/ai-engineer/README|ai-engineer seed skills]]
