---
type: category-index
category: ai-ml/applied-ai
curator: Thomas Cherickal
tags: [moc, category/ai-ml/applied-ai]
updated: 2026-11-15
---

# ai-ml/applied-ai

- Up: [[04-public-skills-directory/roles/ai-ml/_index|ai-ml]]
- Mirror in seed registry: [[03-skills/ai-ml/applied-ai/_index|ai-ml/applied-ai]]

## Roles

- [[04-public-skills-directory/roles/ai-ml/applied-ai/ai-engineer|ai-engineer]] (20 skills)
- [[04-public-skills-directory/roles/ai-ml/applied-ai/genai-engineer|genai-engineer]] (20 skills)
