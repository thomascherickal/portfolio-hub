---
type: category-index
category: web3
curator: Thomas Cherickal
tags: [moc, category/web3]
updated: 2026-11-15
---

# web3

- Up: [[04-public-skills-directory/README|Public directory]]
- Mirror in seed registry: [[03-skills/web3/_index|web3]]

## Roles

- [[04-public-skills-directory/roles/web3/blockchain-defi-engineer|blockchain-defi-engineer]] (20 skills)
