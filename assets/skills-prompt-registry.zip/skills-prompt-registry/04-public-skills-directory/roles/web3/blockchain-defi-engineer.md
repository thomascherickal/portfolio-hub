---
type: public-role-directory
role: blockchain-defi-engineer
category: web3
curator: Thomas Cherickal
count: 20
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/blockchain-defi-engineer, category/web3]
---

# blockchain-defi-engineer: Public Skills (20)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/agent-payment-x402|agent-payment-x402]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Add x402 payment execution to AI agents with per-task budgets, spending controls, and non-custodial wallets. Supports Base through... |
| 2 | [[04-public-skills-directory/skills/affaan-m/defi-amm-security|defi-amm-security]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Security checklist for Solidity AMM contracts, liquidity pools, and swap flows. Covers reentrancy, CEI ordering, donation or inflation... |
| 3 | [[04-public-skills-directory/skills/affaan-m/evm-token-decimals|evm-token-decimals]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Prevent silent decimal mismatch bugs across EVM chains. Covers runtime decimal lookup, chain-aware caching, bridged-token precision drift,... |
| 4 | [[04-public-skills-directory/skills/sickn33/blockchain-developer|blockchain-developer]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Build production-ready Web3 applications, smart contracts, and decentralized systems. Implements DeFi protocols, NFT platforms, DAOs, and... |
| 5 | [[04-public-skills-directory/skills/sickn33/defi-protocol-templates|defi-protocol-templates]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Implement DeFi protocols with educational templates for staking, AMMs, governance, and lending systems. Use when building decentralized... |
| 6 | [[04-public-skills-directory/skills/sickn33/defi-yield-strategy-allocator|defi-yield-strategy-allocator]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Multi-vault automated yield strategy allocation register: APY benchmarks, impermanent loss risk tiers, and rebalancing triggers. |
| 7 | [[04-public-skills-directory/skills/sickn33/smart-contract-formal-verification|smart-contract-formal-verification]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Foundry and Soroban formal invariant verification register: state transition rules, boundary invariant properties, and symbolic execution... |
| 8 | [[04-public-skills-directory/skills/sickn33/smart-contract-upgrade-governance|smart-contract-upgrade-governance]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Soroban WASM upgrade governance register: executable bytecode hash, timelocked migration delays, and multi-sig authorization quorum. |
| 9 | [[04-public-skills-directory/skills/trailofbits/algorand-vulnerability-scanner|algorand-vulnerability-scanner]] | trailofbits | [trailofbits/skills](https://github.com/trailofbits/skills) | 8,189 | CC-BY-SA-4.0 | Scans Algorand smart contracts for 11 common vulnerabilities including rekeying attacks, unchecked transaction fees, missing field... |
| 10 | [[04-public-skills-directory/skills/trailofbits/cairo-vulnerability-scanner|cairo-vulnerability-scanner]] | trailofbits | [trailofbits/skills](https://github.com/trailofbits/skills) | 8,189 | CC-BY-SA-4.0 | Scans Cairo/StarkNet smart contracts for 6 critical vulnerabilities including felt252 arithmetic overflow, L1-L2 messaging issues, address... |
| 11 | [[04-public-skills-directory/skills/trailofbits/cosmos-vulnerability-scanner|cosmos-vulnerability-scanner]] | trailofbits | [trailofbits/skills](https://github.com/trailofbits/skills) | 8,189 | CC-BY-SA-4.0 | Scans Cosmos SDK blockchain modules and CosmWasm contracts for consensus-critical vulnerabilities — chain halts, fund loss, state... |
| 12 | [[04-public-skills-directory/skills/trailofbits/solana-vulnerability-scanner|solana-vulnerability-scanner]] | trailofbits | [trailofbits/skills](https://github.com/trailofbits/skills) | 8,189 | CC-BY-SA-4.0 | Scans Solana programs for 6 critical vulnerabilities including arbitrary CPI, improper PDA validation, missing signer/ownership checks, and... |
| 13 | [[04-public-skills-directory/skills/trailofbits/substrate-vulnerability-scanner|substrate-vulnerability-scanner]] | trailofbits | [trailofbits/skills](https://github.com/trailofbits/skills) | 8,189 | CC-BY-SA-4.0 | Scans Substrate/Polkadot pallets for 7 critical vulnerabilities including arithmetic overflow, panic DoS, incorrect weights, and bad origin... |
| 14 | [[04-public-skills-directory/skills/awarexone/web3-ai-tools|web3-ai-tools]] | awarexone | [awarexone/web3-bug-bounty-hunting-ai-skills](https://github.com/awarexone/web3-bug-bounty-hunting-ai-skills) | 186 | MIT | AI-powered tools for Web3 bug bounty automation. Use when you want to automate recon, run autonomous audits, or use AI agents for... |
| 15 | [[04-public-skills-directory/skills/awarexone/web3-bug-classes|web3-bug-classes]] | awarexone | [awarexone/web3-bug-bounty-hunting-ai-skills](https://github.com/awarexone/web3-bug-bounty-hunting-ai-skills) | 186 | MIT | Complete reference for all 10 DeFi smart contract bug classes. Use this when hunting for specific vulnerability types, need attack patterns... |
| 16 | [[04-public-skills-directory/skills/awarexone/web3-case-study-role-misconfig|web3-case-study-role-misconfig]] | awarexone | [awarexone/web3-bug-bounty-hunting-ai-skills](https://github.com/awarexone/web3-bug-bounty-hunting-ai-skills) | 186 | MIT | Case study - role misconfiguration bug class applied to a yield aggregator protocol. Use as a template for applying all 10 bug classes to a... |
| 17 | [[04-public-skills-directory/skills/awarexone/web3-grep-arsenal|web3-grep-arsenal]] | awarexone | [awarexone/web3-bug-bounty-hunting-ai-skills](https://github.com/awarexone/web3-bug-bounty-hunting-ai-skills) | 186 | MIT | Master grep command arsenal for Web3 smart contract auditing. Use when starting a new protocol scan, before deep code review, or when... |
| 18 | [[04-public-skills-directory/skills/awarexone/web3-hunt-foundation|web3-hunt-foundation]] | awarexone | [awarexone/web3-bug-bounty-hunting-ai-skills](https://github.com/awarexone/web3-bug-bounty-hunting-ai-skills) | 186 | MIT | Hunter mindset, recon setup, and target scoring for Web3 bug bounty. Use at the START of any new protocol hunt - scoring targets, setting... |
| 19 | [[04-public-skills-directory/skills/kadenzipfel/scv-scan|scv-scan]] | kadenzipfel | [kadenzipfel/scv-scan](https://github.com/kadenzipfel/scv-scan) | 110 | null | Systematically audit Solidity smart contract codebases for security vulnerabilities using a 4-phase approach - load a vulnerability... |
| 20 | [[04-public-skills-directory/skills/dfinity/canister-security|canister-security]] | dfinity | [dfinity/icskills](https://github.com/dfinity/icskills) | 40 | Apache-2.0 | IC-specific security patterns for canister development in Motoko and Rust. Covers access control, anonymous principal rejection, reentrancy... |

## Links

- Up: [[04-public-skills-directory/roles/web3/_index|web3]]
- Seed skills: [[03-skills/web3/blockchain-defi-engineer/README|blockchain-defi-engineer seed skills]]
