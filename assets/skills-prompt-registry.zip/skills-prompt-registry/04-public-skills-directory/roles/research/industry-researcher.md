---
type: public-role-directory
role: industry-researcher
category: research
curator: Thomas Cherickal
count: 18
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/industry-researcher, category/research]
---

# industry-researcher: Public Skills (18)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/benchmark-methodology|benchmark-methodology]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Score a scoped competitor set into comparable profile cards: nine weighted dimensions (positioning, voice, visual craft, offer packaging,... |
| 2 | [[04-public-skills-directory/skills/affaan-m/competitive-platform-analysis|competitive-platform-analysis]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Use when scoping a competitive landscape — identifying, categorising, and score-filtering a competitor set before any benchmarking begins.... |
| 3 | [[04-public-skills-directory/skills/affaan-m/competitive-report-structure|competitive-report-structure]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Assemble scored competitor profile cards (from benchmark-methodology) into a decision-grade competitive report with landscape map,... |
| 4 | [[04-public-skills-directory/skills/affaan-m/deep-research|deep-research]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Produce cited research reports from multiple web sources using firecrawl and exa MCP tools — plan sub-questions, search and deep-read... |
| 5 | [[04-public-skills-directory/skills/affaan-m/exa-search|exa-search]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Neural search via Exa MCP for web, code, and company research. Use when the user needs web search, code examples, company intel, people... |
| 6 | [[04-public-skills-directory/skills/k-dense-ai/market-research-reports|market-research-reports]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Builds evidence-traceable market research reports and assumption-driven market sizing or forecast scenarios. Use for market definition,... |
| 7 | [[04-public-skills-directory/skills/k-dense-ai/parallel-web|parallel-web]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Uses Parallel CLI for web search, URL extraction, deep research, structured data enrichment, entity discovery, and recurring web... |
| 8 | [[04-public-skills-directory/skills/k-dense-ai/research-lookup|research-lookup]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Compiles current scholarly evidence for a scientific manuscript or research brief when the user explicitly asks to gather literature,... |
| 9 | [[04-public-skills-directory/skills/sickn33/apify-competitor-intelligence|apify-competitor-intelligence]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Analyze competitor strategies, content, pricing, ads, and market positioning across Google Maps, Booking.com, Facebook, Instagram, YouTube,... |
| 10 | [[04-public-skills-directory/skills/sickn33/apify-market-research|apify-market-research]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Analyze market conditions, geographic opportunities, pricing, consumer behavior, and product validation across Google Maps, Facebook,... |
| 11 | [[04-public-skills-directory/skills/sickn33/apify-trend-analysis|apify-trend-analysis]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Discover and track emerging trends across Google Trends, Instagram, Facebook, YouTube, and TikTok to inform content strategy. |
| 12 | [[04-public-skills-directory/skills/sickn33/competitive-landscape|competitive-landscape]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Comprehensive frameworks for analyzing competition, identifying differentiation opportunities, and developing winning market positioning... |
| 13 | [[04-public-skills-directory/skills/sickn33/competitor-alternatives|competitor-alternatives]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | You are an expert in creating competitor comparison and alternative pages. Your goal is to build pages that rank for competitive search... |
| 14 | [[04-public-skills-directory/skills/wshobson/social-evidence-research|social-evidence-research]] | wshobson | [wshobson/agents](https://github.com/wshobson/agents) | 42,512 | MIT | Research public discussion on social platforms and keep every report claim tied to the source material that supports it. Use when... |
| 15 | [[04-public-skills-directory/skills/davila7/content-research-writer|content-research-writer]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Assists in writing high-quality content by conducting research, adding citations, improving hooks, iterating on outlines, and providing... |
| 16 | [[04-public-skills-directory/skills/davila7/deep-research-notebooklm|deep-research-notebooklm]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Deep research skill powered by NotebookLM MCP. Conducts structured multi-source research (market analysis, competitive intel, trend... |
| 17 | [[04-public-skills-directory/skills/alirezarezvani/competitive-intel|competitive-intel]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Use for competitor analysis, battlecards, win/loss review or positioning against alternatives. Builds a tracking system that feeds... |
| 18 | [[04-public-skills-directory/skills/wanshuiyin/firecrawl-search|firecrawl-search]] | wanshuiyin | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) | 19,200 | MIT | Web search and page scraping via Firecrawl, returning full-page markdown. Use when user says "firecrawl search", "firecrawl scrape" or... |

## Links

- Up: [[04-public-skills-directory/roles/research/_index|research]]
- Seed skills: [[03-skills/research/industry-researcher/README|industry-researcher seed skills]]
