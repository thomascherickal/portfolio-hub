---
type: category-index
category: research
curator: Thomas Cherickal
tags: [moc, category/research]
updated: 2026-11-15
---

# research

- Up: [[04-public-skills-directory/README|Public directory]]
- Mirror in seed registry: [[03-skills/research/_index|research]]

## Roles

- [[04-public-skills-directory/roles/research/industry-researcher|industry-researcher]] (18 skills)
- [[04-public-skills-directory/roles/research/research-scientist|research-scientist]] (19 skills)
