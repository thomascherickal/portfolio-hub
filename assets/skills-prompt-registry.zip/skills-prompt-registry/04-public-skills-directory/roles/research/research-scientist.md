---
type: public-role-directory
role: research-scientist
category: research
curator: Thomas Cherickal
count: 19
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/research-scientist, category/research]
---

# research-scientist: Public Skills (19)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/scientific-thinking-literature-review|scientific-thinking-literature-review]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Systematic literature-review workflow for academic, biomedical, technical, and scientific topics, including search planning, source... |
| 2 | [[04-public-skills-directory/skills/affaan-m/scientific-thinking-scholar-evaluation|scientific-thinking-scholar-evaluation]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Structured scholarly-work evaluation for papers, proposals, literature reviews, methods sections, evidence quality, citation support, and... |
| 3 | [[04-public-skills-directory/skills/k-dense-ai/citation-management|citation-management]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Comprehensive citation management for academic research. Search OpenAlex, PubMed, and Google Scholar for papers, extract accurate metadata,... |
| 4 | [[04-public-skills-directory/skills/k-dense-ai/experimental-design|experimental-design]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Designs experiments and studies BEFORE data is collected — choosing a design, randomizing, blocking, and laying out treatment combinations... |
| 5 | [[04-public-skills-directory/skills/k-dense-ai/hypothesis-generation|hypothesis-generation]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Formulates evidence-bounded scientific questions, candidate hypotheses, rival explanations, causal or associational claims, discriminating... |
| 6 | [[04-public-skills-directory/skills/k-dense-ai/latex-posters|latex-posters]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Creates research posters in LaTeX using beamerposter, tikzposter, or baposter. Use for conference posters, academic presentations,... |
| 7 | [[04-public-skills-directory/skills/k-dense-ai/literature-review|literature-review]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Conducts systematic, scoping, and narrative literature reviews using PubMed, arXiv, bioRxiv, Semantic Scholar, and other appropriate... |
| 8 | [[04-public-skills-directory/skills/imbad0202/academic-paper|academic-paper]] | Imbad0202 | [Imbad0202/academic-research-skills](https://github.com/Imbad0202/academic-research-skills) | 56,891 | NOASSERTION | 12-agent academic paper writing pipeline. 11 modes... |
| 9 | [[04-public-skills-directory/skills/imbad0202/academic-paper-reviewer|academic-paper-reviewer]] | Imbad0202 | [Imbad0202/academic-research-skills](https://github.com/Imbad0202/academic-research-skills) | 56,891 | NOASSERTION | Multi-perspective academic paper review with dynamic reviewer personas. Runs a 5-seat, role-separated review panel (Journal-Fit Reviewer +... |
| 10 | [[04-public-skills-directory/skills/imbad0202/academic-pipeline|academic-pipeline]] | Imbad0202 | [Imbad0202/academic-research-skills](https://github.com/Imbad0202/academic-research-skills) | 56,891 | NOASSERTION | Orchestrator for the full academic research pipeline: research -> write -> integrity check -> review -> revise -> re-review -> re-revise ->... |
| 11 | [[04-public-skills-directory/skills/davila7/ml-paper-writing|ml-paper-writing]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Write publication-ready ML/AI papers for NeurIPS, ICML, ICLR, ACL, AAAI, COLM. Use when drafting papers from research repos, structuring... |
| 12 | [[04-public-skills-directory/skills/davila7/openalex-database|openalex-database]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Query and analyze scholarly literature using the OpenAlex database. This skill should be used when searching for academic papers, analyzing... |
| 13 | [[04-public-skills-directory/skills/wanshuiyin/ablation-planner|ablation-planner]] | wanshuiyin | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) | 19,200 | MIT | Use when main results pass result-to-claim (`claim_supported = yes` or `partial`) and ablation studies are needed for paper submission. A... |
| 14 | [[04-public-skills-directory/skills/wanshuiyin/arxiv|arxiv]] | wanshuiyin | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) | 19,200 | MIT | Search, download, and summarize academic papers from arXiv. Use when user says \"search arxiv\", \"download paper\", \"fetch arxiv\",... |
| 15 | [[04-public-skills-directory/skills/wanshuiyin/experiment-plan|experiment-plan]] | wanshuiyin | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) | 19,200 | MIT | Turn a refined research proposal or method idea into a detailed, claim-driven experiment roadmap. Use after `research-refine`, or when the... |
| 16 | [[04-public-skills-directory/skills/wanshuiyin/novelty-check|novelty-check]] | wanshuiyin | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) | 19,200 | MIT | Verify research idea novelty against recent literature. Use when user says \"\u67e5\u65b0\", \"novelty check\",... |
| 17 | [[04-public-skills-directory/skills/wanshuiyin/openalex|openalex]] | wanshuiyin | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) | 19,200 | MIT | Search academic papers via OpenAlex API for open citation data, institutional affiliations, and funding information. Use when user says... |
| 18 | [[04-public-skills-directory/skills/orchestra-research/academic-plotting|academic-plotting]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Generates publication-quality figures for ML papers from research context. Given a paper section or description, extracts system components... |
| 19 | [[04-public-skills-directory/skills/orchestra-research/systems-paper-writing|systems-paper-writing]] | Orchestra-Research | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 14,542 | MIT | Comprehensive guide for writing systems papers targeting OSDI, SOSP, ASPLOS, NSDI, and EuroSys. Provides paragraph-level structural... |

## Links

- Up: [[04-public-skills-directory/roles/research/_index|research]]
- Seed skills: [[03-skills/research/research-scientist/README|research-scientist seed skills]]
