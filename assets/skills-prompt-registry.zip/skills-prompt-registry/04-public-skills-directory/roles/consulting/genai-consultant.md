---
type: public-role-directory
role: genai-consultant
category: consulting
curator: Thomas Cherickal
count: 13
sort: repo_stars_desc
updated: 2026-11-15
tags: [moc, public-skill, role/genai-consultant, category/consulting]
---

# genai-consultant: Public Skills (13)

Sorted by GitHub stars of the source repo, highest first.

| # | Skill | Owner | Repo | Stars | License | What it does |
|---|---|---|---|---|---|---|
| 1 | [[04-public-skills-directory/skills/affaan-m/enterprise-agent-ops|enterprise-agent-ops]] | affaan-m | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 302,998 | MIT | Operational controls for long-lived or cloud-hosted agent systems — runtime lifecycle (start, pause, stop, restart), observability (logs,... |
| 2 | [[04-public-skills-directory/skills/k-dense-ai/iso-standards-readiness|iso-standards-readiness]] | K-Dense-AI | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 57,202 | MIT | Prepares and structurally reviews readiness evidence for ISO management-system and laboratory-competence standards - ISO 13485 medical... |
| 3 | [[04-public-skills-directory/skills/sickn33/00-andruia-consultant|00-andruia-consultant]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Usar al iniciar o mejorar un proyecto de IA: diagnostica código y restricciones, propone skills existentes y redacta tareas y un plan de... |
| 4 | [[04-public-skills-directory/skills/sickn33/change-management|change-management]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Implement change management processes. Configure CAB reviews, change windows, and rollback procedures. Use when managing production changes. |
| 5 | [[04-public-skills-directory/skills/sickn33/data-storytelling|data-storytelling]] | sickn33 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 49,710 | MIT | Transform raw data into compelling narratives that drive decisions and inspire action. |
| 6 | [[04-public-skills-directory/skills/davila7/ceo-advisor|ceo-advisor]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Executive leadership guidance for strategic decision-making, organizational development, and stakeholder management. Includes strategy... |
| 7 | [[04-public-skills-directory/skills/davila7/cto-advisor|cto-advisor]] | davila7 | [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) | 33,617 | MIT | Technical leadership guidance for engineering teams, architecture decisions, and technology strategy. Includes tech debt analyzer, team... |
| 8 | [[04-public-skills-directory/skills/alirezarezvani/ai-act-readiness|ai-act-readiness]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | EU AI Act readiness: risk tier, duties, deadlines. Load whenever AI ships in the EU or the user asks if the Act applies. |
| 9 | [[04-public-skills-directory/skills/alirezarezvani/aims-audit|aims-audit]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | ISO 42001 AI readiness check. Use before a stage 1 or internal audit, or /compliance-os:aims-audit. |
| 10 | [[04-public-skills-directory/skills/alirezarezvani/business-investment-advisor|business-investment-advisor]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Use when deciding whether a capital expense is worth it (equipment, property, an acquisition, hiring, technology), or for ROI, IRR, NPV,... |
| 11 | [[04-public-skills-directory/skills/alirezarezvani/cfo-advisor|cfo-advisor]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Startup finance: runway and burn, unit economics (LTV, CAC, payback), fundraising and dilution. Load whenever the user asks how long the... |
| 12 | [[04-public-skills-directory/skills/alirezarezvani/chief-ai-officer-advisor|chief-ai-officer-advisor]] | alirezarezvani | [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29,806 | MIT | Use for AI strategy decisions: API vs fine-tune vs build, EU AI Act or US state risk classification, when self-hosting pays off, or AI... |
| 13 | [[04-public-skills-directory/skills/trailofbits/guidelines-advisor|guidelines-advisor]] | trailofbits | [trailofbits/skills](https://github.com/trailofbits/skills) | 8,189 | CC-BY-SA-4.0 | Smart contract development advisor based on Trail of Bits' best practices. Analyzes codebase to generate documentation/specifications,... |

## Links

- Up: [[04-public-skills-directory/roles/consulting/_index|consulting]]
- Seed skills: [[03-skills/consulting/genai-consultant/README|genai-consultant seed skills]]
