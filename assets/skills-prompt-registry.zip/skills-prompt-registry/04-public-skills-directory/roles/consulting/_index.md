---
type: category-index
category: consulting
curator: Thomas Cherickal
tags: [moc, category/consulting]
updated: 2026-11-15
---

# consulting

- Up: [[04-public-skills-directory/README|Public directory]]
- Mirror in seed registry: [[03-skills/consulting/_index|consulting]]

## Roles

- [[04-public-skills-directory/roles/consulting/genai-consultant|genai-consultant]] (13 skills)
