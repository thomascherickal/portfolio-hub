---
type: source-repo
repo: trailofbits/skills
owner: trailofbits
curator: Thomas Cherickal
stars: 8189
license: CC-BY-SA-4.0
last_push: 2026-11-12
url: https://github.com/trailofbits/skills
tags: [source, owner/trailofbits]
---

# trailofbits/skills

[https://github.com/trailofbits/skills](https://github.com/trailofbits/skills) - 8,189 stars, license CC-BY-SA-4.0, last push 2026-11-12.

## Skills Listed Here

- [[04-public-skills-directory/skills/trailofbits/algorand-vulnerability-scanner|algorand-vulnerability-scanner]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/trailofbits/cairo-vulnerability-scanner|cairo-vulnerability-scanner]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/trailofbits/cargo-fuzz|cargo-fuzz]]: rust-engineer
- [[04-public-skills-directory/skills/trailofbits/cosmos-vulnerability-scanner|cosmos-vulnerability-scanner]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/trailofbits/guidelines-advisor|guidelines-advisor]]: genai-consultant
- [[04-public-skills-directory/skills/trailofbits/rust-review|rust-review]]: rust-engineer
- [[04-public-skills-directory/skills/trailofbits/ruzzy|ruzzy]]: rust-engineer
- [[04-public-skills-directory/skills/trailofbits/solana-vulnerability-scanner|solana-vulnerability-scanner]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/trailofbits/substrate-vulnerability-scanner|substrate-vulnerability-scanner]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/trailofbits/vector-forge|vector-forge]]: rag-engineer
- [[04-public-skills-directory/skills/trailofbits/writing-lean-proofs|writing-lean-proofs]]: quantum-computing-researcher

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
