---
type: source-repo
repo: anthropics/skills
owner: anthropics
curator: Thomas Cherickal
stars: 194585
license: null
last_push: 2026-11-14
url: https://github.com/anthropics/skills
tags: [source, owner/anthropics]
---

# anthropics/skills

[https://github.com/anthropics/skills](https://github.com/anthropics/skills) - 194,585 stars, license null, last push 2026-11-14.

## Skills Listed Here

- [[04-public-skills-directory/skills/anthropics/brand-guidelines|brand-guidelines]]: web-designer
- [[04-public-skills-directory/skills/anthropics/canvas-design|canvas-design]]: web-designer
- [[04-public-skills-directory/skills/anthropics/claude-api|claude-api]]: ai-engineer
- [[04-public-skills-directory/skills/anthropics/doc-coauthoring|doc-coauthoring]]: technical-writer
- [[04-public-skills-directory/skills/anthropics/frontend-design|frontend-design]]: frontend-engineer, web-designer
- [[04-public-skills-directory/skills/anthropics/mcp-builder|mcp-builder]]: genai-engineer
- [[04-public-skills-directory/skills/anthropics/skill-creator|skill-creator]]: ai-engineer
- [[04-public-skills-directory/skills/anthropics/theme-factory|theme-factory]]: web-designer
- [[04-public-skills-directory/skills/anthropics/web-artifacts-builder|web-artifacts-builder]]: fullstack-engineer
- [[04-public-skills-directory/skills/anthropics/webapp-testing|webapp-testing]]: frontend-engineer, pwa-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
