---
type: source-repo
repo: Imbad0202/academic-research-skills
owner: Imbad0202
curator: Thomas Cherickal
stars: 56891
license: NOASSERTION
last_push: 2026-11-14
url: https://github.com/Imbad0202/academic-research-skills
tags: [source, owner/imbad0202]
---

# Imbad0202/academic-research-skills

[https://github.com/Imbad0202/academic-research-skills](https://github.com/Imbad0202/academic-research-skills) - 56,891 stars, license NOASSERTION, last push 2026-11-14.

## Skills Listed Here

- [[04-public-skills-directory/skills/imbad0202/academic-paper|academic-paper]]: research-scientist
- [[04-public-skills-directory/skills/imbad0202/academic-paper-reviewer|academic-paper-reviewer]]: research-scientist
- [[04-public-skills-directory/skills/imbad0202/academic-pipeline|academic-pipeline]]: research-scientist

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
