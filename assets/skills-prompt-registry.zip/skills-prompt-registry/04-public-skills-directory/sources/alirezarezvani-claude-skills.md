---
type: source-repo
repo: alirezarezvani/claude-skills
owner: alirezarezvani
curator: Thomas Cherickal
stars: 29806
license: MIT
last_push: 2026-11-12
url: https://github.com/alirezarezvani/claude-skills
tags: [source, owner/alirezarezvani]
---

# alirezarezvani/claude-skills

[https://github.com/alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) - 29,806 stars, license MIT, last push 2026-11-12.

## Skills Listed Here

- [[04-public-skills-directory/skills/alirezarezvani/a11y-audit|a11y-audit]]: frontend-engineer
- [[04-public-skills-directory/skills/alirezarezvani/ai-act-readiness|ai-act-readiness]]: genai-consultant
- [[04-public-skills-directory/skills/alirezarezvani/aims-audit|aims-audit]]: genai-consultant
- [[04-public-skills-directory/skills/alirezarezvani/api-design-reviewer|api-design-reviewer]]: backend-engineer
- [[04-public-skills-directory/skills/alirezarezvani/business-investment-advisor|business-investment-advisor]]: genai-consultant
- [[04-public-skills-directory/skills/alirezarezvani/cfo-advisor|cfo-advisor]]: genai-consultant
- [[04-public-skills-directory/skills/alirezarezvani/changelog|changelog]]: technical-writer
- [[04-public-skills-directory/skills/alirezarezvani/chief-ai-officer-advisor|chief-ai-officer-advisor]]: genai-consultant
- [[04-public-skills-directory/skills/alirezarezvani/competitive-intel|competitive-intel]]: industry-researcher
- [[04-public-skills-directory/skills/alirezarezvani/cs-backend-engineer|cs-backend-engineer]]: backend-engineer
- [[04-public-skills-directory/skills/alirezarezvani/cs-backend-review|cs-backend-review]]: backend-engineer
- [[04-public-skills-directory/skills/alirezarezvani/cs-fullstack-engineer|cs-fullstack-engineer]]: fullstack-engineer
- [[04-public-skills-directory/skills/alirezarezvani/cs-fullstack-review|cs-fullstack-review]]: fullstack-engineer
- [[04-public-skills-directory/skills/alirezarezvani/markdown-html-orchestrator|markdown-html-orchestrator]]: pwa-engineer
- [[04-public-skills-directory/skills/alirezarezvani/rag-architect|rag-architect]]: rag-engineer
- [[04-public-skills-directory/skills/alirezarezvani/saas-health|saas-health]]: fullstack-engineer
- [[04-public-skills-directory/skills/alirezarezvani/saas-metrics-coach|saas-metrics-coach]]: fullstack-engineer
- [[04-public-skills-directory/skills/alirezarezvani/saas-scaffolder|saas-scaffolder]]: fullstack-engineer
- [[04-public-skills-directory/skills/alirezarezvani/stripe-integration-expert|stripe-integration-expert]]: fullstack-engineer
- [[04-public-skills-directory/skills/alirezarezvani/tdd-guide|tdd-guide]]: software-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
