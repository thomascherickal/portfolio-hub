---
type: source-repo
repo: obra/superpowers
owner: obra
curator: Thomas Cherickal
stars: 317619
license: MIT
last_push: 2026-11-03
url: https://github.com/obra/superpowers
tags: [source, owner/obra]
---

# obra/superpowers

[https://github.com/obra/superpowers](https://github.com/obra/superpowers) - 317,619 stars, license MIT, last push 2026-11-03.

## Skills Listed Here

- [[04-public-skills-directory/skills/obra/brainstorming|brainstorming]]: software-engineer
- [[04-public-skills-directory/skills/obra/dispatching-parallel-agents|dispatching-parallel-agents]]: genai-engineer
- [[04-public-skills-directory/skills/obra/executing-plans|executing-plans]]: software-engineer
- [[04-public-skills-directory/skills/obra/finishing-a-development-branch|finishing-a-development-branch]]: software-engineer
- [[04-public-skills-directory/skills/obra/receiving-code-review|receiving-code-review]]: software-engineer
- [[04-public-skills-directory/skills/obra/requesting-code-review|requesting-code-review]]: software-engineer
- [[04-public-skills-directory/skills/obra/subagent-driven-development|subagent-driven-development]]: genai-engineer
- [[04-public-skills-directory/skills/obra/writing-skills|writing-skills]]: technical-writer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
