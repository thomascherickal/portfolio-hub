---
type: source-repo
repo: google-labs-code/stitch-skills
owner: google-labs-code
curator: Thomas Cherickal
stars: 8871
license: Apache-2.0
last_push: 2026-08-17
url: https://github.com/google-labs-code/stitch-skills
tags: [source, owner/google-labs-code]
---

# google-labs-code/stitch-skills

[https://github.com/google-labs-code/stitch-skills](https://github.com/google-labs-code/stitch-skills) - 8,871 stars, license Apache-2.0, last push 2026-08-17.

## Skills Listed Here

- [[04-public-skills-directory/skills/google-labs-code/stitch-extract-static-html|stitch::extract-static-html]]: pwa-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
