---
type: source-repo
repo: Nutlope/hallmark
owner: Nutlope
curator: Thomas Cherickal
stars: 54976
license: MIT
last_push: 2026-11-11
url: https://github.com/Nutlope/hallmark
tags: [source, owner/nutlope]
---

# Nutlope/hallmark

[https://github.com/Nutlope/hallmark](https://github.com/Nutlope/hallmark) - 54,976 stars, license MIT, last push 2026-11-11.

## Skills Listed Here

- [[04-public-skills-directory/skills/nutlope/hallmark|hallmark]]: web-designer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
