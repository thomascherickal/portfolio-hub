---
type: source-repo
repo: GuillaumeLessard/qector-claude-plugin
owner: GuillaumeLessard
curator: Thomas Cherickal
stars: 1
license: NOASSERTION
last_push: 2026-11-12
url: https://github.com/GuillaumeLessard/qector-claude-plugin
tags: [source, owner/guillaumelessard]
---

# GuillaumeLessard/qector-claude-plugin

[https://github.com/GuillaumeLessard/qector-claude-plugin](https://github.com/GuillaumeLessard/qector-claude-plugin) - 1 stars, license NOASSERTION, last push 2026-11-12.

## Skills Listed Here

- [[04-public-skills-directory/skills/guillaumelessard/qector-architecture|qector-architecture]]: quantum-computing-engineer
- [[04-public-skills-directory/skills/guillaumelessard/qector-batch-decoding|qector-batch-decoding]]: quantum-computing-engineer
- [[04-public-skills-directory/skills/guillaumelessard/qector-bp-osd|qector-bp-osd]]: quantum-computing-engineer
- [[04-public-skills-directory/skills/guillaumelessard/qector-codes-builder|qector-codes-builder]]: quantum-computing-engineer
- [[04-public-skills-directory/skills/guillaumelessard/qector-core|qector-core]]: quantum-computing-engineer
- [[04-public-skills-directory/skills/guillaumelessard/qector-decoders-deep-dive|qector-decoders-deep-dive]]: quantum-computing-engineer
- [[04-public-skills-directory/skills/guillaumelessard/qector-dem-pipeline|qector-dem-pipeline]]: quantum-computing-engineer
- [[04-public-skills-directory/skills/guillaumelessard/qector-deployment|qector-deployment]]: quantum-computing-engineer
- [[04-public-skills-directory/skills/guillaumelessard/qector-developer|qector-developer]]: quantum-computing-engineer
- [[04-public-skills-directory/skills/guillaumelessard/qector-educator|qector-educator]]: quantum-computing-researcher
- [[04-public-skills-directory/skills/guillaumelessard/qector-glossary|qector-glossary]]: quantum-computing-researcher
- [[04-public-skills-directory/skills/guillaumelessard/qector-hardware-engineer|qector-hardware-engineer]]: quantum-computing-engineer
- [[04-public-skills-directory/skills/guillaumelessard/qector-ler-methodology|qector-ler-methodology]]: quantum-computing-researcher
- [[04-public-skills-directory/skills/guillaumelessard/qector-math-foundations|qector-math-foundations]]: quantum-ml-engineer, quantum-computing-researcher
- [[04-public-skills-directory/skills/guillaumelessard/qector-pymatching-compat|qector-pymatching-compat]]: quantum-computing-engineer
- [[04-public-skills-directory/skills/guillaumelessard/qector-reproducibility|qector-reproducibility]]: quantum-computing-researcher
- [[04-public-skills-directory/skills/guillaumelessard/qector-researcher|qector-researcher]]: quantum-computing-researcher
- [[04-public-skills-directory/skills/guillaumelessard/qector-roadmap|qector-roadmap]]: quantum-computing-researcher
- [[04-public-skills-directory/skills/guillaumelessard/qector-sinter|qector-sinter]]: quantum-computing-engineer
- [[04-public-skills-directory/skills/guillaumelessard/qector-space-time|qector-space-time]]: quantum-computing-researcher
- [[04-public-skills-directory/skills/guillaumelessard/qector-testing-strategy|qector-testing-strategy]]: quantum-computing-engineer
- [[04-public-skills-directory/skills/guillaumelessard/qector-workbench|qector-workbench]]: quantum-computing-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
