---
type: source-repo
repo: kadenzipfel/scv-scan
owner: kadenzipfel
curator: Thomas Cherickal
stars: 110
license: null
last_push: 2026-03-11
url: https://github.com/kadenzipfel/scv-scan
tags: [source, owner/kadenzipfel]
---

# kadenzipfel/scv-scan

[https://github.com/kadenzipfel/scv-scan](https://github.com/kadenzipfel/scv-scan) - 110 stars, license null, last push 2026-03-11.

## Skills Listed Here

- [[04-public-skills-directory/skills/kadenzipfel/scv-scan|scv-scan]]: blockchain-defi-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
