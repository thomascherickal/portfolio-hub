---
type: moc
curator: Thomas Cherickal
tags: [moc, source]
updated: 2026-11-15
---

# Source Repositories (20)

Sorted by stars.

| Repo | Owner | Stars | License | Skills listed |
|---|---|---|---|---|
| [[04-public-skills-directory/sources/obra-superpowers|obra/superpowers]] | obra | 317,619 | MIT | 8 |
| [[04-public-skills-directory/sources/affaan-m-ecc|affaan-m/ECC]] | affaan-m | 302,998 | MIT | 53 |
| [[04-public-skills-directory/sources/anthropics-skills|anthropics/skills]] | anthropics | 194,585 | null | 10 |
| [[04-public-skills-directory/sources/k-dense-ai-scientific-agent-skills|K-Dense-AI/scientific-agent-skills]] | K-Dense-AI | 57,202 | MIT | 21 |
| [[04-public-skills-directory/sources/imbad0202-academic-research-skills|Imbad0202/academic-research-skills]] | Imbad0202 | 56,891 | NOASSERTION | 3 |
| [[04-public-skills-directory/sources/nutlope-hallmark|Nutlope/hallmark]] | Nutlope | 54,976 | MIT | 1 |
| [[04-public-skills-directory/sources/sickn33-agentic-awesome-skills|sickn33/agentic-awesome-skills]] | sickn33 | 49,710 | MIT | 91 |
| [[04-public-skills-directory/sources/wshobson-agents|wshobson/agents]] | wshobson | 42,512 | MIT | 21 |
| [[04-public-skills-directory/sources/davila7-claude-code-templates|davila7/claude-code-templates]] | davila7 | 33,617 | MIT | 49 |
| [[04-public-skills-directory/sources/alirezarezvani-claude-skills|alirezarezvani/claude-skills]] | alirezarezvani | 29,806 | MIT | 20 |
| [[04-public-skills-directory/sources/wanshuiyin-auto-claude-code-research-in-sleep|wanshuiyin/Auto-claude-code-research-in-sleep]] | wanshuiyin | 19,200 | MIT | 12 |
| [[04-public-skills-directory/sources/orchestra-research-ai-research-skills|Orchestra-Research/AI-Research-SKILLs]] | Orchestra-Research | 14,542 | MIT | 24 |
| [[04-public-skills-directory/sources/jeffallan-claude-skills|jeffallan/claude-skills]] | Jeffallan | 12,361 | MIT | 9 |
| [[04-public-skills-directory/sources/google-labs-code-stitch-skills|google-labs-code/stitch-skills]] | google-labs-code | 8,871 | Apache-2.0 | 1 |
| [[04-public-skills-directory/sources/trailofbits-skills|trailofbits/skills]] | trailofbits | 8,189 | CC-BY-SA-4.0 | 11 |
| [[04-public-skills-directory/sources/morganlinton-beautifulrust|morganlinton/BeautifulRust]] | morganlinton | 1,813 | MIT | 2 |
| [[04-public-skills-directory/sources/awarexone-web3-bug-bounty-hunting-ai-skills|awarexone/web3-bug-bounty-hunting-ai-skills]] | awarexone | 186 | MIT | 5 |
| [[04-public-skills-directory/sources/kadenzipfel-scv-scan|kadenzipfel/scv-scan]] | kadenzipfel | 110 | null | 1 |
| [[04-public-skills-directory/sources/dfinity-icskills|dfinity/icskills]] | dfinity | 40 | Apache-2.0 | 2 |
| [[04-public-skills-directory/sources/guillaumelessard-qector-claude-plugin|GuillaumeLessard/qector-claude-plugin]] | GuillaumeLessard | 1 | NOASSERTION | 22 |

- Up: [[04-public-skills-directory/README|Public directory]]
