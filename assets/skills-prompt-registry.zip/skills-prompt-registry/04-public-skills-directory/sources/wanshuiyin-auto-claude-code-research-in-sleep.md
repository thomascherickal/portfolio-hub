---
type: source-repo
repo: wanshuiyin/Auto-claude-code-research-in-sleep
owner: wanshuiyin
curator: Thomas Cherickal
stars: 19200
license: MIT
last_push: 2026-11-14
url: https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep
tags: [source, owner/wanshuiyin]
---

# wanshuiyin/Auto-claude-code-research-in-sleep

[https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) - 19,200 stars, license MIT, last push 2026-11-14.

## Skills Listed Here

- [[04-public-skills-directory/skills/wanshuiyin/ablation-planner|ablation-planner]]: research-scientist
- [[04-public-skills-directory/skills/wanshuiyin/arxiv|arxiv]]: research-scientist
- [[04-public-skills-directory/skills/wanshuiyin/experiment-plan|experiment-plan]]: research-scientist
- [[04-public-skills-directory/skills/wanshuiyin/firecrawl-search|firecrawl-search]]: industry-researcher
- [[04-public-skills-directory/skills/wanshuiyin/formula-derivation|formula-derivation]]: quantum-computing-researcher
- [[04-public-skills-directory/skills/wanshuiyin/lean-formalize|lean-formalize]]: quantum-computing-researcher
- [[04-public-skills-directory/skills/wanshuiyin/mermaid-diagram|mermaid-diagram]]: technical-writer
- [[04-public-skills-directory/skills/wanshuiyin/novelty-check|novelty-check]]: research-scientist
- [[04-public-skills-directory/skills/wanshuiyin/openalex|openalex]]: research-scientist
- [[04-public-skills-directory/skills/wanshuiyin/proof-checker|proof-checker]]: quantum-computing-researcher
- [[04-public-skills-directory/skills/wanshuiyin/render-html|render-html]]: pwa-engineer
- [[04-public-skills-directory/skills/wanshuiyin/specification-writing|specification-writing]]: technical-writer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
