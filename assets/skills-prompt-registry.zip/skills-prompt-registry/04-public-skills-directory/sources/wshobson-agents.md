---
type: source-repo
repo: wshobson/agents
owner: wshobson
curator: Thomas Cherickal
stars: 42512
license: MIT
last_push: 2026-11-09
url: https://github.com/wshobson/agents
tags: [source, owner/wshobson]
---

# wshobson/agents

[https://github.com/wshobson/agents](https://github.com/wshobson/agents) - 42,512 stars, license MIT, last push 2026-11-09.

## Skills Listed Here

- [[04-public-skills-directory/skills/wshobson/accessibility-compliance|accessibility-compliance]]: frontend-engineer
- [[04-public-skills-directory/skills/wshobson/dataset-curation|dataset-curation]]: llm-engineer
- [[04-public-skills-directory/skills/wshobson/design-system-patterns|design-system-patterns]]: web-designer
- [[04-public-skills-directory/skills/wshobson/eval-harness-first|eval-harness-first]]: ai-engineer
- [[04-public-skills-directory/skills/wshobson/evaluation-methodology|evaluation-methodology]]: ai-engineer
- [[04-public-skills-directory/skills/wshobson/finetuning-method-selection|finetuning-method-selection]]: llm-engineer
- [[04-public-skills-directory/skills/wshobson/grpo-rlvr-training|grpo-rlvr-training]]: llm-engineer
- [[04-public-skills-directory/skills/wshobson/interaction-design|interaction-design]]: web-designer
- [[04-public-skills-directory/skills/wshobson/lora-qlora-recipes|lora-qlora-recipes]]: llm-engineer
- [[04-public-skills-directory/skills/wshobson/postgresql-table-design|postgresql-table-design]]: backend-engineer
- [[04-public-skills-directory/skills/wshobson/protect-mcp-setup|protect-mcp-setup]]: genai-engineer
- [[04-public-skills-directory/skills/wshobson/python-anti-patterns|python-anti-patterns]]: python-engineer
- [[04-public-skills-directory/skills/wshobson/python-background-jobs|python-background-jobs]]: python-engineer
- [[04-public-skills-directory/skills/wshobson/python-code-style|python-code-style]]: python-engineer
- [[04-public-skills-directory/skills/wshobson/python-configuration|python-configuration]]: python-engineer
- [[04-public-skills-directory/skills/wshobson/python-design-patterns|python-design-patterns]]: python-engineer
- [[04-public-skills-directory/skills/wshobson/quantized-export|quantized-export]]: local-ai-engineer
- [[04-public-skills-directory/skills/wshobson/react-native-design|react-native-design]]: frontend-engineer
- [[04-public-skills-directory/skills/wshobson/review-agent-setup|review-agent-setup]]: genai-engineer
- [[04-public-skills-directory/skills/wshobson/social-evidence-research|social-evidence-research]]: industry-researcher
- [[04-public-skills-directory/skills/wshobson/web-component-design|web-component-design]]: pwa-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
