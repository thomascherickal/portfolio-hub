---
type: source-repo
repo: dfinity/icskills
owner: dfinity
curator: Thomas Cherickal
stars: 40
license: Apache-2.0
last_push: 2026-11-14
url: https://github.com/dfinity/icskills
tags: [source, owner/dfinity]
---

# dfinity/icskills

[https://github.com/dfinity/icskills](https://github.com/dfinity/icskills) - 40 stars, license Apache-2.0, last push 2026-11-14.

## Skills Listed Here

- [[04-public-skills-directory/skills/dfinity/canister-security|canister-security]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/dfinity/static-site|static-site]]: pwa-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
