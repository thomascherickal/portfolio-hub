---
type: source-repo
repo: affaan-m/ECC
owner: affaan-m
curator: Thomas Cherickal
stars: 302998
license: MIT
last_push: 2026-11-09
url: https://github.com/affaan-m/ECC
tags: [source, owner/affaan-m]
---

# affaan-m/ECC

[https://github.com/affaan-m/ECC](https://github.com/affaan-m/ECC) - 302,998 stars, license MIT, last push 2026-11-09.

## Skills Listed Here

- [[04-public-skills-directory/skills/affaan-m/accessibility|accessibility]]: frontend-engineer
- [[04-public-skills-directory/skills/affaan-m/agent-architecture-audit|agent-architecture-audit]]: genai-engineer
- [[04-public-skills-directory/skills/affaan-m/agent-eval|agent-eval]]: ai-engineer, genai-engineer
- [[04-public-skills-directory/skills/affaan-m/agent-harness-construction|agent-harness-construction]]: genai-engineer
- [[04-public-skills-directory/skills/affaan-m/agent-introspection-debugging|agent-introspection-debugging]]: genai-engineer
- [[04-public-skills-directory/skills/affaan-m/agent-payment-x402|agent-payment-x402]]: genai-engineer, blockchain-defi-engineer
- [[04-public-skills-directory/skills/affaan-m/agent-self-evaluation|agent-self-evaluation]]: ai-engineer
- [[04-public-skills-directory/skills/affaan-m/angular-developer|angular-developer]]: frontend-engineer
- [[04-public-skills-directory/skills/affaan-m/api-design|api-design]]: backend-engineer
- [[04-public-skills-directory/skills/affaan-m/architecture-decision-records|architecture-decision-records]]: software-engineer
- [[04-public-skills-directory/skills/affaan-m/article-writing|article-writing]]: technical-writer
- [[04-public-skills-directory/skills/affaan-m/backend-patterns|backend-patterns]]: backend-engineer
- [[04-public-skills-directory/skills/affaan-m/benchmark-methodology|benchmark-methodology]]: industry-researcher
- [[04-public-skills-directory/skills/affaan-m/brand-discovery|brand-discovery]]: web-designer
- [[04-public-skills-directory/skills/affaan-m/browser-qa|browser-qa]]: frontend-engineer
- [[04-public-skills-directory/skills/affaan-m/competitive-platform-analysis|competitive-platform-analysis]]: industry-researcher
- [[04-public-skills-directory/skills/affaan-m/competitive-report-structure|competitive-report-structure]]: industry-researcher
- [[04-public-skills-directory/skills/affaan-m/database-migrations|database-migrations]]: backend-engineer
- [[04-public-skills-directory/skills/affaan-m/deep-research|deep-research]]: industry-researcher
- [[04-public-skills-directory/skills/affaan-m/defi-amm-security|defi-amm-security]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/affaan-m/design-system|design-system]]: web-designer
- [[04-public-skills-directory/skills/affaan-m/django-celery|django-celery]]: python-engineer
- [[04-public-skills-directory/skills/affaan-m/django-patterns|django-patterns]]: python-engineer
- [[04-public-skills-directory/skills/affaan-m/django-security|django-security]]: python-engineer
- [[04-public-skills-directory/skills/affaan-m/django-tdd|django-tdd]]: python-engineer, software-engineer
- [[04-public-skills-directory/skills/affaan-m/django-verification|django-verification]]: python-engineer
- [[04-public-skills-directory/skills/affaan-m/docs-governance|docs-governance]]: technical-writer
- [[04-public-skills-directory/skills/affaan-m/documentation-lookup|documentation-lookup]]: technical-writer
- [[04-public-skills-directory/skills/affaan-m/enterprise-agent-ops|enterprise-agent-ops]]: genai-consultant
- [[04-public-skills-directory/skills/affaan-m/eval-harness|eval-harness]]: ai-engineer
- [[04-public-skills-directory/skills/affaan-m/evm-token-decimals|evm-token-decimals]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/affaan-m/exa-search|exa-search]]: industry-researcher
- [[04-public-skills-directory/skills/affaan-m/flutter-dart-code-review|flutter-dart-code-review]]: software-engineer
- [[04-public-skills-directory/skills/affaan-m/foundation-models-on-device|foundation-models-on-device]]: local-ai-engineer
- [[04-public-skills-directory/skills/affaan-m/frontend-a11y|frontend-a11y]]: frontend-engineer
- [[04-public-skills-directory/skills/affaan-m/frontend-design-direction|frontend-design-direction]]: frontend-engineer, web-designer
- [[04-public-skills-directory/skills/affaan-m/golang-patterns|golang-patterns]]: go-engineer
- [[04-public-skills-directory/skills/affaan-m/golang-testing|golang-testing]]: go-engineer
- [[04-public-skills-directory/skills/affaan-m/healthcare-eval-harness|healthcare-eval-harness]]: ai-engineer
- [[04-public-skills-directory/skills/affaan-m/iterative-retrieval|iterative-retrieval]]: rag-engineer
- [[04-public-skills-directory/skills/affaan-m/knowledge-ops|knowledge-ops]]: rag-engineer
- [[04-public-skills-directory/skills/affaan-m/laravel-tdd|laravel-tdd]]: software-engineer
- [[04-public-skills-directory/skills/affaan-m/liquid-glass-design|liquid-glass-design]]: web-designer
- [[04-public-skills-directory/skills/affaan-m/living-docs-governance|living-docs-governance]]: technical-writer
- [[04-public-skills-directory/skills/affaan-m/mysql-patterns|mysql-patterns]]: backend-engineer
- [[04-public-skills-directory/skills/affaan-m/nextjs-turbopack|nextjs-turbopack]]: fullstack-engineer
- [[04-public-skills-directory/skills/affaan-m/postgres-patterns|postgres-patterns]]: backend-engineer
- [[04-public-skills-directory/skills/affaan-m/quarkus-tdd|quarkus-tdd]]: software-engineer
- [[04-public-skills-directory/skills/affaan-m/rust-patterns|rust-patterns]]: rust-engineer
- [[04-public-skills-directory/skills/affaan-m/rust-testing|rust-testing]]: rust-engineer
- [[04-public-skills-directory/skills/affaan-m/scientific-thinking-literature-review|scientific-thinking-literature-review]]: research-scientist
- [[04-public-skills-directory/skills/affaan-m/scientific-thinking-scholar-evaluation|scientific-thinking-scholar-evaluation]]: ai-engineer, research-scientist
- [[04-public-skills-directory/skills/affaan-m/vite-patterns|vite-patterns]]: pwa-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
