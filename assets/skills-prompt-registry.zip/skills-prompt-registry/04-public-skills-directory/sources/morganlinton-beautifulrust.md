---
type: source-repo
repo: morganlinton/BeautifulRust
owner: morganlinton
curator: Thomas Cherickal
stars: 1813
license: MIT
last_push: 2026-11-08
url: https://github.com/morganlinton/BeautifulRust
tags: [source, owner/morganlinton]
---

# morganlinton/BeautifulRust

[https://github.com/morganlinton/BeautifulRust](https://github.com/morganlinton/BeautifulRust) - 1,813 stars, license MIT, last push 2026-11-08.

## Skills Listed Here

- [[04-public-skills-directory/skills/morganlinton/rust-best-practices|rust-best-practices]]: rust-engineer
- [[04-public-skills-directory/skills/morganlinton/rust-port|rust-port]]: rust-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
