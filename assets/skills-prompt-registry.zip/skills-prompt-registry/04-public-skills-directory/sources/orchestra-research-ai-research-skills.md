---
type: source-repo
repo: Orchestra-Research/AI-Research-SKILLs
owner: Orchestra-Research
curator: Thomas Cherickal
stars: 14542
license: MIT
last_push: 2026-10-11
url: https://github.com/Orchestra-Research/AI-Research-SKILLs
tags: [source, owner/orchestra-research]
---

# Orchestra-Research/AI-Research-SKILLs

[https://github.com/Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) - 14,542 stars, license MIT, last push 2026-10-11.

## Skills Listed Here

- [[04-public-skills-directory/skills/orchestra-research/academic-plotting|academic-plotting]]: research-scientist
- [[04-public-skills-directory/skills/orchestra-research/awq-quantization|awq-quantization]]: local-ai-engineer
- [[04-public-skills-directory/skills/orchestra-research/axolotl|axolotl]]: llm-engineer
- [[04-public-skills-directory/skills/orchestra-research/brainstorming-research-ideas|brainstorming-research-ideas]]: software-engineer
- [[04-public-skills-directory/skills/orchestra-research/chroma|chroma]]: rag-engineer
- [[04-public-skills-directory/skills/orchestra-research/deepspeed|deepspeed]]: llm-engineer
- [[04-public-skills-directory/skills/orchestra-research/distributed-llm-pretraining-torchtitan|distributed-llm-pretraining-torchtitan]]: llm-engineer
- [[04-public-skills-directory/skills/orchestra-research/faiss|faiss]]: rag-engineer
- [[04-public-skills-directory/skills/orchestra-research/fine-tuning-openvla-oft|fine-tuning-openvla-oft]]: llm-engineer
- [[04-public-skills-directory/skills/orchestra-research/fine-tuning-serving-openpi|fine-tuning-serving-openpi]]: llm-engineer
- [[04-public-skills-directory/skills/orchestra-research/gguf-quantization|gguf-quantization]]: local-ai-engineer
- [[04-public-skills-directory/skills/orchestra-research/gptq|gptq]]: local-ai-engineer
- [[04-public-skills-directory/skills/orchestra-research/hqq-quantization|hqq-quantization]]: local-ai-engineer
- [[04-public-skills-directory/skills/orchestra-research/llama-cpp|llama-cpp]]: local-ai-engineer
- [[04-public-skills-directory/skills/orchestra-research/llamaindex|llamaindex]]: rag-engineer
- [[04-public-skills-directory/skills/orchestra-research/mamba-architecture|mamba-architecture]]: quantum-ml-engineer
- [[04-public-skills-directory/skills/orchestra-research/outlines|outlines]]: local-ai-engineer
- [[04-public-skills-directory/skills/orchestra-research/pinecone|pinecone]]: rag-engineer
- [[04-public-skills-directory/skills/orchestra-research/qdrant-vector-search|qdrant-vector-search]]: rag-engineer
- [[04-public-skills-directory/skills/orchestra-research/quantizing-models-bitsandbytes|quantizing-models-bitsandbytes]]: local-ai-engineer
- [[04-public-skills-directory/skills/orchestra-research/sparse-autoencoder-training|sparse-autoencoder-training]]: quantum-ml-engineer
- [[04-public-skills-directory/skills/orchestra-research/systems-paper-writing|systems-paper-writing]]: research-scientist
- [[04-public-skills-directory/skills/orchestra-research/transformer-lens-interpretability|transformer-lens-interpretability]]: quantum-ml-engineer
- [[04-public-skills-directory/skills/orchestra-research/whisper|whisper]]: local-ai-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
