---
type: source-repo
repo: jeffallan/claude-skills
owner: Jeffallan
curator: Thomas Cherickal
stars: 12361
license: MIT
last_push: 2026-11-11
url: https://github.com/Jeffallan/claude-skills
tags: [source, owner/jeffallan]
---

# jeffallan/claude-skills

[https://github.com/Jeffallan/claude-skills](https://github.com/Jeffallan/claude-skills) - 12,361 stars, license MIT, last push 2026-11-11.

## Skills Listed Here

- [[04-public-skills-directory/skills/jeffallan/django-expert|django-expert]]: python-engineer
- [[04-public-skills-directory/skills/jeffallan/django-storages-s3|django-storages-s3]]: python-engineer
- [[04-public-skills-directory/skills/jeffallan/fastapi-expert|fastapi-expert]]: python-engineer
- [[04-public-skills-directory/skills/jeffallan/fine-tuning-expert|fine-tuning-expert]]: llm-engineer
- [[04-public-skills-directory/skills/jeffallan/fullstack-guardian|fullstack-guardian]]: fullstack-engineer
- [[04-public-skills-directory/skills/jeffallan/microservices-architect|microservices-architect]]: backend-engineer
- [[04-public-skills-directory/skills/jeffallan/nextjs-developer|nextjs-developer]]: fullstack-engineer
- [[04-public-skills-directory/skills/jeffallan/postgres-pro|postgres-pro]]: backend-engineer
- [[04-public-skills-directory/skills/jeffallan/rust-engineer|rust-engineer]]: rust-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
