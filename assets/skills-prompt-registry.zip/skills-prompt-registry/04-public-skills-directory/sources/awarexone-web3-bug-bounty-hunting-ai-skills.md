---
type: source-repo
repo: awarexone/web3-bug-bounty-hunting-ai-skills
owner: awarexone
curator: Thomas Cherickal
stars: 186
license: MIT
last_push: 2026-09-21
url: https://github.com/awarexone/web3-bug-bounty-hunting-ai-skills
tags: [source, owner/awarexone]
---

# awarexone/web3-bug-bounty-hunting-ai-skills

[https://github.com/awarexone/web3-bug-bounty-hunting-ai-skills](https://github.com/awarexone/web3-bug-bounty-hunting-ai-skills) - 186 stars, license MIT, last push 2026-09-21.

## Skills Listed Here

- [[04-public-skills-directory/skills/awarexone/web3-ai-tools|web3-ai-tools]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/awarexone/web3-bug-classes|web3-bug-classes]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/awarexone/web3-case-study-role-misconfig|web3-case-study-role-misconfig]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/awarexone/web3-grep-arsenal|web3-grep-arsenal]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/awarexone/web3-hunt-foundation|web3-hunt-foundation]]: blockchain-defi-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
