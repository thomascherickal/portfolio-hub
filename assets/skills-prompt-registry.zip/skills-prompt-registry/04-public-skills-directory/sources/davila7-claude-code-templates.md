---
type: source-repo
repo: davila7/claude-code-templates
owner: davila7
curator: Thomas Cherickal
stars: 33617
license: MIT
last_push: 2026-11-14
url: https://github.com/davila7/claude-code-templates
tags: [source, owner/davila7]
---

# davila7/claude-code-templates

[https://github.com/davila7/claude-code-templates](https://github.com/davila7/claude-code-templates) - 33,617 stars, license MIT, last push 2026-11-14.

## Skills Listed Here

- [[04-public-skills-directory/skills/davila7/mcp-integration|MCP Integration]]: genai-engineer
- [[04-public-skills-directory/skills/davila7/accessibility-auditor|accessibility-auditor]]: frontend-engineer
- [[04-public-skills-directory/skills/davila7/agent-development|agent-development]]: genai-engineer
- [[04-public-skills-directory/skills/davila7/agent-management|agent-management]]: genai-engineer
- [[04-public-skills-directory/skills/davila7/agent-md-refactor|agent-md-refactor]]: software-engineer, genai-engineer
- [[04-public-skills-directory/skills/davila7/agents-llamaindex|agents-llamaindex]]: rag-engineer
- [[04-public-skills-directory/skills/davila7/backend-to-frontend-handoff-docs|backend-to-frontend-handoff-docs]]: backend-engineer, frontend-engineer, technical-writer
- [[04-public-skills-directory/skills/davila7/ceo-advisor|ceo-advisor]]: genai-consultant
- [[04-public-skills-directory/skills/davila7/changelog-generator|changelog-generator]]: technical-writer
- [[04-public-skills-directory/skills/davila7/code-review|code-review]]: software-engineer
- [[04-public-skills-directory/skills/davila7/content-research-writer|content-research-writer]]: industry-researcher
- [[04-public-skills-directory/skills/davila7/core-web-vitals|core-web-vitals]]: pwa-engineer
- [[04-public-skills-directory/skills/davila7/cto-advisor|cto-advisor]]: genai-consultant
- [[04-public-skills-directory/skills/davila7/deep-research-notebooklm|deep-research-notebooklm]]: industry-researcher
- [[04-public-skills-directory/skills/davila7/distributed-training-deepspeed|distributed-training-deepspeed]]: llm-engineer
- [[04-public-skills-directory/skills/davila7/distributed-training-megatron-core|distributed-training-megatron-core]]: llm-engineer
- [[04-public-skills-directory/skills/davila7/distributed-training-pytorch-fsdp|distributed-training-pytorch-fsdp]]: llm-engineer
- [[04-public-skills-directory/skills/davila7/distributed-training-pytorch-lightning|distributed-training-pytorch-lightning]]: quantum-ml-engineer
- [[04-public-skills-directory/skills/davila7/docs-search|docs-search]]: technical-writer
- [[04-public-skills-directory/skills/davila7/emerging-techniques-knowledge-distillation|emerging-techniques-knowledge-distillation]]: llm-engineer
- [[04-public-skills-directory/skills/davila7/emerging-techniques-long-context|emerging-techniques-long-context]]: llm-engineer
- [[04-public-skills-directory/skills/davila7/eval-genius|eval-genius]]: ai-engineer
- [[04-public-skills-directory/skills/davila7/evaluation-bigcode-evaluation-harness|evaluation-bigcode-evaluation-harness]]: ai-engineer
- [[04-public-skills-directory/skills/davila7/evaluation-lm-evaluation-harness|evaluation-lm-evaluation-harness]]: ai-engineer
- [[04-public-skills-directory/skills/davila7/evaluation-nemo-evaluator|evaluation-nemo-evaluator]]: ai-engineer
- [[04-public-skills-directory/skills/davila7/fastapi-endpoint|fastapi-endpoint]]: python-engineer
- [[04-public-skills-directory/skills/davila7/frontend-to-backend-requirements|frontend-to-backend-requirements]]: backend-engineer, frontend-engineer
- [[04-public-skills-directory/skills/davila7/inference-serving-llama-cpp|inference-serving-llama-cpp]]: local-ai-engineer
- [[04-public-skills-directory/skills/davila7/mermaid-diagram-specialist|mermaid-diagram-specialist]]: technical-writer
- [[04-public-skills-directory/skills/davila7/ml-paper-writing|ml-paper-writing]]: research-scientist
- [[04-public-skills-directory/skills/davila7/multimodal-whisper|multimodal-whisper]]: local-ai-engineer
- [[04-public-skills-directory/skills/davila7/notion-research-documentation|notion-research-documentation]]: technical-writer
- [[04-public-skills-directory/skills/davila7/openalex-database|openalex-database]]: research-scientist
- [[04-public-skills-directory/skills/davila7/optimization-awq|optimization-awq]]: local-ai-engineer
- [[04-public-skills-directory/skills/davila7/optimization-bitsandbytes|optimization-bitsandbytes]]: local-ai-engineer
- [[04-public-skills-directory/skills/davila7/optimization-gguf|optimization-gguf]]: local-ai-engineer
- [[04-public-skills-directory/skills/davila7/optimization-gptq|optimization-gptq]]: local-ai-engineer
- [[04-public-skills-directory/skills/davila7/optimization-hqq|optimization-hqq]]: local-ai-engineer
- [[04-public-skills-directory/skills/davila7/postgres-schema-design|postgres-schema-design]]: backend-engineer
- [[04-public-skills-directory/skills/davila7/prompt-engineering-dspy|prompt-engineering-dspy]]: ai-engineer
- [[04-public-skills-directory/skills/davila7/prompt-engineering-outlines|prompt-engineering-outlines]]: local-ai-engineer
- [[04-public-skills-directory/skills/davila7/rag-chroma|rag-chroma]]: rag-engineer
- [[04-public-skills-directory/skills/davila7/rag-faiss|rag-faiss]]: rag-engineer
- [[04-public-skills-directory/skills/davila7/rag-pinecone|rag-pinecone]]: rag-engineer
- [[04-public-skills-directory/skills/davila7/rag-qdrant|rag-qdrant]]: rag-engineer
- [[04-public-skills-directory/skills/davila7/react-dev|react-dev]]: frontend-engineer
- [[04-public-skills-directory/skills/davila7/react-useeffect|react-useeffect]]: frontend-engineer
- [[04-public-skills-directory/skills/davila7/rust-cli-builder|rust-cli-builder]]: rust-engineer
- [[04-public-skills-directory/skills/davila7/senior-backend|senior-backend]]: backend-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
