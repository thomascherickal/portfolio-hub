---
type: source-repo
repo: sickn33/agentic-awesome-skills
owner: sickn33
curator: Thomas Cherickal
stars: 49710
license: MIT
last_push: 2026-11-14
url: https://github.com/sickn33/agentic-awesome-skills
tags: [source, owner/sickn33]
---

# sickn33/agentic-awesome-skills

[https://github.com/sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) - 49,710 stars, license MIT, last push 2026-11-14.

## Skills Listed Here

- [[04-public-skills-directory/skills/sickn33/00-andruia-consultant|00-andruia-consultant]]: genai-consultant
- [[04-public-skills-directory/skills/sickn33/3d-ui|3d-ui]]: web-designer
- [[04-public-skills-directory/skills/sickn33/accessibility-compliance-accessibility-audit|accessibility-compliance-accessibility-audit]]: frontend-engineer
- [[04-public-skills-directory/skills/sickn33/advanced-evaluation|advanced-evaluation]]: ai-engineer
- [[04-public-skills-directory/skills/sickn33/agent-creator|agent-creator]]: genai-engineer
- [[04-public-skills-directory/skills/sickn33/agent-evals|agent-evals]]: ai-engineer, genai-engineer
- [[04-public-skills-directory/skills/sickn33/agent-evaluation|agent-evaluation]]: ai-engineer, genai-engineer
- [[04-public-skills-directory/skills/sickn33/agent-evaluation-reporting|agent-evaluation-reporting]]: ai-engineer, genai-engineer
- [[04-public-skills-directory/skills/sickn33/agent-framework-azure-ai-py|agent-framework-azure-ai-py]]: genai-engineer
- [[04-public-skills-directory/skills/sickn33/agent-observability|agent-observability]]: ai-engineer
- [[04-public-skills-directory/skills/sickn33/ai-native-ui|ai-native-ui]]: web-designer
- [[04-public-skills-directory/skills/sickn33/angular|angular]]: frontend-engineer
- [[04-public-skills-directory/skills/sickn33/angular-best-practices|angular-best-practices]]: frontend-engineer
- [[04-public-skills-directory/skills/sickn33/angular-migration|angular-migration]]: frontend-engineer
- [[04-public-skills-directory/skills/sickn33/angular-state-management|angular-state-management]]: frontend-engineer
- [[04-public-skills-directory/skills/sickn33/api-design-principles|api-design-principles]]: backend-engineer
- [[04-public-skills-directory/skills/sickn33/api-documentation|api-documentation]]: technical-writer
- [[04-public-skills-directory/skills/sickn33/api-documentation-generator|api-documentation-generator]]: technical-writer
- [[04-public-skills-directory/skills/sickn33/api-documenter|api-documenter]]: technical-writer
- [[04-public-skills-directory/skills/sickn33/apify-competitor-intelligence|apify-competitor-intelligence]]: industry-researcher
- [[04-public-skills-directory/skills/sickn33/apify-market-research|apify-market-research]]: industry-researcher
- [[04-public-skills-directory/skills/sickn33/apify-trend-analysis|apify-trend-analysis]]: industry-researcher
- [[04-public-skills-directory/skills/sickn33/app-builder|app-builder]]: fullstack-engineer
- [[04-public-skills-directory/skills/sickn33/app-store-changelog|app-store-changelog]]: technical-writer
- [[04-public-skills-directory/skills/sickn33/async-python-patterns|async-python-patterns]]: python-engineer
- [[04-public-skills-directory/skills/sickn33/auth-implementation-patterns|auth-implementation-patterns]]: fullstack-engineer
- [[04-public-skills-directory/skills/sickn33/avoid-ai-writing|avoid-ai-writing]]: technical-writer
- [[04-public-skills-directory/skills/sickn33/azure-cosmos-rust|azure-cosmos-rust]]: rust-engineer
- [[04-public-skills-directory/skills/sickn33/azure-eventhub-rust|azure-eventhub-rust]]: rust-engineer
- [[04-public-skills-directory/skills/sickn33/backend-architect|backend-architect]]: backend-engineer
- [[04-public-skills-directory/skills/sickn33/backend-dev-guidelines|backend-dev-guidelines]]: backend-engineer
- [[04-public-skills-directory/skills/sickn33/backend-development-feature-development|backend-development-feature-development]]: backend-engineer
- [[04-public-skills-directory/skills/sickn33/backend-security-coder|backend-security-coder]]: backend-engineer
- [[04-public-skills-directory/skills/sickn33/blockchain-developer|blockchain-developer]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/sickn33/change-management|change-management]]: genai-consultant
- [[04-public-skills-directory/skills/sickn33/chrome-extension-developer|chrome-extension-developer]]: pwa-engineer
- [[04-public-skills-directory/skills/sickn33/clean-code|clean-code]]: software-engineer
- [[04-public-skills-directory/skills/sickn33/clean-code-guard|clean-code-guard]]: software-engineer
- [[04-public-skills-directory/skills/sickn33/clerk-auth|clerk-auth]]: fullstack-engineer
- [[04-public-skills-directory/skills/sickn33/code-refactoring-context-restore|code-refactoring-context-restore]]: software-engineer
- [[04-public-skills-directory/skills/sickn33/code-refactoring-refactor-clean|code-refactoring-refactor-clean]]: software-engineer
- [[04-public-skills-directory/skills/sickn33/code-refactoring-tech-debt|code-refactoring-tech-debt]]: software-engineer
- [[04-public-skills-directory/skills/sickn33/competitive-landscape|competitive-landscape]]: industry-researcher
- [[04-public-skills-directory/skills/sickn33/competitor-alternatives|competitor-alternatives]]: industry-researcher
- [[04-public-skills-directory/skills/sickn33/data-storytelling|data-storytelling]]: genai-consultant
- [[04-public-skills-directory/skills/sickn33/dbos-golang|dbos-golang]]: go-engineer
- [[04-public-skills-directory/skills/sickn33/dbos-python|dbos-python]]: python-engineer
- [[04-public-skills-directory/skills/sickn33/defi-protocol-templates|defi-protocol-templates]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/sickn33/defi-yield-strategy-allocator|defi-yield-strategy-allocator]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/sickn33/django-access-review|django-access-review]]: python-engineer
- [[04-public-skills-directory/skills/sickn33/django-perf-review|django-perf-review]]: python-engineer
- [[04-public-skills-directory/skills/sickn33/django-pro|django-pro]]: python-engineer
- [[04-public-skills-directory/skills/sickn33/embedding-strategies|embedding-strategies]]: rag-engineer
- [[04-public-skills-directory/skills/sickn33/faf-go|faf-go]]: go-engineer
- [[04-public-skills-directory/skills/sickn33/frontend-lighthouse|frontend-lighthouse]]: pwa-engineer
- [[04-public-skills-directory/skills/sickn33/full-stack-orchestration-full-stack-feature|full-stack-orchestration-full-stack-feature]]: fullstack-engineer
- [[04-public-skills-directory/skills/sickn33/go|go]]: go-engineer
- [[04-public-skills-directory/skills/sickn33/go-concurrency-patterns|go-concurrency-patterns]]: go-engineer
- [[04-public-skills-directory/skills/sickn33/go-in-depth|go-in-depth]]: go-engineer
- [[04-public-skills-directory/skills/sickn33/go-playwright|go-playwright]]: go-engineer
- [[04-public-skills-directory/skills/sickn33/go-rod-master|go-rod-master]]: go-engineer
- [[04-public-skills-directory/skills/sickn33/go-rust-reverse|go-rust-reverse]]: rust-engineer, go-engineer
- [[04-public-skills-directory/skills/sickn33/golang-pro|golang-pro]]: go-engineer
- [[04-public-skills-directory/skills/sickn33/grpc-golang|grpc-golang]]: go-engineer
- [[04-public-skills-directory/skills/sickn33/huggingface-lora-space-builder|huggingface-lora-space-builder]]: llm-engineer
- [[04-public-skills-directory/skills/sickn33/hunt-nextjs|hunt-nextjs]]: fullstack-engineer
- [[04-public-skills-directory/skills/sickn33/hunt-rag-vector|hunt-rag-vector]]: rag-engineer
- [[04-public-skills-directory/skills/sickn33/hybrid-search-implementation|hybrid-search-implementation]]: rag-engineer
- [[04-public-skills-directory/skills/sickn33/javascript-pro|javascript-pro]]: pwa-engineer
- [[04-public-skills-directory/skills/sickn33/llm-fine-tuning|llm-fine-tuning]]: llm-engineer
- [[04-public-skills-directory/skills/sickn33/local-llm-expert|local-llm-expert]]: local-ai-engineer
- [[04-public-skills-directory/skills/sickn33/markstream-nuxt|markstream-nuxt]]: fullstack-engineer
- [[04-public-skills-directory/skills/sickn33/micro-saas-launcher|micro-saas-launcher]]: fullstack-engineer
- [[04-public-skills-directory/skills/sickn33/modern-javascript-patterns|modern-javascript-patterns]]: pwa-engineer
- [[04-public-skills-directory/skills/sickn33/nextjs-app-router-patterns|nextjs-app-router-patterns]]: fullstack-engineer
- [[04-public-skills-directory/skills/sickn33/ollama-stack|ollama-stack]]: local-ai-engineer
- [[04-public-skills-directory/skills/sickn33/progressive-web-app|progressive-web-app]]: pwa-engineer
- [[04-public-skills-directory/skills/sickn33/rag-engineer|rag-engineer]]: rag-engineer
- [[04-public-skills-directory/skills/sickn33/rag-implementation|rag-implementation]]: rag-engineer
- [[04-public-skills-directory/skills/sickn33/rust|rust]]: rust-engineer
- [[04-public-skills-directory/skills/sickn33/rust-async-patterns|rust-async-patterns]]: rust-engineer
- [[04-public-skills-directory/skills/sickn33/rust-pro|rust-pro]]: rust-engineer
- [[04-public-skills-directory/skills/sickn33/smart-contract-formal-verification|smart-contract-formal-verification]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/sickn33/smart-contract-upgrade-governance|smart-contract-upgrade-governance]]: blockchain-defi-engineer
- [[04-public-skills-directory/skills/sickn33/systems-programming-rust-project|systems-programming-rust-project]]: rust-engineer
- [[04-public-skills-directory/skills/sickn33/temporal-golang-pro|temporal-golang-pro]]: go-engineer
- [[04-public-skills-directory/skills/sickn33/text-to-html-converter|text-to-html-converter]]: pwa-engineer
- [[04-public-skills-directory/skills/sickn33/trl-training|trl-training]]: llm-engineer
- [[04-public-skills-directory/skills/sickn33/unsloth-finetuning|unsloth-finetuning]]: llm-engineer
- [[04-public-skills-directory/skills/sickn33/vllm-server|vllm-server]]: llm-engineer
- [[04-public-skills-directory/skills/sickn33/web-performance-optimization|web-performance-optimization]]: pwa-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
