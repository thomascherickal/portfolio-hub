---
type: source-repo
repo: K-Dense-AI/scientific-agent-skills
owner: K-Dense-AI
curator: Thomas Cherickal
stars: 57202
license: MIT
last_push: 2026-11-09
url: https://github.com/K-Dense-AI/scientific-agent-skills
tags: [source, owner/k-dense-ai]
---

# K-Dense-AI/scientific-agent-skills

[https://github.com/K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) - 57,202 stars, license MIT, last push 2026-11-09.

## Skills Listed Here

- [[04-public-skills-directory/skills/k-dense-ai/cirq|cirq]]: quantum-computing-engineer, quantum-ml-engineer, quantum-computing-researcher
- [[04-public-skills-directory/skills/k-dense-ai/citation-management|citation-management]]: research-scientist
- [[04-public-skills-directory/skills/k-dense-ai/experimental-design|experimental-design]]: research-scientist
- [[04-public-skills-directory/skills/k-dense-ai/hypothesis-generation|hypothesis-generation]]: research-scientist
- [[04-public-skills-directory/skills/k-dense-ai/infographics|infographics]]: web-designer
- [[04-public-skills-directory/skills/k-dense-ai/iso-standards-readiness|iso-standards-readiness]]: genai-consultant
- [[04-public-skills-directory/skills/k-dense-ai/latex-posters|latex-posters]]: research-scientist
- [[04-public-skills-directory/skills/k-dense-ai/literature-review|literature-review]]: research-scientist
- [[04-public-skills-directory/skills/k-dense-ai/markdown-mermaid-writing|markdown-mermaid-writing]]: technical-writer
- [[04-public-skills-directory/skills/k-dense-ai/market-research-reports|market-research-reports]]: industry-researcher
- [[04-public-skills-directory/skills/k-dense-ai/parallel-web|parallel-web]]: industry-researcher
- [[04-public-skills-directory/skills/k-dense-ai/pennylane|pennylane]]: quantum-computing-engineer, quantum-ml-engineer, quantum-computing-researcher
- [[04-public-skills-directory/skills/k-dense-ai/pi-agent|pi-agent]]: genai-engineer
- [[04-public-skills-directory/skills/k-dense-ai/pytorch-lightning|pytorch-lightning]]: quantum-ml-engineer
- [[04-public-skills-directory/skills/k-dense-ai/qiskit|qiskit]]: quantum-computing-engineer, quantum-ml-engineer, quantum-computing-researcher
- [[04-public-skills-directory/skills/k-dense-ai/qutip|qutip]]: quantum-computing-engineer, quantum-ml-engineer, quantum-computing-researcher
- [[04-public-skills-directory/skills/k-dense-ai/research-lookup|research-lookup]]: industry-researcher
- [[04-public-skills-directory/skills/k-dense-ai/scholar-evaluation|scholar-evaluation]]: ai-engineer
- [[04-public-skills-directory/skills/k-dense-ai/scientific-brainstorming|scientific-brainstorming]]: software-engineer
- [[04-public-skills-directory/skills/k-dense-ai/scikit-learn|scikit-learn]]: quantum-ml-engineer
- [[04-public-skills-directory/skills/k-dense-ai/zarr-python|zarr-python]]: python-engineer

## Links

- Up: [[04-public-skills-directory/sources/_index|All sources]]
